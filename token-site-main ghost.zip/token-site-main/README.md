# Ghost Voice Control

Multi-account Discord voice session manager with real-time presence radar and controls.

## Features

- 🎙️ Multi-account voice join/leave with staggered dispatch
- Real-time presence radar with owner-only cached username search, shared-server roles, channel lists, and voice participants
- 🔑 Access key system with granular permissions per key
- 🛡️ Anti-leave protection with exponential backoff
- 👣 Auto-follow mode
- 💬 Auto-react rules per user
- 🔒 AES-256-GCM encrypted local state, optional Supabase sync
- ⚡ SSE-powered live UI (no polling)

## Deploy to Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template)

1. Fork this repo to your GitHub
2. Create a new Railway project → **Deploy from GitHub repo**
3. Set the required environment variables (see below)
4. Railway will auto-build and deploy

Railway installs the locked dependencies with `npm ci` and then runs
`npm run build`. Keep the frontend entry point (`src/main.tsx`), its imported
source files, and `vite.config.ts` in the GitHub repository; the build cannot
complete if these files exist only in a local working copy.

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ACCESS_PASSWORD` | **Yes** | Owner dashboard password (min 8 chars recommended) |
| `SESSION_SECRET` | **Yes** | 32+ char random string for signing session tokens |
| `ENCRYPTION_KEY` | **Yes** | 32+ char random string for AES-256-GCM state encryption |
| `SUPABASE_URL` | Optional | Supabase project URL for cloud key sync |
| `SUPABASE_SERVICE_ROLE_KEY` | Recommended | Supabase service role key (server only) |
| `DATA_DIR` | Optional | Path for encrypted state file (default: `./data`) |
| `PORT` | Optional | HTTP port (Railway injects this automatically) |
| `MAX_SESSIONS` | Optional | Max concurrent Discord sessions (default: 1000) |
| `JOIN_STAGGER_MS` | Optional | Delay between batch joins in ms (default: 650) |

> ⚠️ **Never commit `.env` files.** Set secrets via Railway's Variables panel.

## Run Locally

**Prerequisites:** Node.js 20.19+ or 22.12+

```bash
npm install
cp .env.example .env.local
# Fill in your values in .env.local
npm run dev
```

## Build

```bash
npm run build
npm start
```

## Security Notes

- Discord tokens are stored AES-256-GCM encrypted on disk, never sent to the browser
- The browser only receives opaque session IDs — tokens are never exposed
- Sessions are signed HMAC-SHA256 tokens with expiry and instant revocation
- The session cookie is the *only* accepted credential: `httpOnly`, `Secure` in
  production, and `SameSite=Lax`
- Cross-origin writes are refused by an `Origin` check on every non-GET request
- Brute-force protection on login (exponential backoff, 12 attempt limit per IP,
  plus a global cap against distributed attempts)
- Rate limiting on all API routes (token bucket, 240 req/min)
- All SSE connections are revoked instantly when a key is disabled or deleted
- CSP allows no inline scripts in production; `frame-ancestors 'none'` and HSTS
  are set alongside it
- A password set from the owner panel is stored as a scrypt hash, never in the clear

### Fixed in 2.1.0

| Area | Issue |
| --- | --- |
| Radar | `POST /radar/join-target` skipped the guild allow-list that `/voice/join` enforces, so a key restricted to one server could send its accounts anywhere |
| Session cookie | `SameSite=None` in production let any other site fire authenticated writes at the API; now `Lax` plus an `Origin` check |
| Auth | The legacy `<expiry>.<hmac>` token minted an owner session under a fixed id that revocation could never invalidate — removed |
| Logging | The owner-key check wrote the expected and supplied key lengths to the shared console, readable by any key with `canViewLogs` |
| Client | The SSE URL still appended a `localStorage` token as `?token=`, leaking a credential into proxy logs and `Referer` |
| Keys | A non-numeric `maxUses` became `NaN`, and `length >= NaN` is always false — the key came out unlimited. Bad input is now rejected |
| Keys | The `radar_only` preset dropped `allowedGuildIds`, silently widening a server-restricted key |
| Auto-react | Editing and deleting rules never re-checked `canUseAutoReact` |
| Owner password | 4-character minimum, stored in plain text inside the state file |
| Boot password | Generated with `Math.random()`, which is predictable — now `crypto.randomBytes` |
| Types | `@types/react` was missing, so the entire front-end type-checked as `any`. Added, with `strict` enabled — the build is now 0 errors |
| UI | Per-card "leave server" acted on the whole selection instead of that one account |
| UI | A non-JSON error response surfaced as a raw `Unexpected token <` |
| UI | Two competing `?key=` auto-logins raced; the animation never played for link logins, and owner logins skipped it entirely |

## Access sequence

On a successful login the dashboard plays a short verification sequence before
handing over. It is cut to `public/access-granted.mp3` (6.58 s, extracted from
the supplied Audacity project): the first voice runs under the scanning phase,
and the "GHOST AWAKENED" burst lands on the second voice at 2.9 s.

**The sequence cannot be skipped.** It ends on the audio's own `ended` event,
so it always lasts exactly as long as the voice; the timers in the component
are only a fallback for when the file never started, and both sit past the end
of it.

The meter under the dial reads a loudness envelope baked off the real mix
(`ACCESS_ENVELOPE` in `src/lib/accessSound.ts`, 25 ms buckets), indexed by the
element's own `currentTime` so picture and sound cannot drift.

An earlier build tapped the element with `createMediaElementSource` to drive
that meter live. That call reroutes the element's output into the AudioContext,
and a context created outside a user gesture starts `suspended` — the audio
went into a stopped graph and **nothing reached the speakers**. Nothing is
routed through an AudioContext now.

Browsers only allow audio after a user gesture, so:

- **Typed key or owner password** — `unlockAccessSound()` primes the element
  inside the click handler, before the login request, because that request is
  slow enough for Safari to treat the gesture as spent.
- **`?key=` links** — nothing was ever clicked, so audio is blocked outright.
  That path shows a one-tap *Enter* card first. It starts the sequence; it
  cannot skip it.

`prefers-reduced-motion` collapses the whole thing to a short fade.

To swap the sound, replace `public/access-granted.mp3`, regenerate
`ACCESS_ENVELOPE`, and set `VERIFY_MS` in `src/components/AccessGranted.tsx`
to the beat you want the burst to land on.
