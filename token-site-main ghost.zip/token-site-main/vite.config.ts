import { fileURLToPath } from 'node:url';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import JavaScriptObfuscator from 'javascript-obfuscator';
import { defineConfig } from 'vite';
import type { Plugin } from 'vite';

// Scrambles the production JS so DevTools > Sources shows unreadable code.
function obfuscate(): Plugin {
  return {
    name: 'obfuscate-bundle',
    apply: 'build',
    enforce: 'post',
    generateBundle(_opts, bundle) {
      for (const chunk of Object.values(bundle)) {
        if (chunk.type !== 'chunk' || !chunk.fileName.endsWith('.js')) continue;
        // Never let a bad obfuscation run break the whole build — fall back
        // to the plain minified chunk and keep deploying.
        try {
          chunk.code = JavaScriptObfuscator.obfuscate(chunk.code, {
            compact: true,
            identifierNamesGenerator: 'hexadecimal',
            stringArray: true,
            stringArrayThreshold: 0.75,
            stringArrayEncoding: ['base64'],
            stringArrayRotate: true,
            stringArrayShuffle: true,
            splitStrings: false,
            controlFlowFlattening: false,
            deadCodeInjection: false,
            selfDefending: false,
            debugProtection: false,
            renameGlobals: false,
            sourceMap: false,
            target: 'browser',
          }).getObfuscatedCode();
        } catch (err) {
          console.warn(`[obfuscate] skipped ${chunk.fileName}:`, (err as Error).message);
        }
      }
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), obfuscate()],
  resolve: {
    alias: {
      '@shared': fileURLToPath(new URL('./shared', import.meta.url)),
    },
  },
  esbuild: { drop: ['console', 'debugger'] },
  server: { allowedHosts: true },
  preview: { allowedHosts: true },
  build: {
    outDir: 'dist/public',
    emptyOutDir: true,
    sourcemap: false,
    minify: 'esbuild',
  },
});
