/**
 * Contract shared by the server and the browser.
 *
 * Rule that drives the whole shape below: a raw Discord token NEVER crosses
 * this boundary. The browser only ever sees `id`, an opaque session handle.
 */

export type SessionStatus = 'online' | 'connecting' | 'offline' | 'error';

/** One active voice slot for a session (one per guild). */
export interface VoiceSlot {
  guildId: string;
  guildName: string | null;
  channelId: string;
  channelName: string | null;
  selfMute: boolean;
  selfDeaf: boolean;
}

export interface BotSession {
  /** Opaque handle. Not derivable from the token. */
  id: string;
  userId: string | null;
  username: string;
  discriminator: string | null;
  avatarUrl: string | null;
  status: SessionStatus;
  error: string | null;
  /** True if the session is in at least one voice channel. */
  inVoice: boolean;
  /**
   * All active voice slots (one per guild).
   * Legacy single-slot fields below are kept for backwards-compat and
   * reflect the *first* slot (or null when silent).
   */
  voiceSlots: VoiceSlot[];
  guildId: string | null;
  guildName: string | null;
  channelId: string | null;
  channelName: string | null;
  selfMute: boolean;
  selfDeaf: boolean;
  antiLeave: boolean;
  antiMove: boolean;
  antiHost: boolean;
  autoFollow: boolean;
  guildCount: number;
  /** Last 4 characters of the token, so a human can tell rows apart. */
  tokenHint: string;
}

export interface AppConfig {
  defaultGuildId: string;
  defaultChannelId: string;
  autoFollowTargetId: string;
  autoFollowEnabled: boolean;
  globalAntiLeave: boolean;
  globalAntiMove: boolean;
  globalAntiHost: boolean;
  selfMute: boolean;
  selfDeaf: boolean;
}

export type LogType = 'info' | 'join' | 'leave' | 'anti-leave' | 'anti-move' | 'anti-host' | 'follow' | 'react' | 'error' | 'warn';

export interface AutoReactRule {
  id: string;
  name: string;
  targetUserId: string;
  emoji: string;
  enabled: boolean;
  botScope: 'all' | 'specific';
  botIds: string[];
  createdAt: number;
  triggerCount: number;
  lastTriggeredAt: number | null;
  createdByRole?: UserRole;
  createdByKeyId?: string;
}

export interface SystemLog {
  id: string;
  /** Epoch millis. The client formats it in the viewer's locale. */
  at: number;
  type: LogType;
  message: string;
}

export interface MutualGuild {
  id: string;
  name: string;
  iconUrl: string | null;
}

export interface UserProfile {
  userId: string;
  username: string;
  globalName: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  accentColor: string | null;
  bio: string;
  createdAt: number;
  badges: string[];
  /** True when the looked-up ID belongs to a bot application, not a human account. */
  isBot: boolean;
  /** True when Discord flags the bot as verified. */
  isVerifiedBot: boolean;
  inVoice: boolean;
  voiceGuildId: string | null;
  voiceGuildName: string | null;
  voiceChannelId: string | null;
  voiceChannelName: string | null;
  voiceMemberCount: number;
  /** Whether the target has their own mic muted or is deafened. */
  voiceSelfMute: boolean;
  voiceSelfDeaf: boolean;
  mutualGuilds: MutualGuild[];
}

/** Where saved accounts live, and whether they survive a redeploy. */
export interface StorageStatus {
  backend: 'supabase' | 'disk';
  /** True when saved accounts survive a redeploy/restart. */
  durable: boolean;
  /** Cloud sync state. 'off' = Supabase not configured. */
  remote: 'off' | 'ready' | 'unknown' | 'unavailable' | 'blocked';
  lastSyncAt: number | null;
  message: string;
}

export interface Snapshot {
  sessions: BotSession[];
  storage?: StorageStatus;
  config: AppConfig;
  autoReactRules?: AutoReactRule[];
  stats: {
    total: number;
    online: number;
    inVoice: number;
    uptimeSeconds: number;
  };
}

export type UserRole = 'owner' | 'user';

export interface KeyPermissions {
  botScope: 'all' | 'specific';
  assignedBotIds: string[];
  /**
   * Guild IDs this key is allowed to join/leave.
   * Empty array = unrestricted (all guilds).
   */
  allowedGuildIds: string[];
  canJoinVoice: boolean;
  canLeaveVoice: boolean;
  canMuteDeaf: boolean;
  canUseAntiLeave: boolean;
  canUseAutoFollow: boolean;
  canViewRadar: boolean;
  canUseAutoReact?: boolean;
  canUseSpammer?: boolean;
  canReconnectBots?: boolean;
  canLeaveGuild?: boolean;
  canImportBots: boolean;
  canDeleteBots: boolean;
  canViewLogs: boolean;
}

export interface KeyUsageRecord {
  sessionId: string;
  ip: string;
  userAgent?: string;
  redeemedAt: number;
  lastActiveAt: number;
}

export interface AccessKey {
  id: string;
  key: string;
  note: string;
  role: 'user';
  createdAt: number;
  expiresAt: number | null; // epoch timestamp or null if permanent
  durationMs: number | null; // duration from first activation or null
  firstUsedAt: number | null;
  maxUses: number | null; // 1 for single device, N for N users, null for unlimited
  usedCount: number;
  status: 'active' | 'disabled';
  permissions: KeyPermissions;
  redeemedUsers: KeyUsageRecord[];
  config?: Partial<AppConfig>;
}

export interface AuthSessionInfo {
  authenticated: boolean;
  role?: UserRole;
  keyInfo?: {
    id: string;
    key: string;
    note: string;
    expiresAt: number | null;
    remainingMs: number | null;
    permissions: KeyPermissions;
  };
}

/** Envelope for every server-sent event on /api/stream. */
export type StreamEvent =
  | { kind: 'snapshot'; data: Snapshot }
  | { kind: 'logs'; data: SystemLog[] }
  | { kind: 'ping'; data: number }
  | { kind: 'revoked'; message: string };

export interface ApiError {
  error: string;
}

