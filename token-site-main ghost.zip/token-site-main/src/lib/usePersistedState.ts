import { useEffect, useState } from 'react';

const PREFIX = 'gvc:ui:';

export function readSaved<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw === null ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

export function writeSaved(key: string, value: unknown): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* private mode or full storage: the page just forgets, nothing breaks */
  }
}

/** Forget everything remembered here. Called on logout so the next person starts clean. */
export function clearSaved(): void {
  try {
    for (const k of Object.keys(localStorage)) {
      if (k.startsWith(PREFIX)) localStorage.removeItem(k);
    }
  } catch {
    /* ignore */
  }
}

/** useState that survives a refresh, a closed tab and a phone browser discarding the page. */
export function usePersistedState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => readSaved(key, initial));
  useEffect(() => {
    writeSaved(key, value);
  }, [key, value]);
  return [value, setValue] as const;
}

/**
 * Remembers the scroll position of one view and puts it back when the view returns.
 * Content arrives after mount (lazy panels, live data), so the restore retries for ~2 s
 * until the page is tall enough instead of giving up on the first try.
 */
export function useScrollMemory(scope: string, ready: boolean): void {
  useEffect(() => {
    if (!ready) return;
    let timer: number | undefined;
    const onScroll = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => writeSaved(`scroll:${scope}`, window.scrollY), 120);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.clearTimeout(timer);
    };
  }, [scope, ready]);

  useEffect(() => {
    if (!ready) return;
    const y = readSaved<number>(`scroll:${scope}`, 0);
    if (!y) return;
    let tries = 0;
    const id = window.setInterval(() => {
      window.scrollTo(0, y);
      tries += 1;
      if (Math.abs(window.scrollY - y) < 4 || tries > 20) window.clearInterval(id);
    }, 100);
    return () => window.clearInterval(id);
  }, [scope, ready]);
}
