export const ACCESS_AUDIO_MS = 6580;
export const ENVELOPE_STEP_MS = 25;
export const ACCESS_ENVELOPE: readonly number[] = [];

let accessAudio: HTMLAudioElement | null = null;

function getAudio(): HTMLAudioElement | null {
  if (typeof Audio === 'undefined') return null;
  if (!accessAudio) {
    accessAudio = new Audio('/access-granted.mp3');
    accessAudio.preload = 'auto';
  }
  return accessAudio;
}

export function unlockAccessSound(): void {
  const audio = getAudio();
  if (!audio) return;

  audio.currentTime = 0;
  void audio.play().then(
    () => {
      audio.pause();
      audio.currentTime = 0;
    },
    () => {
      // Audio is optional; the access animation has a timer-based fallback.
    },
  );
}

export async function playAccessSound(): Promise<HTMLAudioElement | null> {
  const audio = getAudio();
  if (!audio) return null;

  audio.currentTime = 0;
  try {
    await audio.play();
    return audio;
  } catch {
    return null;
  }
}

export function stopAccessSound(): void {
  const audio = getAudio();
  if (!audio) return;
  audio.pause();
  audio.currentTime = 0;
}