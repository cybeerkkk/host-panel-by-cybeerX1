import type {
  AccessKey,
  AppConfig,
  AuthSessionInfo,
  AutoReactRule,
  BotSession,
  Snapshot,
  SystemLog,
  UserRole,
  UserProfile,
} from '@shared/types';

export type GuildRank = 'owner' | 'administrator' | 'admin';

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

const sleepMs = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const isRead = !init?.method || init.method === 'GET';
  let response!: Response;
  // A burst of reads can hit the rate limit for a moment; wait and retry quietly.
  for (let attempt = 0; attempt < 4; attempt++) {
    response = await fetch(`/api${path}`, {
      ...init,
      credentials: 'include',
      headers: {
        ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
        ...init?.headers,
      },
    });
    if (response.status !== 429 || !isRead || attempt === 3) break;
    await sleepMs(700 * (attempt + 1));
  }
  const text = await response.text();
  let payload: unknown;

  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    throw new ApiError(
      text || `The server returned an invalid response (${response.status})`,
      response.status,
    );
  }

  if (!response.ok) {
    const message =
      payload && typeof payload === 'object' && 'error' in payload &&
      typeof payload.error === 'string'
        ? payload.error
        : response.statusText || `Request failed (${response.status})`;
    throw new ApiError(message, response.status);
  }

  return payload as T;
}

function jsonBody(value: unknown): Pick<RequestInit, 'method' | 'body'> {
  return { method: 'POST', body: JSON.stringify(value) };
}

function query(values: Record<string, string | number | undefined>): string {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== undefined) params.set(key, String(value));
  }
  const result = params.toString();
  return result ? `?${result}` : '';
}

export interface MonitorGuildSummary {
  id: string;
  name: string;
  iconUrl: string | null;
  memberCount?: number | null;
}

export interface MonitorGuildVoiceMember {
  userId: string;
  username: string;
  globalName: string | null;
  avatarUrl: string | null;
  selfMute: boolean;
  selfDeaf: boolean;
  serverMute: boolean;
  serverDeaf: boolean;
}

export interface MonitorGuildChannelDetails {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'stage';
  parentName: string | null;
  memberCount?: number;
  members?: MonitorGuildVoiceMember[];
}

export interface MonitorGuildDetails {
  id: string;
  name: string;
  iconUrl: string | null;
  memberCount: number | null;
  channels: MonitorGuildChannelDetails[];
  channelsComplete?: boolean;
  channelsWarning?: string | null;
}

export interface MonitorGuildRoleInfo {
  id: string;
  name: string;
  color: string | null;
  position: number;
  hoist: boolean;
  mentionable: boolean;
  managed: boolean;
  permissions: string;
  permissionNames: string[];
  memberCount: number | null;
}

export interface MonitorGuildRoles {
  guildId: string;
  guildName: string;
  roles: MonitorGuildRoleInfo[];
}

export interface MonitorMemberRoleDetails {
  userId: string;
  guildId: string;
  guildName: string;
  nickname: string | null;
  avatarUrl: string | null;
  joinedAt: number | null;
  isOwner: boolean;
  roles: Array<{
    id: string;
    name: string;
    color: string | null;
    position: number;
    hoist: boolean;
    administrator: boolean;
    elevated: boolean;
  }>;
}

export interface MonitorMemberSearchResult {
  userId: string;
  username: string;
  globalName: string | null;
  nickname: string | null;
  avatarUrl: string | null;
  guildId: string;
  guildName: string;
  guildIconUrl: string | null;
}

export interface MonitorVoiceMember {
  userId: string;
  username: string;
  globalName: string | null;
  avatarUrl: string | null;
  selfMute: boolean;
  selfDeaf: boolean;
  serverMute: boolean;
  serverDeaf: boolean;
}

export interface MonitorChannel {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'stage';
  parentName: string | null;
  /** Voice and stage channels only. */
  memberCount?: number;
  members?: MonitorVoiceMember[];
}

export interface MonitorGuild {
  id: string;
  name: string;
  iconUrl: string | null;
  memberCount: number | null;
  channels: MonitorChannel[];
  channelsComplete: boolean;
  channelsWarning: string | null;
}

export type MonitorGuildRole = Record<string, unknown>;
export type MonitorMessage = Record<string, unknown>;
export type MonitorChannelLookup = Record<string, unknown>;
export type MonitorMemberRoles = Record<string, unknown>;
export type MonitorMemberPermissions = Record<string, unknown>;
export type MonitorRoleMembers = Record<string, unknown>;

export interface PublicProfile {
  userId: string;
  username: string;
  globalName: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  accentColor: string | null;
  bio: string;
  createdAt: number;
  badges: string[];
  isBot?: boolean;
  isVerifiedBot?: boolean;
  // Live presence fields (always present in response, may be false/null when offline)
  inVoice: boolean;
  voiceGuildId: string | null;
  voiceGuildName: string | null;
  voiceChannelId: string | null;
  voiceChannelName: string | null;
  voiceMemberCount: number;
  voiceSelfMute: boolean;
  voiceSelfDeaf: boolean;
  // Mutual servers visible to connected accounts
  mutualGuilds: Array<{ id: string; name: string; iconUrl: string | null }>;
}

export const api = {
  publicUser: (userId: string) =>
    request<PublicProfile>(`/public/user/${encodeURIComponent(userId)}`),
  publicUserRanks: (userId: string) =>
    request<Record<string, GuildRank>>(`/public/user/${encodeURIComponent(userId)}/ranks`),
  publicSearch: (q: string) =>
    request<MonitorMemberSearchResult[]>(`/public/search${query({ q })}`),
  publicMemberRoles: (guildId: string, userId: string) =>
    request<MonitorMemberRoleDetails>(`/public/guilds/${encodeURIComponent(guildId)}/member-roles${query({ userId })}`),
  publicGuildRoles: (guildId: string) =>
    request<MonitorGuildRoles>(`/public/guilds/${encodeURIComponent(guildId)}/roles`),
  session: () => request<AuthSessionInfo>('/auth/session'),
  login: (credentials: { key?: string; password?: string }) =>
    request<{
      ok: boolean;
      role?: UserRole;
      keyInfo?: AuthSessionInfo['keyInfo'];
    }>('/auth/login', jsonBody(credentials)),
  logout: () => request<{ ok: boolean }>('/auth/logout', jsonBody({})),

  snapshot: () => request<Snapshot>('/snapshot'),
  logs: () => request<SystemLog[]>('/logs'),

  addTokens: (tokens: string) =>
    request<{ added: number; failed: number; message?: string; reasons?: string[] }>('/sessions', {
      method: 'POST',
      body: JSON.stringify({ tokens }),
    }),
  join: (body: {
    ids?: string[];
    guildId: string;
    channelId: string;
    selfMute: boolean;
    selfDeaf: boolean;
  }) => request<{ sent: number }>('/voice/join', jsonBody(body)),
  leave: (ids?: string[]) => request<{ sent: number }>('/voice/leave', jsonBody({ ids })),
  leaveGuild: (ids: string[], guildId: string) =>
    request<{ sent: number }>('/voice/leave', jsonBody({ ids, guildId })),
  patchConfig: (patch: Partial<AppConfig>) =>
    request<AppConfig>('/config', { method: 'PATCH', body: JSON.stringify(patch) }),
  removeSession: (id: string) =>
    request<{ ok: boolean }>(`/sessions/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  removeAll: () => request<{ ok: boolean; removed: number }>('/sessions', { method: 'DELETE' }),
  reconnect: (id: string) =>
    request<{ ok: boolean }>(`/sessions/${encodeURIComponent(id)}/reconnect`, jsonBody({})),
  replaceToken: (id: string, token: string) =>
    request<BotSession>(`/sessions/${encodeURIComponent(id)}/token`, {
      method: 'PUT',
      body: JSON.stringify({ token }),
    }),
  patchSession: (id: string, patch: { antiLeave?: boolean; autoFollow?: boolean }) =>
    request<BotSession>(`/sessions/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  setVoiceState: (
    id: string,
    patch: { selfMute?: boolean; selfDeaf?: boolean },
    guildId: string,
  ) =>
    request<{ ok: boolean }>(`/voice/${encodeURIComponent(id)}/state`, {
      method: 'PATCH',
      body: JSON.stringify({ ...patch, guildId }),
    }),

  radar: (userId: string) =>
    request<UserProfile>(`/radar/${encodeURIComponent(userId)}`),
  radarRanks: (userId: string) =>
    request<Record<string, GuildRank>>(`/radar/${encodeURIComponent(userId)}/ranks`),

  createAutoReactRule: (body: Partial<AutoReactRule>) =>
    request<AutoReactRule>('/auto-react', jsonBody(body)),
  updateAutoReactRule: (id: string, patch: Partial<AutoReactRule>) =>
    request<AutoReactRule>(`/auto-react/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  deleteAutoReactRule: (id: string) =>
    request<{ ok: boolean }>(`/auto-react/${encodeURIComponent(id)}`, { method: 'DELETE' }),

  owner: {
    getKeys: () => request<AccessKey[]>('/owner/keys'),
    createKeys: (body: Record<string, unknown>) =>
      request<{ ok: boolean; keys: AccessKey[] }>('/owner/keys', jsonBody(body)),
    patchKey: (id: string, patch: Partial<AccessKey>) =>
      request<AccessKey>(`/owner/keys/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      }),
    deleteKey: (id: string) =>
      request<{ ok: boolean }>(`/owner/keys/${encodeURIComponent(id)}`, { method: 'DELETE' }),
    kickUser: (keyId: string, sessionId: string) =>
      request<{ ok: boolean }>(
        `/owner/keys/${encodeURIComponent(keyId)}/kick/${encodeURIComponent(sessionId)}`,
        jsonBody({}),
      ),
    updatePassword: (password: string) =>
      request<{ ok: boolean }>('/owner/password', jsonBody({ password })),
    getSupabaseStatus: () => request<{
      configured: boolean;
      url: string | null;
      tableReady: boolean;
      message: string;
      schemaSql: string;
    }>('/owner/supabase-status'),
    syncSupabase: () => request<{ synced: number }>('/owner/supabase-sync', jsonBody({})),
  },

  monitor: {
    searchMembers: (search: string) =>
      request<MonitorMemberSearchResult[]>(`/monitor/user-search${query({ q: search })}`),
    guilds: () => request<MonitorGuildSummary[]>('/monitor/guilds'),
    guild: (guildId: string) =>
      request<MonitorGuild>(`/monitor/guilds/${encodeURIComponent(guildId)}`),
    guildDetails: (guildId: string) =>
      request<MonitorGuildDetails>(`/monitor/guilds/${encodeURIComponent(guildId)}`),
    memberRoles: (guildId: string, userId: string) =>
      request<MonitorMemberRoles>(
        `/monitor/guilds/${encodeURIComponent(guildId)}/member-roles${query({ userId })}`,
      ),
    memberRoleDetails: (guildId: string, userId: string) =>
      request<MonitorMemberRoleDetails>(
        `/monitor/guilds/${encodeURIComponent(guildId)}/member-roles${query({ userId })}`,
      ),
    memberPermissions: (guildId: string, userId: string) =>
      request<MonitorMemberPermissions>(
        `/monitor/guilds/${encodeURIComponent(guildId)}/member-permissions${query({ userId })}`,
      ),
    roleMembers: (guildId: string, roleId: string) =>
      request<MonitorRoleMembers>(
        `/monitor/guilds/${encodeURIComponent(guildId)}/roles/${encodeURIComponent(roleId)}/members`,
      ),
    guildRoles: (guildId: string) =>
      request<MonitorGuildRoles>(`/monitor/guilds/${encodeURIComponent(guildId)}/roles`),
    messages: (channelId: string, botId?: string, limit?: number) =>
      request<MonitorMessage[]>(
        `/monitor/messages${query({ channelId, botId, limit })}`,
      ),
    react: (channelId: string, messageId: string, emoji: string, botIds: string[]) =>
      request<{ sent: number; errors?: string[] }>(
        '/monitor/react',
        jsonBody({ channelId, messageId, emoji, botIds }),
      ),
    channelLookup: (channelId: string, botId?: string) =>
      request<MonitorChannelLookup>(
        `/monitor/channel-lookup${query({ channelId, botId })}`,
      ),
  },
};
