import { useCallback, useEffect, useState } from 'react';
import type { Snapshot, StreamEvent, SystemLog } from '@shared/types';
import { api } from './api';

export type ConnectionState = 'live' | 'connecting' | 'reconnecting' | 'offline';

/** The server pings every 25 s and sends a snapshot every 30 s: silence past this means a dead socket. */
const STALE_AFTER_MS = 70_000;
/** After the page was hidden, anything quieter than this is refreshed the moment it comes back. */
const WAKE_STALE_MS = 35_000;

export function useLiveData(enabled: boolean) {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [connection, setConnection] = useState<ConnectionState>('offline');

  const refresh = useCallback(() => {
    if (!enabled) return;
    void Promise.all([api.snapshot(), api.logs()])
      .then(([nextSnapshot, nextLogs]) => {
        setSnapshot(nextSnapshot);
        setLogs(nextLogs);
      })
      .catch((error: unknown) => {
        console.error('Could not refresh live dashboard data', error);
      });
  }, [enabled]);

  useEffect(() => {
    if (!enabled) {
      setSnapshot(null);
      setLogs([]);
      setConnection('offline');
      return;
    }

    let source: EventSource | null = null;
    let retryTimer: number | undefined;
    let attempt = 0;
    let lastEventAt = Date.now();
    let disposed = false;

    const checkSession = () => {
      // Repeated failures can mean the login expired, not the network. Say so instead of
      // retrying forever behind a "reconnecting" badge.
      void api
        .session()
        .then((res) => {
          if (!res.authenticated && !disposed) {
            window.dispatchEvent(
              new CustomEvent('gvc-auth-revoked', { detail: 'Your session expired. Please sign in again.' }),
            );
          }
        })
        .catch(() => undefined);
    };

    const scheduleRetry = () => {
      if (disposed || retryTimer !== undefined) return;
      const delay = Math.min(1000 * 2 ** attempt, 15_000);
      attempt += 1;
      if (attempt === 3) checkSession();
      retryTimer = window.setTimeout(() => {
        retryTimer = undefined;
        connect();
      }, delay);
    };

    function connect() {
      if (disposed) return;
      source?.close();
      setConnection(attempt === 0 ? 'connecting' : 'reconnecting');
      const es = new EventSource('/api/stream', { withCredentials: true });
      source = es;

      es.onopen = () => {
        attempt = 0;
        lastEventAt = Date.now();
        setConnection('live');
      };

      es.onerror = () => {
        setConnection('reconnecting');
        // On an HTTP error (a 502 while Railway swaps containers) the browser gives up for
        // good and never retries by itself. Reconnect by hand in that case.
        if (es.readyState === EventSource.CLOSED) {
          es.close();
          scheduleRetry();
        }
      };

      es.onmessage = (message) => {
        lastEventAt = Date.now();
        let event: StreamEvent;
        try {
          event = JSON.parse(message.data) as StreamEvent;
        } catch (error) {
          console.error('Received an invalid live dashboard event', error);
          return;
        }

        switch (event.kind) {
          case 'snapshot':
            setSnapshot(event.data);
            break;
          case 'logs':
            // Every (re)connect replays the server's recent log buffer: keep only new lines.
            setLogs((current) => {
              const known = new Set(current.map((entry) => entry.id));
              const fresh = event.data.filter((entry) => !known.has(entry.id));
              return fresh.length > 0 ? [...current, ...fresh].slice(-500) : current;
            });
            break;
          case 'revoked':
            window.dispatchEvent(new CustomEvent('gvc-auth-revoked', { detail: event.message }));
            break;
          case 'ping':
            break;
        }
      };
    }

    const reconnectNow = () => {
      window.clearTimeout(retryTimer);
      retryTimer = undefined;
      attempt = 0;
      connect();
    };

    // Coming back to the page (other tab, locked phone, laptop lid): a socket that went quiet
    // while hidden is replaced immediately and the data is pulled fresh, so nothing looks stale.
    const wake = () => {
      if (document.visibilityState === 'hidden') return;
      const quiet = Date.now() - lastEventAt > WAKE_STALE_MS;
      if (quiet || source?.readyState !== EventSource.OPEN) reconnectNow();
      refresh();
    };
    const onPageShow = (event: PageTransitionEvent) => {
      if (event.persisted) wake();
    };

    document.addEventListener('visibilitychange', wake);
    window.addEventListener('online', wake);
    window.addEventListener('pageshow', onPageShow);

    // A socket can die without any error event (NAT timeout, sleeping device).
    const watchdog = window.setInterval(() => {
      if (document.visibilityState === 'hidden') return;
      if (Date.now() - lastEventAt > STALE_AFTER_MS) reconnectNow();
    }, 10_000);

    connect();

    return () => {
      disposed = true;
      window.clearTimeout(retryTimer);
      window.clearInterval(watchdog);
      document.removeEventListener('visibilitychange', wake);
      window.removeEventListener('online', wake);
      window.removeEventListener('pageshow', onPageShow);
      source?.close();
      setConnection('offline');
    };
  }, [enabled, refresh]);

  return { snapshot, logs, connection, refresh };
}
