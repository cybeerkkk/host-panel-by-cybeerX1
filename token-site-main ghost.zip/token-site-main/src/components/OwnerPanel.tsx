import { useEffect, useState, type FormEvent } from 'react';
import type { AccessKey, BotSession, KeyPermissions } from '@shared/types';
import { api, ApiError } from '../lib/api';
import {
  IconCheck,
  IconClock,
  IconCopy,
  IconCrown,
  IconDatabase,
  IconDelete,
  IconEdit,
  IconGlobe,
  IconKey,
  IconLink,
  IconLock,
  IconPause,
  IconPlay,
  IconPlus,
  IconRefresh,
  IconSearch,
  IconShield,
  IconSpeaker,
  IconUsers,
  IconUserX,
} from './Icons';

interface OwnerPanelProps {
  availableBots: BotSession[];
  onClose: () => void;
}

const DEFAULT_PERMISSIONS: KeyPermissions = {
  botScope: 'all',
  assignedBotIds: [],
  allowedGuildIds: [],
  canJoinVoice: true,
  canLeaveVoice: true,
  canMuteDeaf: true,
  canUseAntiLeave: true,
  canUseAutoFollow: false,
  canUseAutoReact: false,
  canUseSpammer: false,
  canReconnectBots: true,
  canLeaveGuild: false,
  canViewRadar: true,
  canImportBots: false,
  canDeleteBots: false,
  canViewLogs: true,
};

type PresetRole = 'admin' | 'voice_operator' | 'trial_user' | 'radar_only';

export function OwnerPanel({ availableBots, onClose }: OwnerPanelProps) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  const [keys, setKeys] = useState<AccessKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'disabled' | 'expired'>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  const [confirmingDelete, setConfirmingDelete] = useState<string | null>(null);

  // Modals & Drawers
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);
  const [editingKey, setEditingKey] = useState<AccessKey | null>(null);
  const [expandedKeyUsers, setExpandedKeyUsers] = useState<string | null>(null);

  // New Key Form State
  const [newKeyCode, setNewKeyCode] = useState('');
  const [newNote, setNewNote] = useState('');
  const [newCount, setNewCount] = useState(1);
  const [newMaxUses, setNewMaxUses] = useState<number | ''>(1);
  const [newDurationType, setNewDurationType] = useState<'permanent' | '1h' | '24h' | '3d' | '7d' | '30d' | 'custom'>('24h');
  const [customDurationHours, setCustomDurationHours] = useState(48);
  const [newStartsOnUse, setNewStartsOnUse] = useState(true);
  const [newPermissions, setNewPermissions] = useState<KeyPermissions>(DEFAULT_PERMISSIONS);
  const [creating, setCreating] = useState(false);

  // Password Change State
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Supabase State
  const [supabaseStatus, setSupabaseStatus] = useState<{
    configured: boolean;
    url: string | null;
    tableReady: boolean;
    message: string;
    schemaSql: string;
  } | null>(null);
  const [syncingSupabase, setSyncingSupabase] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  const fetchKeys = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await api.owner.getKeys();
      setKeys(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load access keys');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKeys();
  }, []);

  const handleCopy = (text: string, id: string, isLink = false) => {
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(text);
      if (isLink) {
        setCopiedLink(id);
        setTimeout(() => setCopiedLink(null), 2000);
      } else {
        setCopiedKey(id);
        setTimeout(() => setCopiedKey(null), 2000);
      }
    }
  };

  const getDirectLink = (key: string) => {
    if (typeof window === 'undefined') return key;
    const origin = window.location.origin;
    return `${origin}/?key=${encodeURIComponent(key)}`;
  };

  const applyPreset = (preset: PresetRole) => {
    switch (preset) {
      case 'admin':
        setNewPermissions({
          botScope: 'all',
          assignedBotIds: [],
          allowedGuildIds: [],
          canJoinVoice: true,
          canLeaveVoice: true,
          canMuteDeaf: true,
          canUseAntiLeave: true,
          canUseAutoFollow: true,
          canUseAutoReact: true,
          canUseSpammer: true,
          canReconnectBots: true,
          canLeaveGuild: true,
          canViewRadar: true,
          canImportBots: true,
          canDeleteBots: true,
          canViewLogs: true,
        });
        break;
      case 'voice_operator':
        setNewPermissions({
          botScope: newPermissions.botScope,
          assignedBotIds: newPermissions.assignedBotIds,
          allowedGuildIds: newPermissions.allowedGuildIds ?? [],
          canJoinVoice: true,
          canLeaveVoice: true,
          canMuteDeaf: true,
          canUseAntiLeave: true,
          canUseAutoFollow: false,
          canUseAutoReact: false,
          canUseSpammer: false,
          canReconnectBots: true,
          canLeaveGuild: false,
          canViewRadar: true,
          canImportBots: false,
          canDeleteBots: false,
          canViewLogs: false,
        });
        break;
      case 'trial_user':
        setNewPermissions({
          botScope: newPermissions.botScope,
          assignedBotIds: newPermissions.assignedBotIds,
          allowedGuildIds: newPermissions.allowedGuildIds ?? [],
          canJoinVoice: true,
          canLeaveVoice: true,
          canMuteDeaf: false,
          canUseAntiLeave: false,
          canUseAutoFollow: false,
          canUseAutoReact: false,
          canUseSpammer: false,
          canReconnectBots: false,
          canLeaveGuild: false,
          canViewRadar: true,
          canImportBots: false,
          canDeleteBots: false,
          canViewLogs: false,
        });
        setNewDurationType('24h');
        setNewMaxUses(1);
        break;
      case 'radar_only':
        setNewPermissions({
          botScope: 'all',
          assignedBotIds: [],
          allowedGuildIds: newPermissions.allowedGuildIds ?? [],
          canJoinVoice: false,
          canLeaveVoice: false,
          canMuteDeaf: false,
          canUseAntiLeave: false,
          canUseAutoFollow: false,
          canUseAutoReact: false,
          canUseSpammer: false,
          canReconnectBots: false,
          canLeaveGuild: false,
          canViewRadar: true,
          canImportBots: false,
          canDeleteBots: false,
          canViewLogs: false,
        });
        break;
    }
  };

  const handleCreateKeys = async (e: FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setError('');

    try {
      let durationMs: number | null = null;
      let expiresAt: number | null = null;

      if (newDurationType !== 'permanent') {
        let hours = 24;
        if (newDurationType === '1h') hours = 1;
        else if (newDurationType === '24h') hours = 24;
        else if (newDurationType === '3d') hours = 72;
        else if (newDurationType === '7d') hours = 168;
        else if (newDurationType === '30d') hours = 720;
        else if (newDurationType === 'custom') hours = customDurationHours;

        const ms = hours * 3600 * 1000;
        if (newStartsOnUse) {
          durationMs = ms;
          expiresAt = null;
        } else {
          expiresAt = Date.now() + ms;
        }
      }

      await api.owner.createKeys({
        key: newKeyCode.trim() || undefined,
        note: newNote.trim() || undefined,
        count: newCount,
        maxUses: newMaxUses === '' ? null : Number(newMaxUses),
        durationMs,
        expiresAt,
        permissions: newPermissions,
      });

      setShowCreateModal(false);
      setNewKeyCode('');
      setNewNote('');
      setNewCount(1);
      fetchKeys();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to generate key(s)');
    } finally {
      setCreating(false);
    }
  };

  const handleToggleStatus = async (key: AccessKey) => {
    const nextStatus = key.status === 'active' ? 'disabled' : 'active';
    try {
      await api.owner.patchKey(key.id, { status: nextStatus });
      setKeys((prev) =>
        prev.map((k) => (k.id === key.id ? { ...k, status: nextStatus } : k)),
      );
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to toggle key status');
    }
  };

  const handleDeleteKey = async (id: string) => {
    try {
      await api.owner.deleteKey(id);
      setKeys((prev) => prev.filter((k) => k.id !== id));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to delete key');
    }
  };

  const handleKickUser = async (keyId: string, sessionId: string) => {
    try {
      await api.owner.kickUser(keyId, sessionId);
      setKeys((prev) =>
        prev.map((k) => {
          if (k.id === keyId) {
            return {
              ...k,
              redeemedUsers: k.redeemedUsers.filter((u) => u.sessionId !== sessionId),
            };
          }
          return k;
        }),
      );
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to kick user session');
    }
  };

  const handleUpdatePassword = async (e: FormEvent) => {
    e.preventDefault();
    if (!newPassword.trim()) return;
    try {
      await api.owner.updatePassword(newPassword.trim());
      setPasswordMsg({ text: 'Owner password updated successfully!', error: false });
      setNewPassword('');
      setTimeout(() => setShowPasswordModal(false), 1500);
    } catch (err) {
      setPasswordMsg({
        text: err instanceof ApiError ? err.message : 'Failed to update password',
        error: true,
      });
    }
  };

  const handleOpenSupabase = async () => {
    setShowSupabaseModal(true);
    try {
      const status = await api.owner.getSupabaseStatus();
      setSupabaseStatus(status);
    } catch {
      setSupabaseStatus({
        configured: false,
        url: null,
        tableReady: false,
        message: 'Could not fetch Supabase configuration',
        schemaSql: '',
      });
    }
  };

  const handleSyncSupabase = async () => {
    try {
      setSyncingSupabase(true);
      const res = await api.owner.syncSupabase();
      alert(`Successfully synced ${res.synced} keys to Supabase!`);
    } catch (err) {
      alert(`Supabase sync failed: ${err instanceof ApiError ? err.message : 'Error'}`);
    } finally {
      setSyncingSupabase(false);
    }
  };

  // Filtered keys
  const now = Date.now();
  const filteredKeys = keys.filter((k) => {
    const isExpired = k.expiresAt && k.expiresAt <= now;
    if (filter === 'active' && (k.status !== 'active' || isExpired)) return false;
    if (filter === 'disabled' && k.status !== 'disabled') return false;
    if (filter === 'expired' && !isExpired) return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      return k.key.toLowerCase().includes(q) || k.note.toLowerCase().includes(q);
    }
    return true;
  });

  const activeCount = keys.filter((k) => k.status === 'active' && (!k.expiresAt || k.expiresAt > now)).length;
  const disabledCount = keys.filter((k) => k.status === 'disabled').length;
  const expiredCount = keys.filter((k) => k.status === 'active' && Boolean(k.expiresAt && k.expiresAt <= now)).length;
  const totalLiveUsers = keys.reduce((sum, k) => sum + k.redeemedUsers.length, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm sm:p-6">
      <div className="flex h-full max-h-[92vh] w-full max-w-5xl flex-col rounded-2xl border border-[var(--color-edge)] bg-[var(--color-surface)] shadow-2xl">
        {/* Top Navbar */}
        <div className="flex flex-wrap items-center justify-between border-b border-[var(--color-line-soft)] px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="flex size-9 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
              <IconCrown size={20} />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold tracking-tight">Owner & Access Control Panel</h2>
                <span className="rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[0.6875rem] font-bold tracking-wide text-amber-400 uppercase">
                  Admin Exclusive
                </span>
              </div>
              <p className="text-xs text-[var(--color-ink-faint)]">
                Generate customer license keys, control bot permissions, and manage live sessions
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCreateModal(true)}
              className="btn btn-primary"
            >
              <IconPlus size={15} />
              <span>Generate Key(s)</span>
            </button>

            <button
              onClick={handleOpenSupabase}
              className="btn"
              title="Supabase Database Status & Sync"
            >
              <IconDatabase size={15} />
              <span className="hidden sm:inline">Supabase</span>
            </button>

            <button
              onClick={() => {
                setShowPasswordModal(true);
                setPasswordMsg(null);
              }}
              className="btn"
              title="Change Master Password"
            >
              <IconLock size={15} />
            </button>

            <button
              onClick={onClose}
              className="btn"
              title="Close Owner Panel"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Overview Stats Bar */}
        <div className="grid grid-cols-2 gap-3 border-b border-[var(--color-line-soft)] bg-[var(--color-surface-dim)] px-6 py-3 sm:grid-cols-5">
          <div className="leading-tight">
            <div className="text-xs text-[var(--color-ink-faint)]">Total Keys</div>
            <div className="font-mono text-base font-bold">{keys.length}</div>
          </div>
          <div className="leading-tight">
            <div className="text-xs text-[var(--color-good)]">Active Valid</div>
            <div className="font-mono text-base font-bold text-[var(--color-good)]">{activeCount}</div>
          </div>
          <div className="leading-tight">
            <div className="text-xs text-[var(--color-warn)]">Paused / Disabled</div>
            <div className="font-mono text-base font-bold text-[var(--color-warn)]">{disabledCount}</div>
          </div>
          <div className="leading-tight">
            <div className="text-xs text-[var(--color-bad)]">Expired</div>
            <div className="font-mono text-base font-bold text-[var(--color-bad)]">{expiredCount}</div>
          </div>
          <div className="leading-tight">
            <div className="text-xs text-cyan-400">Live Device Sessions</div>
            <div className="font-mono text-base font-bold text-cyan-400">{totalLiveUsers}</div>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--color-line-soft)] px-6 py-3">
          <div className="flex items-center gap-1.5 rounded-lg bg-[var(--color-surface-dim)] p-1">
            <button
              onClick={() => setFilter('all')}
              className={`rounded-md px-3 py-1 text-xs font-semibold ${
                filter === 'all'
                  ? 'bg-[var(--color-surface)] text-[var(--color-ink)] shadow-xs'
                  : 'text-[var(--color-ink-dim)]'
              }`}
            >
              All ({keys.length})
            </button>
            <button
              onClick={() => setFilter('active')}
              className={`rounded-md px-3 py-1 text-xs font-semibold ${
                filter === 'active'
                  ? 'bg-[var(--color-surface)] text-[var(--color-good)] shadow-xs'
                  : 'text-[var(--color-ink-dim)]'
              }`}
            >
              Active ({activeCount})
            </button>
            <button
              onClick={() => setFilter('disabled')}
              className={`rounded-md px-3 py-1 text-xs font-semibold ${
                filter === 'disabled'
                  ? 'bg-[var(--color-surface)] text-[var(--color-warn)] shadow-xs'
                  : 'text-[var(--color-ink-dim)]'
              }`}
            >
              Paused ({disabledCount})
            </button>
            <button
              onClick={() => setFilter('expired')}
              className={`rounded-md px-3 py-1 text-xs font-semibold ${
                filter === 'expired'
                  ? 'bg-[var(--color-surface)] text-[var(--color-bad)] shadow-xs'
                  : 'text-[var(--color-ink-dim)]'
              }`}
            >
              Expired ({expiredCount})
            </button>
          </div>

          <div className="relative min-w-[240px] flex-1 sm:max-w-xs">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search key code or note..."
              className="field py-1.5 pl-8 text-xs"
            />
            <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--color-ink-faint)]">
              <IconSearch size={14} />
            </span>
          </div>
        </div>

        {/* Keys List Container */}
        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="mb-4 rounded-lg bg-[var(--color-bad-soft)] p-3 text-xs font-medium text-[var(--color-bad)]">
              {error}
            </div>
          )}

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-center text-[var(--color-ink-faint)]">
              <IconRefresh size={28} className="animate-spin-slow" />
              <p className="mt-3 text-xs">Loading access keys...</p>
            </div>
          ) : filteredKeys.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[var(--color-line-soft)] py-16 text-center">
              <span className="flex size-12 items-center justify-center rounded-2xl bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)]">
                <IconKey size={24} />
              </span>
              <p className="mt-3 text-sm font-semibold">No access keys found</p>
              <p className="mt-1 text-xs text-[var(--color-ink-faint)]">
                {search ? 'Try adjusting your search or filter' : 'Generate your first code for customers or team members'}
              </p>
              <button
                onClick={() => setShowCreateModal(true)}
                className="btn btn-primary mt-4"
              >
                <IconPlus size={15} />
                Generate Key Now
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredKeys.map((k) => {
                const isExpired = Boolean(k.expiresAt && k.expiresAt <= now);
                const isPaused = k.status === 'disabled';
                const isExpanded = expandedKeyUsers === k.id;
                const directLink = getDirectLink(k.key);

                return (
                  <div
                    key={k.id}
                    className={`rounded-xl border transition-all ${
                      isPaused
                        ? 'border-amber-500/30 bg-amber-500/5'
                        : isExpired
                          ? 'border-red-500/30 bg-red-500/5'
                          : 'border-[var(--color-edge)] bg-[color-mix(in_oklab,var(--color-void)_40%,transparent)]'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                      {/* Left: Code, Note, Badges */}
                      <div className="flex flex-1 min-w-[280px] flex-col gap-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-base font-extrabold tracking-wider text-[var(--color-ink)]">
                            {k.key}
                          </span>

                          {/* Quick Copy Key */}
                          <button
                            onClick={() => handleCopy(k.key, k.id)}
                            className="btn py-1 px-2 text-[0.6875rem]"
                            title="Copy Key Code"
                          >
                            {copiedKey === k.id ? (
                              <>
                                <IconCheck size={12} className="text-[var(--color-good)]" />
                                <span className="text-[var(--color-good)] font-bold">Copied!</span>
                              </>
                            ) : (
                              <>
                                <IconCopy size={12} />
                                <span>Copy</span>
                              </>
                            )}
                          </button>

                          {/* Quick Copy Direct Join Link */}
                          <button
                            onClick={() => handleCopy(directLink, k.id, true)}
                            className="btn py-1 px-2 text-[0.6875rem]"
                            title="Copy 1-Click Direct Join Link (?key=...)"
                          >
                            {copiedLink === k.id ? (
                              <>
                                <IconCheck size={12} className="text-[var(--color-good)]" />
                                <span className="text-[var(--color-good)] font-bold">Link Copied!</span>
                              </>
                            ) : (
                              <>
                                <><IconLink size={12} /><span>Link</span></>
                              </>
                            )}
                          </button>

                          {/* Status Badge */}
                          {isPaused ? (
                            <span className="rounded-md bg-amber-500/20 px-2 py-0.5 text-[0.6875rem] font-bold text-amber-400">
                              Paused
                            </span>
                          ) : isExpired ? (
                            <span className="rounded-md bg-red-500/20 px-2 py-0.5 text-[0.6875rem] font-bold text-red-400">
                              Expired
                            </span>
                          ) : (
                            <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-[0.6875rem] font-bold text-emerald-400">
                              Active
                            </span>
                          )}
                        </div>

                        {/* Note & Meta Details */}
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[var(--color-ink-faint)]">
                          {k.note && (
                            <span className="font-semibold text-[var(--color-ink-dim)]">
                              <><IconEdit size={12} /> {k.note}</>
                            </span>
                          )}

                          {/* Bot Scope */}
                          <span>
                            <IconUsers size={12} />
                            {k.permissions.botScope === 'all' ? (
                              <strong className="text-[var(--color-ink)]">All Bots</strong>
                            ) : (
                              <strong className="text-cyan-400">
                                {k.permissions.assignedBotIds.length} Bot(s) Assigned
                              </strong>
                            )}
                          </span>

                          {/* Server restrictions */}
                          {(k.permissions.allowedGuildIds ?? []).length > 0 && (
                            <span>
                              <IconGlobe size={12} />
                              <strong className="text-[var(--color-warn)]">
                                {k.permissions.allowedGuildIds!.length} Server{k.permissions.allowedGuildIds!.length > 1 ? 's' : ''} Only
                              </strong>
                            </span>
                          )}

                          {/* Expiration Details */}
                          <span>
                            <IconClock size={12} />
                            {k.durationMs && !k.firstUsedAt ? (
                              <span className="text-amber-300">
                                {Math.round(k.durationMs / (3600 * 1000))}h (Starts on 1st use)
                              </span>
                            ) : k.expiresAt ? (
                              isExpired ? (
                                <span className="text-red-400">Expired</span>
                              ) : (
                                <span className="text-emerald-300">
                                  Expires in{' '}
                                  {Math.max(1, Math.round((k.expiresAt - now) / (3600 * 1000)))}h
                                </span>
                              )
                            ) : (
                              <span className="text-blue-300">Permanent (No Expiry)</span>
                            )}
                          </span>

                          {/* Users Limit */}
                          <span>
                            <><IconUsers size={12} /> Uses: {k.usedCount}</>
                            {k.maxUses !== null ? ` / ${k.maxUses} Max Devices` : ' (Unlimited)'}
                          </span>
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-1.5">
                        {/* Pause / Resume Button */}
                        <button
                          onClick={() => handleToggleStatus(k)}
                          className={`btn text-xs ${
                            isPaused ? 'text-[var(--color-good)]' : 'text-amber-400'
                          }`}
                          title={isPaused ? 'Enable Key' : 'Pause Key (instantly revokes user sessions)'}
                        >
                          {isPaused ? <IconPlay size={14} /> : <IconPause size={14} />}
                          <span className="hidden sm:inline">
                            {isPaused ? 'Resume' : 'Pause'}
                          </span>
                        </button>

                        {/* Connected Devices Dropdown Toggle */}
                        <button
                          onClick={() =>
                            setExpandedKeyUsers(isExpanded ? null : k.id)
                          }
                          className={`btn text-xs ${k.redeemedUsers.length > 0 ? 'border-cyan-500/40 text-cyan-400' : ''}`}
                          title="View connected user sessions and kick specific devices"
                        >
                          <IconUsers size={14} />
                          <span>{k.redeemedUsers.length} Devices</span>
                        </button>

                        {/* Edit Permissions Button */}
                        <button
                          onClick={() => setEditingKey(k)}
                          className="btn text-xs"
                          title="Edit Permissions & Assigned Bots"
                        >
                          <IconEdit size={14} />
                        </button>

                        {/* Revoke & Delete (Suprem) */}
                        <button
                          onClick={() => {
                            if (confirmingDelete === k.id) {
                              handleDeleteKey(k.id);
                              setConfirmingDelete(null);
                            } else {
                              setConfirmingDelete(k.id);
                            }
                          }}
                          onMouseLeave={() => setConfirmingDelete(null)}
                          className={`btn text-xs ${
                            confirmingDelete === k.id
                              ? 'bg-[var(--color-bad)] text-white border-transparent'
                              : 'text-[var(--color-bad)] hover:border-red-500/50 hover:bg-red-500/10'
                          }`}
                          title="Delete & Revoke Key (Suppression)"
                        >
                          <IconDelete size={14} />
                          <span className="hidden sm:inline">
                            {confirmingDelete === k.id ? 'Confirm?' : 'Revoke'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Expandable Connected Devices & Sessions Table */}
                    {isExpanded && (
                      <div className="border-t border-[var(--color-line-soft)] bg-black/20 p-4">
                        <div className="mb-2 flex items-center justify-between text-xs">
                          <span className="font-bold text-[var(--color-ink-dim)]">
                            Connected Devices / Redemptions for {k.key}
                          </span>
                          <span className="text-[var(--color-ink-faint)]">
                            Kicking a session disconnects that device immediately
                          </span>
                        </div>

                        {k.redeemedUsers.length === 0 ? (
                          <p className="text-xs text-[var(--color-ink-faint)] italic">
                            No devices have redeemed this key yet.
                          </p>
                        ) : (
                          <div className="flex flex-col gap-2">
                            {k.redeemedUsers.map((u) => (
                              <div
                                key={u.sessionId}
                                className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[var(--color-line-soft)] bg-[var(--color-surface)] p-2.5 text-xs"
                              >
                                <div className="flex flex-col gap-0.5 font-mono">
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-[var(--color-ink)]">
                                      IP: {u.ip}
                                    </span>
                                    <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                                      Session: {u.sessionId.slice(0, 8)}...
                                    </span>
                                  </div>
                                  <div className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                                    First joined: {new Date(u.redeemedAt).toLocaleDateString()} {new Date(u.redeemedAt).toLocaleTimeString()} • Last active: {new Date(u.lastActiveAt).toLocaleTimeString()}
                                  </div>
                                </div>

                                <button
                                  onClick={() => handleKickUser(k.id, u.sessionId)}
                                  className="btn py-1 px-2 text-[0.6875rem] text-[var(--color-bad)] hover:bg-red-500/10"
                                  title="Kick this user session"
                                >
                                  <IconUserX size={12} />
                                  Kick Device
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================= GENERATE KEY MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[var(--color-edge)] bg-[var(--color-surface)] p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[var(--color-line-soft)] pb-4">
              <div className="flex items-center gap-2.5">
                <span className="flex size-8 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
                  <IconKey size={18} />
                </span>
                <h3 className="text-base font-bold">Generate New Access Key(s)</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateKeys} className="mt-5 flex flex-col gap-5">
              {/* Quick Presets */}
              <div>
                <label className="label">1-Click Role Presets</label>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <button
                    type="button"
                    onClick={() => applyPreset('admin')}
                    className="btn flex-col items-center py-2 text-center"
                  >
                    <IconCrown size={15} className="text-amber-400" />
                    <span className="text-xs font-bold">Sub-Admin</span>
                    <span className="text-[0.625rem] text-[var(--color-ink-faint)]">All Bots & Fleet</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('voice_operator')}
                    className="btn flex-col items-center py-2 text-center"
                  >
                    <IconSpeaker size={15} className="text-cyan-400" />
                    <span className="text-xs font-bold">Voice Operator</span>
                    <span className="text-[0.625rem] text-[var(--color-ink-faint)]">Join/Leave/Mute</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('trial_user')}
                    className="btn flex-col items-center py-2 text-center"
                  >
                    <IconClock size={15} className="text-emerald-400" />
                    <span className="text-xs font-bold">24h Trial</span>
                    <span className="text-[0.625rem] text-[var(--color-ink-faint)]">Single Device</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPreset('radar_only')}
                    className="btn flex-col items-center py-2 text-center"
                  >
                    <IconShield size={15} className="text-purple-400" />
                    <span className="text-xs font-bold">Radar Only</span>
                    <span className="text-[0.625rem] text-[var(--color-ink-faint)]">Spectate Presence</span>
                  </button>
                </div>
              </div>

              {/* Code, Note, Bulk Count */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="sm:col-span-1">
                  <label className="label">Custom Code (Optional)</label>
                  <input
                    type="text"
                    value={newKeyCode}
                    onChange={(e) => setNewKeyCode(e.target.value.toUpperCase())}
                    placeholder="Auto GVC-..."
                    className="field font-mono text-xs uppercase"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="label">Note / Customer Name</label>
                  <input
                    type="text"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="e.g. VIP Member Ahmed"
                    className="field text-xs"
                  />
                </div>
                <div className="sm:col-span-1">
                  <label className="label">Quantity (Bulk)</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={newCount}
                    onChange={(e) => setNewCount(Math.max(1, Number(e.target.value)))}
                    className="field text-xs"
                  />
                </div>
              </div>

              {/* Duration / Expiration */}
              <div>
                <label className="label">Validity / Expiration</label>
                <div className="flex flex-wrap gap-2">
                  {(['permanent', '1h', '24h', '3d', '7d', '30d', 'custom'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setNewDurationType(type)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                        newDurationType === type
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)] border border-[var(--color-line-soft)]'
                      }`}
                    >
                      {type === 'permanent' ? 'Permanent' : type.toUpperCase()}
                    </button>
                  ))}
                </div>

                {newDurationType === 'custom' && (
                  <div className="mt-3 flex items-center gap-2">
                    <label className="text-xs text-[var(--color-ink-dim)]">Custom Hours:</label>
                    <input
                      type="number"
                      min={1}
                      value={customDurationHours}
                      onChange={(e) => setCustomDurationHours(Math.max(1, Number(e.target.value)))}
                      className="field w-24 py-1 text-xs"
                    />
                  </div>
                )}

                {newDurationType !== 'permanent' && (
                  <div className="mt-3 flex items-center gap-2">
                    <input
                      id="startsOnUse"
                      type="checkbox"
                      checked={newStartsOnUse}
                      onChange={(e) => setNewStartsOnUse(e.target.checked)}
                      className="rounded border-[var(--color-line-soft)]"
                    />
                    <label htmlFor="startsOnUse" className="text-xs text-[var(--color-ink-dim)]">
                      <strong>Countdown starts on first redemption</strong> (recommended for sold keys)
                    </label>
                  </div>
                )}
              </div>

              {/* Device / User Limit */}
              <div>
                <label className="label">Device / Redemptions Limit</label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setNewMaxUses(1)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                      newMaxUses === 1
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]'
                    }`}
                  >
                    1 Device (Single-User)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewMaxUses(5)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                      newMaxUses === 5
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]'
                    }`}
                  >
                    5 Devices (Team)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewMaxUses('')}
                    className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                      newMaxUses === ''
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]'
                    }`}
                  >
                    Unlimited
                  </button>
                </div>
              </div>

              {/* Bot Scope Selection */}
              <div className="rounded-xl border border-[var(--color-line-soft)] bg-[var(--color-surface-dim)] p-4">
                <label className="label mb-2">Bot Access Scope</label>
                <div className="flex items-center gap-4 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="botScope"
                      checked={newPermissions.botScope === 'all'}
                      onChange={() =>
                        setNewPermissions((prev) => ({
                          ...prev,
                          botScope: 'all',
                        }))
                      }
                    />
                    <span>All Connected Bots ({availableBots.length})</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="botScope"
                      checked={newPermissions.botScope === 'specific'}
                      onChange={() =>
                        setNewPermissions((prev) => ({
                          ...prev,
                          botScope: 'specific',
                        }))
                      }
                    />
                    <span>Specific Assigned Bots Only</span>
                  </label>
                </div>

                {newPermissions.botScope === 'specific' && (
                  <div className="mt-3">
                    <p className="mb-2 text-[0.6875rem] text-[var(--color-ink-faint)]">
                      Select which bots this key holder can view and control:
                    </p>
                    {availableBots.length === 0 ? (
                      <p className="text-xs text-amber-400 italic">No bots currently loaded in memory.</p>
                    ) : (
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 max-h-40 overflow-y-auto">
                        {availableBots.map((b) => {
                          const checked = newPermissions.assignedBotIds.includes(b.id);
                          return (
                            <label
                              key={b.id}
                              className={`flex items-center gap-2 rounded-lg border p-2 text-xs cursor-pointer ${
                                checked
                                  ? 'border-cyan-500/40 bg-cyan-500/10'
                                  : 'border-[var(--color-line-soft)] bg-[var(--color-surface)]'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={(e) => {
                                  const ids = e.target.checked
                                    ? [...newPermissions.assignedBotIds, b.id]
                                    : newPermissions.assignedBotIds.filter((id) => id !== b.id);
                                  setNewPermissions((prev) => ({
                                    ...prev,
                                    assignedBotIds: ids,
                                  }));
                                }}
                              />
                              <span className="font-semibold">{b.username}</span>
                              <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                                ({b.id.slice(0, 6)}...)
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Server (Guild) Restrictions */}
              <div>
                <label className="label">Allowed Servers</label>
                <p className="mb-2 text-[0.6875rem] text-[var(--color-ink-faint)]">
                  Paste Discord Server IDs (one per line) to restrict this key to specific servers only.
                  Leave empty to allow all servers.
                </p>
                <textarea
                  className="field min-h-[72px] font-mono text-xs resize-none"
                  placeholder={"000000000000000001\n000000000000000002"}
                  value={(newPermissions.allowedGuildIds ?? []).join("\n")}
                  onChange={(e) => {
                    const ids = e.target.value
                      .split(/[\n,; ]+/)
                      .map((s) => s.trim())
                      .filter((s) => /^\d{17,20}$/.test(s));
                    setNewPermissions((prev) => ({ ...prev, allowedGuildIds: ids }));
                  }}
                />
                {(newPermissions.allowedGuildIds ?? []).length > 0 && (
                  <p className="mt-1 text-[0.6875rem] text-[var(--color-good)]">
                    ✓ Restricted to {newPermissions.allowedGuildIds!.length} server{newPermissions.allowedGuildIds!.length > 1 ? 's' : ''}
                  </p>
                )}
              </div>

              {/* Granular Feature Checkboxes */}
              <div>
                <label className="label">Granular Permissions</label>
                <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-3">
                  {[
                    { key: 'canJoinVoice', label: 'Join Voice Channels' },
                    { key: 'canLeaveVoice', label: 'Leave Voice Channels' },
                    { key: 'canMuteDeaf', label: 'Toggle Mute & Deafen' },
                    { key: 'canUseAntiLeave', label: 'Anti-Leave Feature' },
                    { key: 'canUseAutoFollow', label: 'Auto-Follow Target' },
                    { key: 'canReconnectBots', label: 'Reconnect Bots' },
                    { key: 'canLeaveGuild', label: 'Leave Server (Kick Bot)' },
                    { key: 'canUseAutoReact', label: 'Auto-React Rules' },
                    { key: 'canUseSpammer', label: 'Message Spammer' },
                    { key: 'canViewRadar', label: 'Discord Radar Scanner' },
                    { key: 'canImportBots', label: 'Import New Bots' },
                    { key: 'canDeleteBots', label: 'Delete Bots' },
                    { key: 'canViewLogs', label: 'View System Logs' },
                  ].map((perm) => (
                    <label
                      key={perm.key}
                      className="flex items-center gap-2 rounded-lg border border-[var(--color-line-soft)] p-2"
                    >
                      <input
                        type="checkbox"
                        checked={Boolean(newPermissions[perm.key as keyof KeyPermissions])}
                        onChange={(e) =>
                          setNewPermissions((prev) => ({
                            ...prev,
                            [perm.key]: e.target.checked,
                          }))
                        }
                      />
                      <span>{perm.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-[var(--color-line-soft)] pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="btn"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="btn btn-primary"
                >
                  {creating ? (
                    <>
                      <IconRefresh size={14} className="animate-spin-slow" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <IconPlus size={14} />
                      Generate {newCount > 1 ? `${newCount} Keys` : 'Key'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= EDIT KEY MODAL */}
      {editingKey && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-[var(--color-edge)] bg-[var(--color-surface)] p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[var(--color-line-soft)] pb-4">
              <h3 className="text-base font-bold">Edit Key {editingKey.key}</h3>
              <button
                onClick={() => setEditingKey(null)}
                className="text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 flex flex-col gap-4">
              <div>
                <label className="label">Customer Note</label>
                <input
                  type="text"
                  value={editingKey.note}
                  onChange={(e) =>
                    setEditingKey({ ...editingKey, note: e.target.value })
                  }
                  className="field text-xs"
                />
              </div>

              {/* Bot Scope Selection for Existing Key */}
              <div className="rounded-xl border border-[var(--color-line-soft)] bg-[var(--color-surface-dim)] p-3">
                <label className="label mb-2">Bot Access Scope</label>
                <div className="flex items-center gap-4 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="editBotScope"
                      checked={editingKey.permissions.botScope === 'all'}
                      onChange={() =>
                        setEditingKey({
                          ...editingKey,
                          permissions: {
                            ...editingKey.permissions,
                            botScope: 'all',
                          },
                        })
                      }
                    />
                    <span>All Connected Bots</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="editBotScope"
                      checked={editingKey.permissions.botScope === 'specific'}
                      onChange={() =>
                        setEditingKey({
                          ...editingKey,
                          permissions: {
                            ...editingKey.permissions,
                            botScope: 'specific',
                          },
                        })
                      }
                    />
                    <span>Specific Bots</span>
                  </label>
                </div>

                {editingKey.permissions.botScope === 'specific' && (
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 max-h-40 overflow-y-auto">
                    {availableBots.map((b) => {
                      const checked = editingKey.permissions.assignedBotIds.includes(b.id);
                      return (
                        <label
                          key={b.id}
                          className="flex items-center gap-2 rounded-lg border border-[var(--color-line-soft)] p-2 text-xs"
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(e) => {
                              const ids = e.target.checked
                                ? [...editingKey.permissions.assignedBotIds, b.id]
                                : editingKey.permissions.assignedBotIds.filter((id) => id !== b.id);
                              setEditingKey({
                                ...editingKey,
                                permissions: {
                                  ...editingKey.permissions,
                                  assignedBotIds: ids,
                                },
                              });
                            }}
                          />
                          <span>{b.username}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Server Restrictions (edit modal) */}
              <div>
                <label className="label text-xs">Allowed Servers</label>
                <textarea
                  className="field min-h-[60px] font-mono text-xs resize-none"
                  placeholder={"000000000000000001\n000000000000000002 (empty = all servers)"}
                  value={(editingKey.permissions.allowedGuildIds ?? []).join("\n")}
                  onChange={(e) => {
                    const ids = e.target.value
                      .split(/[\n,; ]+/)
                      .map((s) => s.trim())
                      .filter((s) => /^\d{17,20}$/.test(s));
                    setEditingKey({
                      ...editingKey,
                      permissions: { ...editingKey.permissions, allowedGuildIds: ids },
                    });
                  }}
                />
                {(editingKey.permissions.allowedGuildIds ?? []).length > 0 && (
                  <p className="mt-1 text-[0.6875rem] text-[var(--color-good)]">
                    ✓ Restricted to {editingKey.permissions.allowedGuildIds!.length} server(s)
                  </p>
                )}
              </div>

              {/* Granular check boxes */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { key: 'canJoinVoice', label: 'Join Voice' },
                  { key: 'canLeaveVoice', label: 'Leave Voice' },
                  { key: 'canMuteDeaf', label: 'Mute & Deafen' },
                  { key: 'canUseAntiLeave', label: 'Anti-Leave' },
                  { key: 'canUseAutoFollow', label: 'Auto-Follow' },
                  { key: 'canReconnectBots', label: 'Reconnect Bots' },
                  { key: 'canLeaveGuild', label: 'Leave Server' },
                  { key: 'canUseAutoReact', label: 'Auto-React' },
                  { key: 'canUseSpammer', label: 'Spammer' },
                  { key: 'canViewRadar', label: 'Radar' },
                  { key: 'canImportBots', label: 'Import Bots' },
                  { key: 'canDeleteBots', label: 'Delete Bots' },
                  { key: 'canViewLogs', label: 'View Logs' },
                ].map((perm) => (
                  <label
                    key={perm.key}
                    className="flex items-center gap-2 rounded-lg border border-[var(--color-line-soft)] p-2"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(editingKey.permissions[perm.key as keyof KeyPermissions])}
                      onChange={(e) =>
                        setEditingKey({
                          ...editingKey,
                          permissions: {
                            ...editingKey.permissions,
                            [perm.key]: e.target.checked,
                          },
                        })
                      }
                    />
                    <span>{perm.label}</span>
                  </label>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-[var(--color-line-soft)] pt-4">
                <button
                  type="button"
                  onClick={() => setEditingKey(null)}
                  className="btn"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await api.owner.patchKey(editingKey.id, editingKey);
                    setKeys((prev) =>
                      prev.map((k) => (k.id === editingKey.id ? editingKey : k)),
                    );
                    setEditingKey(null);
                  }}
                  className="btn btn-primary"
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= CHANGE PASSWORD MODAL */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-2xl border border-[var(--color-edge)] bg-[var(--color-surface)] p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[var(--color-line-soft)] pb-4">
              <h3 className="text-base font-bold">Change Master Password</h3>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdatePassword} className="mt-4 flex flex-col gap-4">
              <div>
                <label className="label">New Owner Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new master password"
                  className="field"
                  autoFocus
                />
              </div>

              {passwordMsg && (
                <div
                  className={`rounded-md p-2.5 text-xs font-medium ${
                    passwordMsg.error
                      ? 'bg-[var(--color-bad-soft)] text-[var(--color-bad)]'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {passwordMsg.text}
                </div>
              )}

              <button type="submit" className="btn btn-primary w-full">
                Save New Password
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= SUPABASE MODAL */}
      {showSupabaseModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[var(--color-edge)] bg-[var(--color-surface)] p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[var(--color-line-soft)] pb-4">
              <div className="flex items-center gap-2">
                <IconDatabase size={18} className="text-emerald-400" />
                <h3 className="text-base font-bold">Supabase PostgreSQL Integration</h3>
              </div>
              <button
                onClick={() => setShowSupabaseModal(false)}
                className="text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 flex flex-col gap-4 text-xs">
              <div className="rounded-xl border border-[var(--color-line-soft)] bg-[var(--color-surface-dim)] p-4">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[var(--color-ink)]">Connection Status:</span>
                  <span
                    className={`rounded-md px-2.5 py-1 font-bold ${
                      supabaseStatus?.tableReady
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : supabaseStatus?.configured
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-[var(--color-surface)] text-[var(--color-ink-faint)]'
                    }`}
                  >
                    {supabaseStatus?.tableReady
                      ? 'Connected & Active'
                      : supabaseStatus?.configured
                        ? 'Connected (Table Missing)'
                        : 'Not Configured (Using Local AES-256)'}
                  </span>
                </div>
                <p className="mt-2 text-[var(--color-ink-faint)]">
                  {supabaseStatus?.message}
                </p>

                {supabaseStatus?.tableReady && (
                  <div className="mt-3 border-t border-[var(--color-line-soft)] pt-3">
                    <button
                      onClick={handleSyncSupabase}
                      disabled={syncingSupabase}
                      className="btn btn-primary"
                    >
                      {syncingSupabase ? (
                        <>
                          <IconRefresh size={14} className="animate-spin-slow" />
                          Syncing...
                        </>
                      ) : (
                        <>
                          <IconRefresh size={14} />
                          Sync All {keys.length} Keys to Supabase Now
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="label">Supabase Database SQL Schema</label>
                  <button
                    onClick={() => {
                      if (supabaseStatus?.schemaSql) {
                        navigator.clipboard.writeText(supabaseStatus.schemaSql);
                        setCopiedSql(true);
                        setTimeout(() => setCopiedSql(false), 2000);
                      }
                    }}
                    className="btn py-1 px-2 text-[0.6875rem]"
                  >
                    {copiedSql ? (
                      <span className="text-[var(--color-good)] font-bold">Copied SQL!</span>
                    ) : (
                      <>
                        <IconCopy size={12} />
                        <span>Copy Schema</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="mt-1.5 max-h-52 overflow-x-auto rounded-lg border border-[var(--color-line-soft)] bg-black/40 p-3 font-mono text-[0.6875rem] text-[var(--color-ink-dim)]">
                  {supabaseStatus?.schemaSql}
                </pre>
                <p className="mt-2 text-[var(--color-ink-faint)]">
                  Run this query inside your <strong>Supabase Dashboard &gt; SQL Editor</strong>. Once the table exists, add <code className="font-mono text-cyan-400">SUPABASE_URL</code> and <code className="font-mono text-cyan-400">SUPABASE_KEY</code> to your environment.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
