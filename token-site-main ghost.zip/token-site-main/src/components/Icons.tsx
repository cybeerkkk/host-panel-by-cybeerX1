/**
 * Hand-rolled SVG icon set.
 *
 * Replaces both lucide-react and every emoji the old UI used as an icon.
 * All strokes inherit `currentColor` and scale from a 24-unit grid, so they
 * stay razor sharp at any zoom or pixel density.
 */
import type { SVGProps } from 'react';

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Icon({ size = 16, children, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const IconShield = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 3 5 6v5.5c0 4.3 2.9 8.3 7 9.5 4.1-1.2 7-5.2 7-9.5V6l-7-3Z" />
    <path d="m9 12 2 2 4-4" />
  </Icon>
);

export const IconShieldOff = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 3 5 6v5.5c0 4.3 2.9 8.3 7 9.5 4.1-1.2 7-5.2 7-9.5V6l-7-3Z" />
    <path d="m4 4 16 16" />
  </Icon>
);

export const IconMic = (p: IconProps) => (
  <Icon {...p}>
    <rect x="9" y="2.5" width="6" height="11" rx="3" />
    <path d="M5.5 11a6.5 6.5 0 0 0 13 0" />
    <path d="M12 17.5V21" />
  </Icon>
);

export const IconMicOff = (p: IconProps) => (
  <Icon {...p}>
    <path d="M15 5.5A3 3 0 0 0 9 5.5v3M9 11.5v.5a3 3 0 0 0 4.5 2.6" />
    <path d="M5.5 11a6.5 6.5 0 0 0 10.2 5.3M18.5 11v.5" />
    <path d="M12 17.5V21" />
    <path d="m3.5 3.5 17 17" />
  </Icon>
);

export const IconSpeaker = (p: IconProps) => (
  <Icon {...p}>
    <path d="M11 5 6.5 8.5H3.5v7h3L11 19V5Z" />
    <path d="M15 9.5a3.5 3.5 0 0 1 0 5" />
    <path d="M17.8 6.8a7.2 7.2 0 0 1 0 10.4" />
  </Icon>
);

export const IconSpeakerOff = (p: IconProps) => (
  <Icon {...p}>
    <path d="M11 5 6.5 8.5H3.5v7h3L11 19V5Z" />
    <path d="m16 9.5 5 5M21 9.5l-5 5" />
  </Icon>
);

export const IconExit = (p: IconProps) => (
  <Icon {...p}>
    <path d="M14.5 4.5h3a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-3" />
    <path d="M10 8.5 6.5 12 10 15.5" />
    <path d="M6.5 12h8" />
  </Icon>
);

export const IconPlus = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);

export const IconTrash = (p: IconProps) => (
  <Icon {...p}>
    <path d="M4.5 6.5h15" />
    <path d="M9 6.5V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v1.5" />
    <path d="M6.5 6.5 7.4 19a1.5 1.5 0 0 0 1.5 1.4h6.2a1.5 1.5 0 0 0 1.5-1.4l.9-12.5" />
    <path d="M10.5 10.5v6M13.5 10.5v6" />
  </Icon>
);

export const IconTerminal = (p: IconProps) => (
  <Icon {...p}>
    <rect x="2.5" y="4" width="19" height="16" rx="2.5" />
    <path d="m7 10 2.5 2L7 14" />
    <path d="M12.5 14.5H17" />
  </Icon>
);

export const IconSearch = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="m15.5 15.5 4.5 4.5" />
  </Icon>
);

export const IconUsers = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="9" cy="8" r="3.5" />
    <path d="M3 19.5a6 6 0 0 1 12 0" />
    <path d="M16 5.2a3.5 3.5 0 0 1 0 6.6" />
    <path d="M17.5 14.4a6 6 0 0 1 3.5 5.1" />
  </Icon>
);

export const IconRefresh = (p: IconProps) => (
  <Icon {...p}>
    <path d="M20 12a8 8 0 1 1-2.5-5.8" />
    <path d="M20 4v4.5h-4.5" />
  </Icon>
);

export const IconSave = (p: IconProps) => (
  <Icon {...p}>
    <path d="M5.5 4.5h10L19.5 8.5v11a1 1 0 0 1-1 1h-13a1 1 0 0 1-1-1v-14a1 1 0 0 1 1-1Z" />
    <path d="M8.5 4.5v5h6v-5" />
    <path d="M8 20.5v-6h8v6" />
  </Icon>
);

export const IconCheck = (p: IconProps) => (
  <Icon {...p}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </Icon>
);

export const IconCheckSquare = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="3.5" />
    <path d="m8 12 2.8 2.8L16.5 9" />
  </Icon>
);

export const IconSquare = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="3.5" />
  </Icon>
);

export const IconAlert = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5v5" />
    <path d="M12 16h.01" />
  </Icon>
);

export const IconWave = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3 12h2M7.5 8v8M12 4.5v15M16.5 8v8M21 12h-2" />
  </Icon>
);

export const IconBolt = (p: IconProps) => (
  <Icon {...p}>
    <path d="m13.5 2.5-9 11h6l-.5 8 9-11h-6l.5-8Z" />
  </Icon>
);

export const IconBomb = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="14" r="7" />
    <path d="m14.5 7.5 2-2 2 2" />
    <path d="M12 7V5a2 2 0 0 1 2-2" />
    <path d="m19 4 1-1M20.5 7h1" />
  </Icon>
);

export const IconMonitor = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3" y="4" width="18" height="13" rx="2" />
    <path d="M8 21h8M12 17v4" />
  </Icon>
);

export const IconHome = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3.5 11 12 4l8.5 7" />
    <path d="M5.5 9.5V19a1 1 0 0 0 1 1H10v-5h4v5h3.5a1 1 0 0 0 1-1V9.5" />
  </Icon>
);

export const IconRadar = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" opacity="0.45" />
    <circle cx="12" cy="12" r="5" opacity="0.7" />
    <circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
    <path d="M12 12 18 7" />
  </Icon>
);

export const IconLock = (p: IconProps) => (
  <Icon {...p}>
    <rect x="4.5" y="10" width="15" height="10.5" rx="2.5" />
    <path d="M8 10V7.5a4 4 0 0 1 8 0V10" />
    <path d="M12 14v3" />
  </Icon>
);

export const IconLink = (p: IconProps) => (
  <Icon {...p}>
    <path d="M10 13.5a4 4 0 0 0 5.7 0l2.8-2.8a4 4 0 0 0-5.7-5.7L11.5 6.4" />
    <path d="M14 10.5a4 4 0 0 0-5.7 0l-2.8 2.8a4 4 0 0 0 5.7 5.7l1.3-1.3" />
  </Icon>
);

export const IconGlobe = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M3.5 12h17" />
    <path d="M12 3.5c2.2 2.4 3.4 5.4 3.4 8.5S14.2 18.1 12 20.5c-2.2-2.4-3.4-5.4-3.4-8.5S9.8 5.9 12 3.5Z" />
  </Icon>
);

export const IconPower = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 4v8" />
    <path d="M7.2 6.8a7 7 0 1 0 9.6 0" />
  </Icon>
);

export const IconClock = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 1.8" />
  </Icon>
);

export const IconPulse = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3 12.5h3.5L9 6l3.5 12 2.4-5.5H21" />
  </Icon>
);

export const IconKey = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="7.5" cy="15.5" r="4.5" />
    <path d="m11 12 8.5-8.5" />
    <path d="m15.5 7.5 2 2" />
    <path d="m17.5 5.5 2 2" />
  </Icon>
);

export const IconCrown = (p: IconProps) => (
  <Icon {...p}>
    <path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7Z" />
    <path d="M4 18h16v2H4z" />
  </Icon>
);

export const IconCopy = (p: IconProps) => (
  <Icon {...p}>
    <rect width="13" height="13" x="8.5" y="8.5" rx="2" ry="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </Icon>
);

export const IconDatabase = (p: IconProps) => (
  <Icon {...p}>
    <ellipse cx="12" cy="5" rx="9" ry="3" />
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
    <path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3" />
  </Icon>
);

export const IconDelete = IconTrash;

export const IconEdit = (p: IconProps) => (
  <Icon {...p}>
    <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
    <path d="m15 5 4 4" />
  </Icon>
);

export const IconPause = (p: IconProps) => (
  <Icon {...p}>
    <rect x="6" y="4" width="4" height="16" rx="1" />
    <rect x="14" y="4" width="4" height="16" rx="1" />
  </Icon>
);

export const IconPlay = (p: IconProps) => (
  <Icon {...p}>
    <polygon points="5 3 19 12 5 21 5 3" />
  </Icon>
);

export const IconMessage = (p: IconProps) => (
  <Icon {...p}>
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </Icon>
);

export const IconStop = (p: IconProps) => (
  <Icon {...p}>
    <rect x="4.5" y="4.5" width="15" height="15" rx="2" fill="currentColor" stroke="none" />
  </Icon>
);

export const IconSend = (p: IconProps) => (
  <Icon {...p}>
    <path d="M22 2 11 13" />
    <path d="M22 2 15 22 11 13 2 9l20-7Z" />
  </Icon>
);

export const IconLoop = (p: IconProps) => (
  <Icon {...p}>
    <path d="M17 1 21 5l-4 4" />
    <path d="M3 11V9a4 4 0 0 1 4-4h14" />
    <path d="M7 23l-4-4 4-4" />
    <path d="M21 13v2a4 4 0 0 1-4 4H3" />
  </Icon>
);

export const IconTarget = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="5" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
  </Icon>
);

export const IconUserX = (p: IconProps) => (
  <Icon {...p}>
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <line x1="17" y1="8" x2="22" y2="13" />
    <line x1="22" y1="8" x2="17" y2="13" />
  </Icon>
);

/** Animated brand mark. The sweep is the only moving part. */
export function BrandMark({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="bm-fill" x1="6" y1="4" x2="42" y2="44" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--color-accent)" />
          <stop offset="1" stopColor="var(--color-accent-2)" />
        </linearGradient>
        <radialGradient id="bm-sweep" cx="0.5" cy="0.5" r="0.5">
          <stop stopColor="var(--color-accent)" stopOpacity="0.55" />
          <stop offset="1" stopColor="var(--color-accent)" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx="24" cy="24" r="21" stroke="var(--color-edge-bright)" strokeWidth="1" />
      <circle cx="24" cy="24" r="14" stroke="var(--color-edge-bright)" strokeWidth="1" opacity="0.7" />

      <g className="animate-radar" style={{ transformOrigin: '24px 24px' }}>
        <path d="M24 24 L24 3 A21 21 0 0 1 41 13 Z" fill="url(#bm-sweep)" />
      </g>

      <path
        d="M24 13a5 5 0 0 0-5 5v5a5 5 0 0 0 10 0v-5a5 5 0 0 0-5-5Z"
        fill="url(#bm-fill)"
      />
      <path
        d="M16 22.5V24a8 8 0 0 0 16 0v-1.5"
        stroke="url(#bm-fill)"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path d="M24 32v4" stroke="url(#bm-fill)" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
