import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { api, ApiError } from '../lib/api';
import { RankBadge, rankCardStyle, sortGuilds, useGuildRanks } from './GuildRank';
import type { PublicProfile, MonitorMemberRoleDetails, MonitorGuildRoleInfo, MonitorMemberSearchResult } from '../lib/api';
import {
  IconClock,
  IconGlobe,
  IconLock,
  IconMic,
  IconMicOff,
  IconRefresh,
  IconSearch,
  IconShield,
  IconSpeaker,
  IconUsers,
} from './Icons';

type TierKey = 'owner' | 'administrator' | 'admin' | 'member';
type MemberRole = MonitorMemberRoleDetails['roles'][number];

const TIERS: Record<TierKey, { label: string; level: number; tone: string }> = {
  owner: { label: 'Owner', level: 5, tone: 'bg-[color-mix(in_oklab,var(--color-accent)_16%,transparent)] text-[var(--color-accent)] border-[color-mix(in_oklab,var(--color-accent)_35%,transparent)]' },
  administrator: { label: 'Administrator', level: 4, tone: 'bg-[color-mix(in_oklab,var(--color-accent-2)_18%,transparent)] text-[var(--color-accent-2)] border-[color-mix(in_oklab,var(--color-accent-2)_35%,transparent)]' },
  admin: { label: 'Admin', level: 3, tone: 'bg-[color-mix(in_oklab,var(--color-good)_15%,transparent)] text-[var(--color-good)] border-[color-mix(in_oklab,var(--color-good)_35%,transparent)]' },
  member: { label: 'Member', level: 1, tone: 'bg-[color-mix(in_oklab,var(--color-ink-dim)_14%,transparent)] text-[var(--color-ink-dim)] border-[var(--color-edge)]' },
};

function getRoleTierKey(role: MemberRole): TierKey {
  if (role.administrator) return 'administrator';
  if (role.elevated) return 'admin';
  return 'member';
}
function getRoleTier(role: MemberRole) { return TIERS[getRoleTierKey(role)]; }
function getMemberRank(roles: MemberRole[], isOwner: boolean) {
  if (isOwner) return TIERS.owner;
  return roles.reduce<(typeof TIERS)[TierKey]>(
    (best, role) => { const t = getRoleTier(role); return t.level > best.level ? t : best; },
    TIERS.member,
  );
}

// One shared in-flight/result cache so reopening a server or double renders
// never fire a second request (the public API is rate limited per IP).
const reqCache = new Map<string, { at: number; p: Promise<any> }>();
function cachedFetch<T>(key: string, fn: () => Promise<T>, force = false): Promise<T> {
  const hit = reqCache.get(key);
  if (!force && hit && Date.now() - hit.at < 60_000) return hit.p;
  const p = fn();
  reqCache.set(key, { at: Date.now(), p });
  p.catch(() => { if (reqCache.get(key)?.p === p) reqCache.delete(key); });
  return p;
}

export function PublicUserInfo({ onGetAccess }: { onGetAccess: () => void }) {
  const [value, setValue] = useState('');
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [avatarFailed, setAvatarFailed] = useState(false);

  // Username search suggestions
  const [searchResults, setSearchResults] = useState<MonitorMemberSearchResult[]>([]);
  const [searchBusy, setSearchBusy] = useState(false);

  // Guild modal state
  const [selectedGuildId, setSelectedGuildId] = useState<string | null>(null);
  const [memberRoles, setMemberRoles] = useState<MonitorMemberRoleDetails | null>(null);
  const [guildRoles, setGuildRoles] = useState<MonitorGuildRoleInfo[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [loadingGuild, setLoadingGuild] = useState(false);
  const [rolesError, setRolesError] = useState('');
  const [guildRolesError, setGuildRolesError] = useState('');
  const [detailsAttempt, setDetailsAttempt] = useState(0);

  const trimmed = value.trim();
  const validId = /^\d{17,20}$/.test(trimmed);
  const validUsername = !validId && trimmed.length >= 2 && trimmed.length <= 32;
  const valid = validId || validUsername;

  const loadProfile = async (userId: string, preferGuildId?: string | null) => {
    setBusy(true);
    setError('');
    setProfile(null);
    setAvatarFailed(false);
    setSelectedGuildId(null);
    setSearchResults([]);
    try {
      const p = await api.publicUser(userId);
      setProfile(p);
      // Auto-open guild modal when coming from a search result
      if (preferGuildId && p.mutualGuilds.some((g) => g.id === preferGuildId)) {
        setSelectedGuildId(preferGuildId);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not reach the server');
    } finally {
      setBusy(false);
    }
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!valid || busy) return;
    if (validId) {
      await loadProfile(trimmed);
      return;
    }
    // Username search
    setSearchBusy(true);
    setError('');
    setProfile(null);
    setSearchResults([]);
    try {
      const results = await api.publicSearch(trimmed);
      if (results.length === 0) {
        setError('No matching members found in any connected server.');
      } else if (results.length === 1) {
        // Single match — load profile directly
        await loadProfile(results[0].userId, results[0].guildId);
      } else {
        setSearchResults(results);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not reach the server');
    } finally {
      setSearchBusy(false);
    }
  };

  // Load roles when a guild is selected
  useEffect(() => {
    if (!selectedGuildId || !profile) {
      setMemberRoles(null);
      setGuildRoles([]);
      setRolesError('');
      setGuildRolesError('');
      setLoadingGuild(false);
      return;
    }
    let cancelled = false;
    setLoadingGuild(true);
    setMemberRoles(null);
    setGuildRoles([]);
    setRolesError('');
    setGuildRolesError('');

    const guildId = selectedGuildId;
    const userId = profile.userId;
    (async () => {
      try {
        const d = await cachedFetch(`m:${guildId}:${userId}`, () => api.publicMemberRoles(guildId, userId), detailsAttempt > 0);
        if (!cancelled) setMemberRoles(d);
      } catch (e) {
        if (!cancelled) setRolesError(e instanceof ApiError ? e.message : 'Could not load member roles');
      }
      if (cancelled) return;
      try {
        const d = await cachedFetch(`g:${guildId}`, () => api.publicGuildRoles(guildId), detailsAttempt > 0);
        if (!cancelled) setGuildRoles(d.roles ?? []);
      } catch (e) {
        if (!cancelled) setGuildRolesError(e instanceof ApiError ? e.message : 'Could not load role permissions');
      }
      if (!cancelled) setLoadingGuild(false);
    })();

    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedGuildId, profile?.userId, detailsAttempt]);

  // Auto-select top role
  useEffect(() => {
    if (!memberRoles) { setSelectedRoleId(null); return; }
    setSelectedRoleId((cur) =>
      memberRoles.roles.some((r) => r.id === cur)
        ? cur
        : [...memberRoles.roles].sort((a, b) => getRoleTier(b).level - getRoleTier(a).level || b.position - a.position)[0]?.id ?? null,
    );
  }, [memberRoles]);

  // Close modal on Escape
  useEffect(() => {
    if (!selectedGuildId) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setSelectedGuildId(null); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [selectedGuildId]);

  const created = profile
    ? new Date(profile.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
    : null;

  const ranks = useGuildRanks(profile?.userId, api.publicUserRanks);
  const mutualGuilds = profile?.mutualGuilds ?? [];
  const selectedGuild = mutualGuilds.find((g) => g.id === selectedGuildId);
  const selectedRole = memberRoles?.roles.find((r) => r.id === selectedRoleId) ?? null;
  const selectedRoleInfo = guildRoles.find((r) => r.id === selectedRoleId);

  return (
    <div className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 sm:px-8 sm:py-12">
      {/* Header */}
      <div className="mb-2 inline-flex items-center gap-2 text-[0.6875rem] font-bold uppercase tracking-[0.14em] text-[var(--color-accent)]">
        <span className="size-1.5 rounded-full bg-[var(--color-accent)]" style={{ boxShadow: '0 0 6px var(--color-accent)' }} />
        Free lookup
      </div>
      <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">User Info</h1>
      <p className="mt-3 max-w-xl text-sm text-[var(--color-ink-dim)]">
        Search by Discord user ID or username. No key needed.
      </p>

      {/* Search */}
      <form onSubmit={submit} className="mt-6">
        <div className="flex items-center overflow-hidden rounded-2xl border border-[var(--color-edge-bright)] bg-[color-mix(in_oklab,var(--color-void)_75%,transparent)] transition-all focus-within:border-[color-mix(in_oklab,var(--color-accent)_55%,transparent)] focus-within:shadow-[0_0_0_3px_color-mix(in_oklab,var(--color-accent)_12%,transparent)]">
          <span className="select-none pl-4 pr-1 font-mono text-base font-bold text-[var(--color-ink-faint)]">
            {validId ? '#' : <IconSearch size={15} />}
          </span>
          <input
            autoComplete="off"
            value={value}
            onChange={(e) => {
              setValue(e.target.value.replace(/\s/g, ''));
              setSearchResults([]);
              setError('');
            }}
            placeholder="Discord user ID or username"
            className="min-w-0 flex-1 bg-transparent py-3.5 pr-2 font-mono text-sm text-[var(--color-ink)] placeholder:text-[var(--color-ink-faint)] focus:outline-none"
          />
          <button
            type="submit"
            disabled={!valid || busy || searchBusy}
            className="m-1.5 flex shrink-0 items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-bold text-[#04121a] transition-all disabled:opacity-40"
            style={{ background: 'var(--color-accent)', boxShadow: '0 2px 14px -4px color-mix(in oklab, var(--color-accent) 55%, transparent)' }}
          >
            {(busy || searchBusy) ? <IconRefresh size={14} className="animate-spin-slow" /> : <IconSearch size={14} />}
            <span className="hidden sm:inline">{(busy || searchBusy) ? 'Searching…' : 'Search'}</span>
          </button>
        </div>
        {value && !valid && (
          <p className="mt-2 text-[0.6875rem] text-[var(--color-ink-faint)]">Enter a user ID (17-20 digits) or a username (2+ characters).</p>
        )}
        {error && (
          <div className="animate-rise mt-3 rounded-xl bg-[var(--color-bad-soft)] px-3 py-2 text-xs font-medium text-[var(--color-bad)]">
            {error}
          </div>
        )}
        {/* Username search results */}
        {searchResults.length > 0 && (
          <div className="animate-rise mt-3 flex max-h-72 flex-col gap-1.5 overflow-y-auto rounded-2xl border border-[var(--color-edge-bright)] bg-[color-mix(in_oklab,var(--color-void)_80%,transparent)] p-2">
            <p className="px-2 pt-1 text-[0.6875rem] font-bold uppercase tracking-wider text-[var(--color-accent)]">
              {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} — pick one
            </p>
            {searchResults.map((r) => (
              <button
                key={`${r.userId}:${r.guildId}`}
                type="button"
                onClick={() => { setValue(r.userId); void loadProfile(r.userId, r.guildId); }}
                className="flex items-center gap-3 rounded-xl border border-[var(--color-edge)] bg-[var(--color-void)]/30 p-2.5 text-left transition-all hover:border-[color-mix(in_oklab,var(--color-accent)_45%,var(--color-edge))] hover:bg-[var(--color-surface-dim)]"
              >
                {r.avatarUrl ? (
                  <img src={r.avatarUrl} alt="" className="size-9 shrink-0 rounded-full object-cover" />
                ) : (
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[var(--color-surface)] text-[10px] font-bold text-[var(--color-accent)]">
                    {r.username.slice(0, 2).toUpperCase()}
                  </span>
                )}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold text-[var(--color-ink)]">
                    {r.nickname ?? r.globalName ?? r.username}
                  </span>
                  <span className="mt-0.5 block truncate text-[10px] text-[var(--color-ink-faint)]">
                    @{r.username}
                    {r.guildName ? <span className="ml-2 text-[var(--color-ink-dim)]">· {r.guildName}</span> : null}
                  </span>
                </span>
                {r.guildIconUrl && (
                  <img src={r.guildIconUrl} alt="" className="size-7 shrink-0 rounded-lg object-cover opacity-70" />
                )}
              </button>
            ))}
          </div>
        )}
      </form>

      {/* Profile card */}
      {profile && (
        <div className="animate-rise panel mt-6 overflow-hidden">
          {/* Banner */}
          <div
            className="relative h-28 sm:h-40"
            style={{
              background: profile.bannerUrl
                ? `center/cover no-repeat url(${JSON.stringify(profile.bannerUrl)})`
                : `linear-gradient(120deg, ${profile.accentColor ?? 'var(--color-accent)'}33, var(--color-accent-2)22)`,
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-panel)] via-[var(--color-panel)]/25 to-transparent" />
            <div className="absolute right-4 top-4 flex items-center gap-2 rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-[10px] font-semibold text-white/80 backdrop-blur">
              <span className={`size-1.5 rounded-full ${profile.inVoice ? 'bg-[var(--color-good)]' : 'bg-white/35'}`} />
              {profile.isBot ? 'Bot info' : profile.inVoice ? 'Active in voice' : 'User info'}
            </div>
          </div>

          <div className="relative px-5 pb-6 sm:px-7">
            {/* Avatar */}
            <div className="absolute -top-12 left-5 sm:-top-14 sm:left-7">
              {profile.avatarUrl && !avatarFailed ? (
                <img
                  src={profile.avatarUrl}
                  alt=""
                  onError={() => setAvatarFailed(true)}
                  className="size-24 rounded-[1.6rem] border-4 border-[var(--color-panel)] bg-[var(--color-panel)] object-cover shadow-xl shadow-black/30 sm:size-28"
                />
              ) : (
                <div className="flex size-24 items-center justify-center rounded-[1.6rem] border-4 border-[var(--color-panel)] bg-[var(--color-panel-2)] font-mono text-2xl font-bold text-[var(--color-accent)] sm:size-28">
                  {profile.username.slice(0, 2).toUpperCase()}
                </div>
              )}
            </div>

            {/* Name + stats */}
            <div className="flex flex-col gap-4 pt-7 sm:flex-row sm:items-end sm:justify-between sm:pt-8">
              <div className="min-w-0 pt-12 sm:pt-8">
                <p className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--color-accent)]">
                  {profile.isBot ? 'Bot info' : 'User info'}
                  {profile.isBot && (
                  <span className="inline-flex items-center rounded-md bg-[#5865F2] px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                    {profile.isVerifiedBot ? '✓ BOT' : 'BOT'}
                  </span>
                  )}
                </p>
                <h2 className="truncate text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
                  {profile.globalName || profile.username}
                </h2>
                <p className="mt-1 truncate text-sm text-[var(--color-ink-dim)]">
                  @{profile.username}
                  <span className="mx-2 text-[var(--color-edge-bright)]">/</span>
                  <span className="font-mono text-xs text-[var(--color-ink-faint)]">{profile.userId}</span>
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:min-w-64">
                <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 px-3 py-2.5">
                  <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Shared servers</p>
                  <p className="mt-1 text-lg font-bold text-[var(--color-ink)]">{mutualGuilds.length}</p>
                </div>
                <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 px-3 py-2.5">
                  <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">{profile.isBot ? 'Bot created' : 'Account created'}</p>
                  <p className="mt-1 truncate text-sm font-bold text-[var(--color-ink)]">{created ?? 'Unknown'}</p>
                </div>
              </div>
            </div>

            {/* Bio */}
            {profile.bio && (
              <div className="mt-4">
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-[var(--color-ink-dim)]">About Me</h4>
                <p className="whitespace-pre-wrap rounded-lg bg-[color-mix(in_oklab,var(--color-void)_30%,transparent)] p-3 text-sm leading-relaxed text-[var(--color-ink)]">
                  {profile.bio}
                </p>
              </div>
            )}

            {/* Badges */}
            {(profile.badges?.length ?? 0) > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {(profile.badges ?? []).map((badge) => (
                  <span key={badge} className="chip border-[var(--color-edge-bright)] bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]">
                    <IconShield size={12} />
                    {badge.replaceAll('_', ' ').toLowerCase()}
                  </span>
                ))}
              </div>
            )}

            {/* Voice presence — not shown for bots */}
            {!profile.isBot && (
              <div
                className="mt-4 flex items-start gap-3 rounded-xl border p-4"
                style={
                  profile.inVoice
                    ? { borderColor: 'color-mix(in oklab, var(--color-good) 38%, transparent)', background: 'color-mix(in oklab, var(--color-good) 9%, transparent)' }
                    : { borderColor: 'var(--color-edge)' }
                }
              >
                <span className="mt-0.5 shrink-0" style={{ color: profile.inVoice ? 'var(--color-good)' : 'var(--color-ink-faint)' }}>
                  <IconSpeaker size={17} />
                </span>
                {profile.inVoice ? (
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[var(--color-good)]">
                      In voice · {profile.voiceChannelName ?? profile.voiceChannelId}
                    </p>
                    <p className="mt-0.5 truncate text-xs text-[var(--color-ink-dim)]">
                      {profile.voiceGuildName}
                      {profile.voiceMemberCount > 0 && ` · ${profile.voiceMemberCount} connected`}
                    </p>
                    {(profile.voiceSelfMute || profile.voiceSelfDeaf) && (
                      <p className="mt-1 flex gap-2 text-[0.6875rem] text-[var(--color-warn)]">
                        {profile.voiceSelfMute && <span className="inline-flex items-center gap-1"><IconMicOff size={12} /> Muted</span>}
                        {profile.voiceSelfDeaf && <span className="inline-flex items-center gap-1"><IconSpeaker size={12} /> Deafened</span>}
                      </p>
                    )}
                  </div>
                ) : (
                  <div>
                    <p className="text-sm font-semibold text-[var(--color-ink-dim)]">Not in voice</p>
                    <p className="mt-0.5 text-xs text-[var(--color-ink-faint)]">
                      Only servers your accounts share with them can be checked.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Mutual servers grid */}
            {mutualGuilds.length > 0 && (
              <section className="mt-7 border-t border-[var(--color-edge)] pt-5">
                <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--color-accent)]">Network</p>
                    <h4 className="mt-1 text-base font-bold text-[var(--color-ink)]">Mutual servers</h4>
                  </div>
                  <span className="rounded-full border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-1 text-xs font-semibold text-[var(--color-ink-dim)]">
                    {mutualGuilds.length} shared
                  </span>
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {sortGuilds(mutualGuilds, ranks).map((guild) => (
                    <button
                      key={guild.id}
                      style={rankCardStyle(ranks[guild.id])}
                      type="button"
                      onClick={() => setSelectedGuildId(guild.id)}
                      className="group flex min-w-0 items-center gap-3 rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/30 p-3 text-left transition-all cursor-pointer hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--color-accent)_45%,var(--color-edge))] hover:bg-[var(--color-surface-dim)]"
                    >
                      {guild.iconUrl ? (
                        <img src={guild.iconUrl} alt="" loading="lazy" className="size-12 shrink-0 rounded-2xl object-cover shadow-md shadow-black/20" />
                      ) : (
                        <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-[var(--color-surface)] text-[var(--color-accent)]">
                          <IconGlobe size={21} />
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="flex min-w-0 items-center gap-2"><span className="truncate text-sm font-bold text-[var(--color-ink)] transition-colors group-hover:text-[var(--color-accent)]">{guild.name}</span><RankBadge rank={ranks[guild.id]} /></span>
                        <span className="mt-1 block truncate font-mono text-[9px] text-[var(--color-ink-faint)]">{guild.id}</span>
                      </span>
                      <span className="shrink-0 text-[var(--color-ink-faint)] transition-transform group-hover:translate-x-0.5 group-hover:text-[var(--color-accent)]">
                        <IconShield size={15} />
                      </span>
                    </button>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      )}

      {/* Access key notice */}
      <div className="mt-6 flex items-start gap-3 rounded-2xl border border-dashed border-[var(--color-edge-bright)] p-4">
        <span className="mt-0.5 shrink-0 text-[var(--color-accent)]"><IconLock size={16} /></span>
        <div className="min-w-0 text-xs text-[var(--color-ink-dim)]">
          <p className="font-semibold text-[var(--color-ink)]">Voice control and advanced features need an access key.</p>
          <button type="button" onClick={onGetAccess} className="mt-1 font-semibold text-[var(--color-accent)] hover:underline">
            Enter your key
          </button>
        </div>
      </div>

      {/* Guild roles modal */}
      {selectedGuildId && profile && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm sm:p-6"
          role="presentation"
          onMouseDown={(e) => { if (e.target === e.currentTarget) setSelectedGuildId(null); }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="server-modal-title"
            className="animate-rise flex max-h-[min(90dvh,900px)] w-full max-w-5xl flex-col overflow-hidden rounded-3xl border border-[var(--color-edge-bright)] bg-[var(--color-panel)] shadow-2xl shadow-black/50"
          >
            {/* Modal header */}
            <header className="relative flex shrink-0 items-center gap-4 overflow-hidden border-b border-[var(--color-edge)] p-5 sm:p-7">
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[var(--color-accent)]/10 via-transparent to-[var(--color-accent-2)]/10" />
              {selectedGuild?.iconUrl ? (
                <img src={selectedGuild.iconUrl} alt="" className="relative size-14 rounded-2xl object-cover ring-1 ring-white/10 sm:size-16" />
              ) : (
                <span className="relative flex size-14 items-center justify-center rounded-2xl bg-[var(--color-surface)] text-[var(--color-accent)] sm:size-16">
                  <IconGlobe size={26} />
                </span>
              )}
              <div className="relative min-w-0 flex-1">
                <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-[var(--color-accent)]">Server profile</p>
                <h3 id="server-modal-title" className="mt-1 truncate text-xl font-extrabold text-white sm:text-2xl">
                  {selectedGuild?.name ?? 'Server details'}
                </h3>
                <p className="mt-1 truncate font-mono text-[10px] text-[var(--color-ink-faint)]">{selectedGuildId}</p>
              </div>
              <button type="button" className="btn relative z-10 shrink-0 cursor-pointer px-3 py-2" onClick={() => setSelectedGuildId(null)} aria-label="Close">
                Close
              </button>
            </header>

            {/* Modal body */}
            <div className="grid min-h-0 flex-1 grid-cols-1 overflow-y-auto md:grid-cols-[minmax(220px,0.8fr)_minmax(0,1.5fr)] md:overflow-hidden">

              {/* Left: role list */}
              <aside className="border-b border-[var(--color-edge)] p-4 md:overflow-y-auto md:border-b-0 md:border-r sm:p-5">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--color-ink-faint)]">Member roles</p>
                    <h4 className="mt-1 text-sm font-bold text-[var(--color-ink)]">Role list</h4>
                  </div>
                  <span className="rounded-full bg-[color-mix(in_oklab,var(--color-accent)_14%,transparent)] px-2.5 py-1 text-xs font-bold text-[var(--color-accent)]">
                    {memberRoles?.roles.length ?? 0}
                  </span>
                </div>

                {/* Member mini card */}
                {memberRoles && (
                  <div className="mb-4 flex items-center gap-3 rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 p-3">
                    {memberRoles.avatarUrl ? (
                      <img src={memberRoles.avatarUrl} alt="" className="size-10 rounded-xl object-cover" />
                    ) : (
                      <span className="flex size-10 items-center justify-center rounded-xl bg-[var(--color-surface)] text-xs font-bold text-[var(--color-accent)]">
                        {(memberRoles.nickname ?? profile.username).slice(0, 2).toUpperCase()}
                      </span>
                    )}
                    <span className="min-w-0">
                      <span className="block truncate text-xs font-bold text-[var(--color-ink)]">{memberRoles.nickname ?? profile.globalName ?? profile.username}</span>
                      <span className="mt-0.5 block truncate text-[10px] text-[var(--color-ink-faint)]">@{profile.username}</span>
                    </span>
                  </div>
                )}

                {/* Rank badge */}
                {memberRoles && (() => {
                  const rank = getMemberRank(memberRoles.roles, memberRoles.isOwner);
                  return (
                    <div className={`mb-4 flex items-center justify-between rounded-2xl border p-3 ${rank.tone}`}>
                      <span className="text-[9px] font-bold uppercase tracking-[0.18em] opacity-80">Rank</span>
                      <span className="text-sm font-extrabold">{rank.label}</span>
                    </div>
                  );
                })()}

                {loadingGuild && (
                  <p className="flex items-center gap-2 rounded-xl bg-[var(--color-surface-dim)] p-3 text-xs text-[var(--color-ink-dim)]">
                    <IconRefresh size={14} className="animate-spin-slow" /> Loading roles…
                  </p>
                )}
                {rolesError && <p className="rounded-xl bg-[var(--color-bad-soft)] p-3 text-xs text-[var(--color-bad)]">{rolesError}</p>}
                {guildRolesError && <p className="mt-2 rounded-xl bg-[var(--color-bad-soft)] p-3 text-xs text-[var(--color-bad)]">{guildRolesError}</p>}
                {(rolesError || guildRolesError) && (
                  <button
                    type="button"
                    className="btn mt-2 w-full py-2 text-xs"
                    onClick={() => setDetailsAttempt((a) => a + 1)}
                  >
                    <IconRefresh size={13} /> Retry
                  </button>
                )}

                {/* Role buttons */}
                {memberRoles && memberRoles.roles.length > 0 && (
                  <div className="flex gap-2 overflow-x-auto pb-1 md:flex-col md:overflow-visible">
                    {[...memberRoles.roles]
                      .sort((a, b) => getRoleTier(b).level - getRoleTier(a).level || (b.position ?? 0) - (a.position ?? 0))
                      .map((role) => {
                        const tier = getRoleTier(role);
                        return (
                          <button
                            key={role.id}
                            type="button"
                            onClick={() => setSelectedRoleId(role.id)}
                            aria-pressed={selectedRoleId === role.id}
                            className={`flex min-w-44 items-center gap-2.5 rounded-xl border p-3 text-left transition-colors md:min-w-0 ${
                              selectedRoleId === role.id
                                ? 'border-[color-mix(in_oklab,var(--color-accent)_55%,var(--color-edge))] bg-[color-mix(in_oklab,var(--color-accent)_10%,var(--color-surface-dim))]'
                                : 'border-[var(--color-edge)] bg-[var(--color-void)]/25 hover:border-[var(--color-edge-bright)]'
                            }`}
                          >
                            <span className="size-2.5 shrink-0 rounded-full" style={{ background: role.color ?? 'var(--color-ink-faint)' }} />
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-xs font-semibold text-[var(--color-ink)]">{role.name}</span>
                              <span className={`mt-1 inline-flex rounded-full border px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider ${tier.tone}`}>
                                {tier.label}
                              </span>
                            </span>
                            <IconShield size={13} className={selectedRoleId === role.id ? 'text-[var(--color-accent)]' : 'text-[var(--color-ink-faint)]'} />
                          </button>
                        );
                      })}
                  </div>
                )}
                {memberRoles?.roles.length === 0 && (
                  <p className="rounded-xl border border-dashed border-[var(--color-edge-bright)] p-4 text-xs text-[var(--color-ink-faint)]">No visible roles for this member.</p>
                )}
              </aside>

              {/* Right: role details */}
              <div className="min-h-0 space-y-5 p-4 md:overflow-y-auto sm:p-6">
                {selectedRole ? (
                  <section className="rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/30 p-4 sm:p-5">
                    <div className="flex items-start gap-3">
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--color-surface)]">
                        <IconShield size={20} style={{ color: selectedRole.color ?? 'var(--color-accent)' }} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--color-ink-faint)]">Selected role</p>
                        <h4 className="mt-1 break-words text-lg font-extrabold text-[var(--color-ink)]">{selectedRole.name}</h4>
                      </div>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <span className={`inline-flex rounded-full border px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.12em] ${getRoleTier(selectedRole).tone}`}>
                        {getRoleTier(selectedRole).label}
                      </span>
                      <span className="inline-flex rounded-full border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.12em] text-[var(--color-ink-dim)]">
                        #{selectedRole.position}
                      </span>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
                      <div className="rounded-xl bg-[var(--color-surface-dim)] p-3">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Displayed separately</p>
                        <p className="mt-1 text-sm font-bold text-[var(--color-ink)]">{selectedRole.hoist ? 'Yes' : 'No'}</p>
                      </div>
                      <div className="rounded-xl bg-[var(--color-surface-dim)] p-3">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Mentionable</p>
                        <p className="mt-1 text-sm font-bold text-[var(--color-ink)]">{selectedRoleInfo ? (selectedRoleInfo.mentionable ? 'Yes' : 'No') : '…'}</p>
                      </div>
                      <div className="col-span-2 rounded-xl bg-[var(--color-surface-dim)] p-3 sm:col-span-1">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Role ID</p>
                        <p className="mt-1 truncate font-mono text-[10px] text-[var(--color-ink-dim)]" title={selectedRole.id}>{selectedRole.id}</p>
                      </div>
                    </div>
                    <div className="mt-4 border-t border-[var(--color-edge)] pt-4">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[9px] font-bold uppercase tracking-[0.16em] text-[var(--color-ink-faint)]">Permissions</p>
                        <span className="text-[10px] text-[var(--color-ink-faint)]">{selectedRoleInfo?.permissionNames.length ?? 0} granted</span>
                      </div>
                      {selectedRoleInfo && selectedRoleInfo.permissionNames.length > 0 ? (
                        <div className="mt-2 flex max-h-40 flex-wrap gap-1.5 overflow-y-auto">
                          {selectedRoleInfo.permissionNames.map((perm) => (
                            <span key={perm} className="rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-2 py-1 text-[10px] font-medium text-[var(--color-ink-dim)]">
                              {perm.replace(/([a-z])([A-Z])/g, '$1 $2').replaceAll('_', ' ').toLowerCase()}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="mt-2 text-xs text-[var(--color-ink-faint)]">
                          {guildRolesError ? 'Role permissions could not be loaded.' : selectedRoleInfo ? 'This role has no explicit permissions.' : 'Loading role permissions…'}
                        </p>
                      )}
                    </div>
                  </section>
                ) : (
                  <section className="rounded-2xl border border-dashed border-[var(--color-edge-bright)] p-5 text-center">
                    <IconShield size={22} className="mx-auto text-[var(--color-ink-faint)]" />
                    <p className="mt-2 text-sm font-semibold text-[var(--color-ink-dim)]">Select a role to inspect it</p>
                    <p className="mt-1 text-xs text-[var(--color-ink-faint)]">Choose a role from the list to view its available details.</p>
                  </section>
                )}

                {memberRoles?.joinedAt && (
                  <div className="flex items-center gap-2 text-xs text-[var(--color-ink-dim)]">
                    <IconClock size={14} className="text-[var(--color-accent)]" />
                    Joined this server {new Date(memberRoles.joinedAt).toLocaleDateString()}
                  </div>
                )}
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
