import { useState, type FormEvent } from 'react';
import type { AutoReactRule, BotSession, UserRole, KeyPermissions } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { useToast } from './Toast';
import {
  IconPlus,
  IconTrash,
  IconPower,
  IconCheckSquare,
  IconSquare,
  IconEdit,
} from './Icons';

interface Props {
  sessions: BotSession[];
  rules: AutoReactRule[];
  role: UserRole;
  permissions?: KeyPermissions;
  onRefreshRules: () => void;
}

export function AutoReact({ sessions, rules, role, permissions, onRefreshRules }: Props) {
  const toast = useToast();
  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const canUseAllScope = role === 'owner' || permissions?.botScope === 'all';

  // Form state
  const [name, setName] = useState('');
  const [targetUserId, setTargetUserId] = useState('');
  const [emoji, setEmoji] = useState('');
  const [botScope, setBotScope] = useState<'all' | 'specific'>(canUseAllScope ? 'all' : 'specific');
  const [selectedBotIds, setSelectedBotIds] = useState<string[]>([]);

  const openCreateForm = () => {
    setEditingId(null);
    setName('');
    setTargetUserId('');
    setEmoji('');
    setBotScope(canUseAllScope ? 'all' : 'specific');
    setSelectedBotIds([]);
    setCreating(true);
  };

  const openEditForm = (rule: AutoReactRule) => {
    setEditingId(rule.id);
    setName(rule.name);
    setTargetUserId(rule.targetUserId);
    setEmoji(rule.emoji);
    setBotScope(rule.botScope);
    setSelectedBotIds(rule.botIds);
    setCreating(true);
  };

  const closeForm = () => {
    setCreating(false);
    setEditingId(null);
  };

  const toggleSelectBot = (id: string) => {
    setSelectedBotIds((current) =>
      current.includes(id) ? current.filter((x) => x !== id) : [...current, id]
    );
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !targetUserId.trim() || !emoji.trim()) {
      toast.bad('Please fill in all fields');
      return;
    }
    if (botScope === 'specific' && selectedBotIds.length === 0) {
      toast.bad('Please select at least one account');
      return;
    }

    setBusy(true);
    try {
      if (editingId) {
        await api.updateAutoReactRule(editingId, {
          name: name.trim(),
          targetUserId: targetUserId.trim(),
          emoji: emoji.trim(),
          botScope,
          botIds: selectedBotIds,
        });
        toast.ok('Auto-react rule updated');
      } else {
        await api.createAutoReactRule({
          name: name.trim(),
          targetUserId: targetUserId.trim(),
          emoji: emoji.trim(),
          botScope,
          botIds: selectedBotIds,
        });
        toast.ok('Auto-react rule created');
      }
      closeForm();
      onRefreshRules();
    } catch (err) {
      toast.bad(err instanceof ApiError ? err.message : `Failed to ${editingId ? 'update' : 'create'} rule`);
    } finally {
      setBusy(false);
    }
  };

  const handleToggle = async (rule: AutoReactRule) => {
    try {
      await api.updateAutoReactRule(rule.id, { enabled: !rule.enabled });
      onRefreshRules();
    } catch (err) {
      toast.bad(err instanceof ApiError ? err.message : 'Failed to toggle rule');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this rule?')) return;
    try {
      await api.deleteAutoReactRule(id);
      toast.ok('Rule deleted');
      onRefreshRules();
    } catch (err) {
      toast.bad(err instanceof ApiError ? err.message : 'Failed to delete rule');
    }
  };

  if (creating) {
    return (
      <div className="animate-rise panel p-5">
        <h2 className="mb-4 text-sm font-bold text-[var(--color-accent)]">{editingId ? 'Edit Auto-React Rule' : 'Create Auto-React Rule'}</h2>
        <form onSubmit={handleSave} className="flex flex-col gap-4">
          <div>
            <label className="label">Rule Name</label>
            <input
              className="field"
              placeholder="e.g. React to my main account"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <label className="label">Target Discord User ID</label>
            <input
              className="field"
              placeholder="000000000000000000"
              value={targetUserId}
              onChange={(e) => setTargetUserId(e.target.value)}
            />
          </div>
          <div>
            <label className="label">Emoji (Unicode or Discord format)</label>
            <input
              className="field"
              placeholder="Emoji or <:name:id>"
              value={emoji}
              onChange={(e) => setEmoji(e.target.value)}
            />
          </div>
          
          <div className="flex flex-col gap-2 border-t border-[var(--color-edge)] pt-4">
            <label className="label">Accounts to react with</label>
            {(role === 'owner' || permissions?.botScope === 'all') ? (
              <select
                className="field"
                value={botScope}
                onChange={(e) => setBotScope(e.target.value as 'all' | 'specific')}
              >
                <option value="all">All online accounts</option>
                <option value="specific">Specific accounts</option>
              </select>
            ) : (
              <div className="field opacity-70 bg-[var(--color-surface-dim)] pointer-events-none cursor-not-allowed">
                Specific accounts
              </div>
            )}
          </div>

          {botScope === 'specific' && (
            <div className="grid max-h-48 grid-cols-1 overflow-y-auto rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface)] p-2">
              {sessions.map((session) => (
                <button
                  key={session.id}
                  type="button"
                  onClick={() => toggleSelectBot(session.id)}
                  className="flex items-center gap-3 rounded-md px-3 py-2 text-left text-xs transition-colors hover:bg-[var(--color-surface-dim)]"
                >
                  {selectedBotIds.includes(session.id) ? (
                    <IconCheckSquare size={16} className="text-[var(--color-accent)]" />
                  ) : (
                    <IconSquare size={16} className="text-[var(--color-ink-faint)]" />
                  )}
                  <span className="truncate font-semibold">{session.username}</span>
                </button>
              ))}
              {sessions.length === 0 && (
                <p className="p-2 text-xs text-[var(--color-ink-faint)]">No accounts available.</p>
              )}
            </div>
          )}

          <div className="mt-4 flex gap-3">
            <button
              type="button"
              className="btn flex-1"
              onClick={closeForm}
              disabled={busy}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary flex-1"
              disabled={busy}
            >
              {busy ? 'Saving...' : editingId ? 'Save Changes' : 'Create Rule'}
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-[var(--color-ink-dim)]">
          {rules.length} Auto-React Rule{rules.length === 1 ? '' : 's'}
        </p>
        <button className="btn btn-primary px-3 py-1.5 text-xs" onClick={openCreateForm}>
          <IconPlus size={14} />
          New Rule
        </button>
      </div>

      {rules.length === 0 ? (
        <div className="panel flex flex-col items-center gap-3 p-12 text-center">
          <p className="text-sm font-semibold text-[var(--color-ink-dim)]">No rules created yet</p>
          <p className="max-w-xs text-xs text-[var(--color-ink-faint)]">
            Create an auto-react rule to automatically add reactions to messages from a specific user.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {rules.map((rule) => (
            <div key={rule.id} className="panel flex flex-col gap-3 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <h3 className="truncate font-bold text-[var(--color-ink)]">{rule.name}</h3>
                  <p className="mt-0.5 truncate font-mono text-[0.6875rem] text-[var(--color-ink-faint)]">
                    Target: {rule.targetUserId}
                  </p>
                </div>
                <button
                  onClick={() => handleToggle(rule)}
                  className="chip transition-colors"
                  style={
                    rule.enabled
                      ? {
                          color: 'var(--color-good)',
                          borderColor: 'color-mix(in oklab, var(--color-good) 40%, transparent)',
                          background: 'color-mix(in oklab, var(--color-good) 10%, transparent)',
                        }
                      : { color: 'var(--color-ink-faint)' }
                  }
                >
                  <IconPower size={13} />
                  {rule.enabled ? 'Active' : 'Paused'}
                </button>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                <span className="chip border-[var(--color-edge)]">
                  Emoji: <span className="ml-1 font-mono">{rule.emoji}</span>
                </span>
                <span className="chip border-[var(--color-edge)]">
                  Bots: {rule.botScope === 'all' ? 'All' : rule.botIds.length}
                </span>
                <span className="chip border-[var(--color-edge)]">
                  Triggers: {rule.triggerCount}
                </span>
              </div>

              <div className="mt-2 flex justify-end gap-2">
                <button
                  onClick={() => openEditForm(rule)}
                  className="btn px-3 py-1.5 text-xs text-[var(--color-ink)] hover:bg-[var(--color-surface-dim)]"
                >
                  <IconEdit size={14} />
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(rule.id)}
                  className="btn px-3 py-1.5 text-xs text-[var(--color-bad)] hover:border-[var(--color-bad)]/30 hover:bg-[var(--color-bad)]/10"
                >
                  <IconTrash size={14} />
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
