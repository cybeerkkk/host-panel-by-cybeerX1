import { useCallback, useEffect, useRef, useState } from 'react';
import type { BotSession, KeyPermissions, UserProfile, UserRole } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { usePersistedState } from '../lib/usePersistedState';
import type {
  MonitorChannel, MonitorChannelLookup, MonitorGuild, MonitorGuildRole, MonitorGuildRoles,
  MonitorGuildSummary, MonitorMemberPermissions, MonitorMemberRoles, MonitorMessage,
  MonitorRoleMembers, MonitorVoiceMember,
} from '../lib/api';
import { useToast } from './Toast';
import {
  IconAlert, IconClock, IconGlobe, IconMic, IconMicOff,
  IconCrown, IconRadar, IconRefresh, IconSearch, IconSpeaker, IconUsers,
} from './Icons';

// ─── inline icons ─────────────────────────────────────────────────────────────
function IconShield({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M8 1L2 4v4c0 3.5 2.5 6 6 7 3.5-1 6-3.5 6-7V4L8 1z"/></svg>;
}
function IconChevronLeft({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 12L6 8l4-4"/></svg>;
}
function IconHash({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><line x1="4" y1="5" x2="12" y2="5"/><line x1="3" y1="9" x2="13" y2="9"/><line x1="6" y1="2" x2="5" y2="14"/><line x1="11" y1="2" x2="10" y2="14"/></svg>;
}
function IconSmile({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="8" r="6.5"/><path d="M5.5 9.5s.8 1.5 2.5 1.5 2.5-1.5 2.5-1.5"/><circle cx="6" cy="6.5" r="0.75" fill="currentColor"/><circle cx="10" cy="6.5" r="0.75" fill="currentColor"/></svg>;
}
function IconKey({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="6" cy="7" r="3.5"/><path d="M9 7h5M12 7v2.5"/></svg>;
}
function IconCheck({ size = 12 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 6l3 3 5-5"/></svg>;
}
function IconX({ size = 12 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M2 2l8 8M10 2L2 10"/></svg>;
}
function IconLock({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="10" height="8" rx="1.5"/><path d="M5 7V5a3 3 0 016 0v2"/></svg>;
}
function IconWifi({ size = 14 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M1 6c1.9-2 4.5-3 7-3s5.1 1 7 3"/><path d="M4 9.5c1.1-1.1 2.5-1.7 4-1.7s2.9.6 4 1.7"/><circle cx="8" cy="13" r="1" fill="currentColor"/></svg>;
}

// ─── helpers ─────────────────────────────────────────────────────────────────
function ago(ts: number) {
  const diff = Date.now() - ts;
  if (diff < 60_000) return 'just now';
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return new Date(ts).toLocaleDateString();
}

function GuildIcon({ guild, size = 32 }: { guild: MonitorGuildSummary; size?: number }) {
  const [failed, setFailed] = useState(false);
  if (guild.iconUrl && !failed)
    return <img src={guild.iconUrl} alt="" style={{ width: size, height: size }} className="rounded-xl object-cover shrink-0" onError={() => setFailed(true)} />;
  return <div style={{ width: size, height: size }} className="flex items-center justify-center rounded-xl bg-[var(--color-surface-dim)] font-bold text-[var(--color-accent)] shrink-0 text-xs">{guild.name.slice(0, 2).toUpperCase()}</div>;
}

function Avatar({ url, name, size = 32 }: { url: string | null; name: string; size?: number }) {
  const [failed, setFailed] = useState(false);
  if (url && !failed)
    return <img src={url} alt="" style={{ width: size, height: size }} className="rounded-full object-cover shrink-0" onError={() => setFailed(true)} />;
  return <div style={{ width: size, height: size }} className="flex items-center justify-center rounded-full bg-[var(--color-surface-dim)] font-bold text-[var(--color-accent)] shrink-0 text-[10px]">{name.slice(0, 2).toUpperCase()}</div>;
}

// ─── Voice member chip ────────────────────────────────────────────────────────
function VoiceMemberChip({ member, guildId, onClick, onRolesClick }: {
  member: MonitorVoiceMember; guildId?: string;
  onClick: (userId: string) => void;
  onRolesClick?: (userId: string, guildId: string) => void;
}) {
  return (
    <div className="group flex items-center gap-1 rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] pl-2 pr-1 py-1.5 transition-colors hover:border-[var(--color-accent)]/40 hover:bg-[var(--color-accent)]/5">
      <button onClick={() => onClick(member.userId)} className="flex items-center gap-2 min-w-0 flex-1 text-left" title={`View profile`}>
        <div className="relative shrink-0">
          <Avatar url={member.avatarUrl} name={member.username} size={30} />
          <span className={`absolute -bottom-0.5 -right-0.5 flex size-3.5 items-center justify-center rounded-full text-white ${member.selfMute || member.serverMute ? 'bg-[var(--color-bad)]' : 'bg-[var(--color-good)]'}`}>
            {member.selfMute || member.serverMute ? <IconMicOff size={8} /> : <IconMic size={8} />}
          </span>
        </div>
        <div className="min-w-0">
          <p className="truncate text-[11px] font-semibold leading-tight text-[var(--color-ink)]">{member.globalName ?? member.username}</p>
          {member.selfDeaf || member.serverDeaf
            ? <p className="text-[9px] text-[var(--color-bad)]">Deafened</p>
            : <p className="text-[9px] text-[var(--color-ink-faint)]">@{member.username}</p>}
        </div>
      </button>
      {guildId && onRolesClick && (
        <button onClick={() => onRolesClick(member.userId, guildId)} className="shrink-0 flex size-6 items-center justify-center rounded-md text-[var(--color-ink-faint)] opacity-0 transition-all group-hover:opacity-100 hover:text-[var(--color-accent)]" title="View roles">
          <IconShield size={11} />
        </button>
      )}
    </div>
  );
}

// ─── Profile popup ────────────────────────────────────────────────────────────
function ProfilePopup({ userId, onClose, onJoinVoice }: {
  userId: string; onClose: () => void;
  onJoinVoice?: (guildId: string, channelId: string) => void;
}) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [avatarFailed, setAvatarFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    api.radar(userId)
      .then((p) => { if (!cancelled) { setProfile(p); setLoading(false); } })
      .catch((e) => { if (!cancelled) { setError(e instanceof ApiError ? e.message : 'Failed'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [userId]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-sm animate-rise panel overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {loading ? (
          <div className="flex flex-col items-center gap-3 p-10"><IconRefresh size={24} className="animate-spin-slow text-[var(--color-accent)]" /><p className="text-sm text-[var(--color-ink-faint)]">Loading profile…</p></div>
        ) : error ? (
          <div className="p-6"><p className="flex items-center gap-2 text-sm text-[var(--color-bad)]"><IconAlert size={16}/> {error}</p><button className="btn mt-4 w-full" onClick={onClose}>Close</button></div>
        ) : profile ? (
          <>
            <div className="relative h-24" style={{ background: profile.bannerUrl ? `center/cover no-repeat url(${JSON.stringify(profile.bannerUrl)})` : `linear-gradient(120deg, ${profile.accentColor ?? 'var(--color-accent)'}44, var(--color-accent-2)22)` }}>
              <button onClick={onClose} className="absolute right-3 top-3 flex size-7 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70">
                <svg width="12" height="12" viewBox="0 0 10 10" fill="none"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
              </button>
            </div>
            <div className="relative px-4 pb-4">
              <div className="absolute -top-10 left-4">
                {profile.avatarUrl && !avatarFailed
                  ? <img src={profile.avatarUrl} alt="" onError={() => setAvatarFailed(true)} className="size-20 rounded-full border-4 border-[var(--color-panel)] object-cover"/>
                  : <div className="flex size-20 items-center justify-center rounded-full border-4 border-[var(--color-panel)] bg-[var(--color-surface-dim)] font-mono text-lg font-bold text-[var(--color-accent)]">{profile.username.slice(0,2).toUpperCase()}</div>}
              </div>
              <div className="pt-12">
                <h3 className="truncate text-base font-extrabold text-white">{profile.globalName || profile.username}</h3>
                <p className="text-xs text-[var(--color-ink-faint)]">@{profile.username}</p>
              </div>
              {profile.bio && <p className="mt-2 rounded-lg bg-[var(--color-surface-dim)] p-2.5 text-xs leading-relaxed text-[var(--color-ink)]">{profile.bio}</p>}
              <div className="mt-3 flex flex-wrap gap-1.5">
                <span className="chip border-[var(--color-edge)] text-[var(--color-ink-faint)]"><IconGlobe size={11}/>{profile.mutualGuilds.length} mutual</span>
                {profile.badges.slice(0,3).map((b) => <span key={b} className="chip border-[var(--color-edge)] text-[var(--color-ink-faint)]">{b.replaceAll('_',' ').toLowerCase()}</span>)}
              </div>
              <div className="mt-3 flex items-center gap-2 rounded-lg border p-3" style={profile.inVoice ? { borderColor: 'color-mix(in oklab, var(--color-good) 38%, transparent)', background: 'color-mix(in oklab, var(--color-good) 9%, transparent)' } : { borderColor: 'var(--color-edge)' }}>
                <span style={{ color: profile.inVoice ? 'var(--color-good)' : 'var(--color-ink-faint)' }}><IconSpeaker size={14}/></span>
                {profile.inVoice
                  ? <div className="min-w-0"><p className="text-xs font-bold text-[var(--color-good)] truncate">{profile.voiceChannelName} · {profile.voiceGuildName}</p>{profile.voiceMemberCount > 0 && <p className="text-[10px] text-[var(--color-ink-faint)]">{profile.voiceMemberCount} in channel</p>}</div>
                  : <p className="text-xs text-[var(--color-ink-dim)]">Not in voice</p>}
              </div>
              {profile.inVoice && profile.voiceGuildId && profile.voiceChannelId && onJoinVoice && (
                <button onClick={() => { onJoinVoice(profile.voiceGuildId!, profile.voiceChannelId!); onClose(); }} className="btn btn-primary mt-3 w-full py-2 text-xs font-bold">
                  <IconSpeaker size={13}/> Dispatch to channel
                </button>
              )}
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}

// ─── Roles popup (member roles in a guild) ────────────────────────────────────
function MemberRolesPopup({ userId, guildId, onClose, onViewPermissions }: {
  userId: string; guildId: string; onClose: () => void;
  onViewPermissions: (userId: string, guildId: string) => void;
}) {
  const [data, setData] = useState<MonitorMemberRoles | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    api.monitor.memberRoles(guildId, userId)
      .then((d) => { if (!cancelled) { setData(d); setLoading(false); } })
      .catch((e) => { if (!cancelled) { setError(e instanceof ApiError ? e.message : 'Failed'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [userId, guildId]);

  const joinedDate = data?.joinedAt ? new Date(data.joinedAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-sm animate-rise panel overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[var(--color-edge)] px-4 py-3">
          <div className="flex items-center gap-2"><span className="text-[var(--color-accent)]"><IconShield size={15}/></span><h3 className="text-sm font-bold text-[var(--color-ink)]">Member Roles</h3></div>
          <button onClick={onClose} className="flex size-7 items-center justify-center rounded-full bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </button>
        </div>
        {loading ? <div className="flex flex-col items-center gap-3 p-10"><IconRefresh size={22} className="animate-spin-slow text-[var(--color-accent)]"/><p className="text-sm text-[var(--color-ink-faint)]">Loading…</p></div>
        : error ? <div className="p-5"><p className="flex items-center gap-2 text-sm text-[var(--color-bad)]"><IconAlert size={15}/> {error}</p><button className="btn mt-4 w-full" onClick={onClose}>Close</button></div>
        : data ? (
          <div className="p-4 flex flex-col gap-3">
            <div className="rounded-xl bg-[var(--color-surface-dim)] p-3 flex flex-col gap-1">
              <p className="text-xs font-bold text-[var(--color-ink)]">{data.nickname ?? `User ${userId.slice(-4)}`}</p>
              <p className="text-[10px] text-[var(--color-ink-faint)]">{data.guildName}</p>
              {joinedDate && <p className="text-[10px] text-[var(--color-ink-faint)]"><IconClock size={9} className="inline mr-0.5"/> Joined {joinedDate}</p>}
            </div>
            <button onClick={() => { onClose(); onViewPermissions(userId, guildId); }} className="btn btn-primary w-full py-1.5 text-xs">
              <IconKey size={13}/> View Effective Permissions
            </button>
            <div>
              <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">{data.roles.length} role{data.roles.length !== 1 ? 's' : ''}</p>
              {data.roles.length === 0
                ? <p className="text-center py-4 text-xs text-[var(--color-ink-faint)]">No roles</p>
                : <div className="flex max-h-64 flex-col gap-1.5 overflow-y-auto pr-1">
                    {data.roles.map((role) => (
                      <div key={role.id} className="flex items-center gap-2 rounded-lg border border-[var(--color-edge)] px-2.5 py-1.5" style={role.color ? { borderColor: `${role.color}44`, background: `${role.color}11` } : undefined}>
                        <span className="size-2.5 rounded-full shrink-0" style={{ background: role.color ?? 'var(--color-edge-bright)' }}/>
                        <span className="text-xs font-semibold truncate" style={{ color: role.color ?? 'var(--color-ink-dim)' }}>{role.name}</span>
                        {role.hoist && <span className="ml-auto shrink-0 text-[9px] text-[var(--color-ink-faint)] border border-[var(--color-edge)] rounded px-1">hoisted</span>}
                      </div>
                    ))}
                  </div>}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

// ─── Member permissions popup ─────────────────────────────────────────────────
function MemberPermissionsPopup({ userId, guildId, onClose }: {
  userId: string; guildId: string; onClose: () => void;
}) {
  const [data, setData] = useState<MonitorMemberPermissions | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<'all' | 'granted' | 'denied'>('granted');

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    api.monitor.memberPermissions(guildId, userId)
      .then((d) => { if (!cancelled) { setData(d); setLoading(false); } })
      .catch((e) => { if (!cancelled) { setError(e instanceof ApiError ? e.message : 'Failed'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [userId, guildId]);

  const filtered = data?.permissions.filter(p =>
    filter === 'all' ? true : filter === 'granted' ? p.granted : !p.granted
  ) ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md animate-rise panel overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[var(--color-edge)] px-4 py-3">
          <div className="flex items-center gap-2"><span className="text-[var(--color-accent)]"><IconKey size={15}/></span><h3 className="text-sm font-bold text-[var(--color-ink)]">Effective Permissions</h3></div>
          <button onClick={onClose} className="flex size-7 items-center justify-center rounded-full bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)] hover:text-[var(--color-ink)]">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </button>
        </div>
        {loading ? <div className="flex flex-col items-center gap-3 p-10"><IconRefresh size={22} className="animate-spin-slow text-[var(--color-accent)]"/><p className="text-sm text-[var(--color-ink-faint)]">Loading permissions…</p></div>
        : error ? <div className="p-5"><p className="flex items-center gap-2 text-sm text-[var(--color-bad)]"><IconAlert size={15}/> {error}</p><button className="btn mt-4 w-full" onClick={onClose}>Close</button></div>
        : data ? (
          <div className="p-4 flex flex-col gap-3">
            <div className="rounded-xl bg-[var(--color-surface-dim)] p-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-[var(--color-ink)]">{data.nickname ?? `User ${userId.slice(-4)}`}</p>
                <p className="text-[10px] text-[var(--color-ink-faint)]">{data.guildName}</p>
              </div>
              {data.isOwner && <span className="chip text-[10px]" style={{ color: 'var(--color-warn)', borderColor: 'color-mix(in oklab,var(--color-warn) 40%,transparent)', background: 'color-mix(in oklab,var(--color-warn) 10%,transparent)' }}><IconCrown size={11} /> Owner</span>}
              <span className="chip text-[10px]" style={{ color: 'var(--color-good)', borderColor: 'color-mix(in oklab, var(--color-good) 40%, transparent)' }}>
                {data.permissions.filter(p => p.granted).length} granted
              </span>
            </div>
            <div className="flex gap-1">
              {(['granted', 'denied', 'all'] as const).map((f) => (
                <button key={f} onClick={() => setFilter(f)} className="flex-1 py-1 rounded-lg text-[11px] font-semibold transition-colors"
                  style={filter === f ? { background: 'color-mix(in oklab, var(--color-accent) 15%, transparent)', color: 'var(--color-accent)', border: '1px solid color-mix(in oklab, var(--color-accent) 40%, transparent)' } : { background: 'var(--color-surface-dim)', color: 'var(--color-ink-faint)', border: '1px solid var(--color-edge)' }}>
                  {f === 'granted' ? '✓ Granted' : f === 'denied' ? '✗ Denied' : 'All'}
                </button>
              ))}
            </div>
            <div className="flex max-h-72 flex-col gap-1 overflow-y-auto pr-1">
              {filtered.map((perm) => (
                <div key={perm.name} className="flex items-center gap-2.5 rounded-lg border border-[var(--color-edge)] px-3 py-2"
                  style={perm.granted ? { borderColor: 'color-mix(in oklab, var(--color-good) 25%, transparent)', background: 'color-mix(in oklab, var(--color-good) 5%, transparent)' } : undefined}>
                  <span className={`flex size-4 shrink-0 items-center justify-center rounded-full ${perm.granted ? 'bg-[var(--color-good)] text-black' : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)]'}`}>
                    {perm.granted ? <IconCheck size={10}/> : <IconX size={9}/>}
                  </span>
                  <span className={`text-xs font-medium ${perm.granted ? 'text-[var(--color-ink)]' : 'text-[var(--color-ink-faint)]'}`}>{perm.name}</span>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

// ─── Guild Roles Panel ────────────────────────────────────────────────────────
function RoleMembersView({ roleId, guildId, roleName, roleColor, onClose, onProfileClick }: {
  roleId: string; guildId: string; roleName: string; roleColor: string | null;
  onClose: () => void; onProfileClick: (userId: string) => void;
}) {
  const [data, setData] = useState<MonitorRoleMembers | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    api.monitor.roleMembers(guildId, roleId)
      .then((d) => { if (!cancelled) { setData(d); setLoading(false); } })
      .catch((e) => { if (!cancelled) { setError(e instanceof ApiError ? e.message : 'Failed'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [roleId, guildId]);

  const filtered = (data?.members ?? []).filter(m =>
    (m.globalName ?? m.username ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (m.nickname ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md animate-rise panel overflow-hidden max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[var(--color-edge)] px-4 py-3 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="size-3.5 rounded-full shrink-0" style={{ background: roleColor ?? 'var(--color-edge-bright)' }}/>
            <h3 className="text-sm font-bold truncate" style={{ color: roleColor ?? 'var(--color-ink)' }}>{roleName}</h3>
            {data && (
              <span className="chip border-[var(--color-edge)] text-[10px] text-[var(--color-ink-faint)] shrink-0">
                {data.members.length === data.total
                  ? `${data.total} members`
                  : `${data.members.length} / ${data.total}`}
              </span>
            )}
          </div>
          <button onClick={onClose} className="flex size-7 items-center justify-center rounded-full bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)] hover:text-[var(--color-ink)] shrink-0">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </button>
        </div>
        {loading ? <div className="flex flex-col items-center gap-3 p-10"><IconRefresh size={20} className="animate-spin-slow text-[var(--color-accent)]"/><p className="text-sm text-[var(--color-ink-faint)]">Loading members…</p></div>
        : error ? <div className="p-5"><p className="flex items-center gap-2 text-sm text-[var(--color-bad)]"><IconAlert size={15}/> {error}</p></div>
        : (
          <div className="flex flex-col gap-3 p-4 flex-1 min-h-0">
            <input className="field py-1.5 text-xs shrink-0" placeholder="Search members…" value={search} onChange={e => setSearch(e.target.value)}/>
            {filtered.length === 0
              ? <div className="py-6 flex flex-col items-center gap-2 text-center">
                  <span className="text-[var(--color-edge-bright)]"><IconUsers size={28}/></span>
                  <p className="text-sm text-[var(--color-ink-dim)]">{search ? 'No results' : 'No members in cache'}</p>
                  <p className="text-[10px] text-[var(--color-ink-faint)] max-w-xs">{search ? 'Try a different search term.' : "The bot's member cache is empty for this role. Members appear here once they're active in the server."}</p>
                </div>
              : <div className="flex flex-col gap-1 overflow-y-auto pr-1">
                  {filtered.map((m) => (
                    <button key={m.userId} onClick={() => onProfileClick(m.userId)}
                      className="flex items-center gap-3 rounded-xl border border-[var(--color-edge)] px-3 py-2.5 text-left transition-colors hover:bg-[var(--color-surface-dim)] hover:border-[var(--color-accent)]/30">
                      <Avatar url={m.avatarUrl} name={m.username} size={34}/>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold text-[var(--color-ink)]">{m.globalName ?? m.username}</p>
                        <p className="text-[10px] text-[var(--color-ink-faint)]">
                          @{m.username}{m.nickname ? ` · "${m.nickname}"` : ''}
                        </p>
                      </div>
                      {m.inVoice && (
                        <span className="chip shrink-0 text-[9px]" style={{ color: 'var(--color-good)', borderColor: 'color-mix(in oklab, var(--color-good) 40%, transparent)', background: 'color-mix(in oklab, var(--color-good) 8%, transparent)' }}>
                          <IconSpeaker size={9}/> {m.voiceChannelName ?? 'In VC'}
                        </span>
                      )}
                    </button>
                  ))}
                </div>}
            {data && !search && data.members.length < data.total && (
              <div className="rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-2 text-center">
                <p className="text-[10px] text-[var(--color-ink-faint)]">
                  Showing <span className="font-semibold text-[var(--color-ink)]">{data.members.length}</span> cached · <span className="font-semibold text-[var(--color-ink)]">{data.total}</span> total in this role
                </p>
                <p className="text-[9px] text-[var(--color-ink-faint)] mt-0.5">Members appear as they become active in the server</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function GuildRolesPanel({ guildId, guildName, onClose, onProfileClick }: {
  guildId: string; guildName: string; onClose: () => void;
  onProfileClick: (userId: string) => void;
}) {
  const [data, setData] = useState<MonitorGuildRoles | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedRole, setSelectedRole] = useState<MonitorGuildRole | null>(null);
  const [search, setSearch] = useState('');
  const [roleMembersTarget, setRoleMembersTarget] = useState<MonitorGuildRole | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    api.monitor.guildRoles(guildId)
      .then((d) => {
        if (!cancelled) {
          setData(d);
          setLoading(false);
          // Auto-select first hoisted/colored role for faster UX
          if (d.roles.length > 0) {
            const firstMeaningful = d.roles.find(r => r.name !== '@everyone' && (r.hoist || r.memberCount));
            setSelectedRole(firstMeaningful ?? d.roles[0]);
          }
        }
      })
      .catch((e) => { if (!cancelled) { setError(e instanceof ApiError ? e.message : 'Failed'); setLoading(false); } });
    return () => { cancelled = true; };
  }, [guildId]);

  const PERMISSION_FLAGS: [string, bigint][] = [
    ['Create Instant Invite', BigInt(1) << BigInt(0)],
    ['Kick Members', BigInt(1) << BigInt(1)],
    ['Ban Members', BigInt(1) << BigInt(2)],
    ['Administrator', BigInt(1) << BigInt(3)],
    ['Manage Channels', BigInt(1) << BigInt(4)],
    ['Manage Guild', BigInt(1) << BigInt(5)],
    ['Add Reactions', BigInt(1) << BigInt(6)],
    ['View Audit Log', BigInt(1) << BigInt(7)],
    ['Priority Speaker', BigInt(1) << BigInt(8)],
    ['Stream', BigInt(1) << BigInt(9)],
    ['View Channel', BigInt(1) << BigInt(10)],
    ['Send Messages', BigInt(1) << BigInt(11)],
    ['Send TTS Messages', BigInt(1) << BigInt(12)],
    ['Manage Messages', BigInt(1) << BigInt(13)],
    ['Embed Links', BigInt(1) << BigInt(14)],
    ['Attach Files', BigInt(1) << BigInt(15)],
    ['Read Message History', BigInt(1) << BigInt(16)],
    ['Mention Everyone', BigInt(1) << BigInt(17)],
    ['Use External Emojis', BigInt(1) << BigInt(18)],
    ['View Guild Insights', BigInt(1) << BigInt(19)],
    ['Connect', BigInt(1) << BigInt(20)],
    ['Speak', BigInt(1) << BigInt(21)],
    ['Mute Members', BigInt(1) << BigInt(22)],
    ['Deafen Members', BigInt(1) << BigInt(23)],
    ['Move Members', BigInt(1) << BigInt(24)],
    ['Use VAD', BigInt(1) << BigInt(25)],
    ['Change Nickname', BigInt(1) << BigInt(26)],
    ['Manage Nicknames', BigInt(1) << BigInt(27)],
    ['Manage Roles', BigInt(1) << BigInt(28)],
    ['Manage Webhooks', BigInt(1) << BigInt(29)],
    ['Manage Emojis', BigInt(1) << BigInt(30)],
    ['Use Application Commands', BigInt(1) << BigInt(31)],
    ['Manage Events', BigInt(1) << BigInt(33)],
    ['Manage Threads', BigInt(1) << BigInt(34)],
    ['Create Public Threads', BigInt(1) << BigInt(35)],
    ['Create Private Threads', BigInt(1) << BigInt(36)],
    ['Send Messages in Threads', BigInt(1) << BigInt(38)],
    ['Moderate Members', BigInt(1) << BigInt(40)],
  ];

  const getRolePerms = (role: MonitorGuildRole) => {
    try {
      const bits = BigInt(role.permissions);
      return PERMISSION_FLAGS.map(([name, bit]) => ({ name, granted: (bits & bit) === bit }));
    } catch { return []; }
  };

  const filtered = data?.roles.filter(r => r.name.toLowerCase().includes(search.toLowerCase())) ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-2xl animate-rise panel overflow-hidden max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-[var(--color-edge)] px-4 py-3 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-[var(--color-accent)]"><IconShield size={15}/></span>
            <h3 className="text-sm font-bold text-[var(--color-ink)] truncate">Roles — {guildName}</h3>
            {data && <span className="chip border-[var(--color-edge)] text-[10px] text-[var(--color-ink-faint)] shrink-0">{data.roles.length}</span>}
          </div>
          <button onClick={onClose} className="flex size-7 items-center justify-center rounded-full bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)] hover:text-[var(--color-ink)] shrink-0">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </button>
        </div>

        {loading ? <div className="flex flex-col items-center gap-3 p-12"><IconRefresh size={24} className="animate-spin-slow text-[var(--color-accent)]"/><p className="text-sm text-[var(--color-ink-faint)]">Loading roles…</p></div>
        : error ? <div className="p-5"><p className="flex items-center gap-2 text-sm text-[var(--color-bad)]"><IconAlert size={15}/> {error}</p></div>
        : data ? (
          <div className="flex flex-1 min-h-0">
            {/* Role list */}
            <div className="w-64 shrink-0 border-r border-[var(--color-edge)] flex flex-col">
              <div className="p-3 border-b border-[var(--color-edge)]">
                <input className="field py-1.5 text-xs" placeholder="Search roles…" value={search} onChange={e => setSearch(e.target.value)}/>
              </div>
              <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-0.5">
                {filtered.map((role) => (
                  <button key={role.id} onClick={() => setSelectedRole(role)}
                    className="flex items-center gap-2.5 rounded-xl px-2.5 py-2.5 text-left transition-colors hover:bg-[var(--color-surface-dim)] w-full"
                    style={selectedRole?.id === role.id ? { background: 'color-mix(in oklab, var(--color-accent) 10%, transparent)' } : undefined}>
                    <span className="size-3.5 rounded-full shrink-0" style={{ background: role.color ?? 'var(--color-edge-bright)' }}/>
                    <span className="text-xs font-semibold truncate flex-1" style={{ color: role.color ?? (selectedRole?.id === role.id ? 'var(--color-accent)' : 'var(--color-ink-dim)') }}>{role.name}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      {role.memberCount !== null && role.memberCount > 0 && (
                        <span className="text-[10px] font-semibold text-[var(--color-ink-faint)]">{role.memberCount}</span>
                      )}
                      {role.hoist && <span className="size-1.5 rounded-full bg-[var(--color-accent)]" title="Hoisted"/>}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Role detail */}
            <div className="flex-1 overflow-y-auto p-4">
              {!selectedRole ? (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-center py-12">
                  <span className="text-[var(--color-edge-bright)]"><IconShield size={36}/></span>
                  <p className="text-sm text-[var(--color-ink-faint)]">Select a role to view permissions</p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {/* role header */}
                  <div className="rounded-xl border border-[var(--color-edge)] overflow-hidden"
                    style={selectedRole.color ? { borderColor: `${selectedRole.color}44` } : undefined}>
                    {/* Color stripe */}
                    <div className="h-1.5 w-full" style={{ background: selectedRole.color ?? 'var(--color-edge-bright)' }}/>
                    <div className="p-3 flex flex-col gap-2.5" style={selectedRole.color ? { background: `${selectedRole.color}0a` } : undefined}>
                      <div className="flex items-center gap-2.5">
                        <span className="size-6 rounded-full shrink-0 border-2" style={{ background: selectedRole.color ?? 'var(--color-edge-bright)', borderColor: selectedRole.color ? `${selectedRole.color}88` : 'var(--color-edge)' }}/>
                        <p className="font-bold text-sm" style={{ color: selectedRole.color ?? 'var(--color-ink)' }}>{selectedRole.name}</p>
                      </div>
                      {/* Stats row */}
                      <div className="flex items-center gap-2">
                        {selectedRole.memberCount !== null && (
                          <div className="flex-1 rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-2.5 py-2 text-center">
                            <p className="text-base font-extrabold text-[var(--color-ink)]">{selectedRole.memberCount.toLocaleString()}</p>
                            <p className="text-[10px] text-[var(--color-ink-faint)]">members</p>
                          </div>
                        )}
                        <div className="flex flex-col gap-1">
                          {selectedRole.hoist && <span className="chip text-[9px] border-[var(--color-edge)] text-[var(--color-ink-faint)]">Hoisted</span>}
                          {selectedRole.mentionable && <span className="chip text-[9px] border-[var(--color-edge)] text-[var(--color-ink-faint)]">Mentionable</span>}
                          {selectedRole.managed && <span className="chip text-[9px] border-[var(--color-edge)] text-[var(--color-ink-faint)]">Managed (bot)</span>}
                        </div>
                      </div>
                      <button onClick={() => setRoleMembersTarget(selectedRole)} className="btn btn-primary py-1.5 px-2.5 text-[11px] w-full">
                        <IconUsers size={12}/> View {selectedRole.memberCount != null ? selectedRole.memberCount.toLocaleString() : ''} Members
                      </button>
                    </div>
                  </div>
                  {/* permissions */}
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Permissions</p>
                  <div className="flex flex-col gap-1">
                    {getRolePerms(selectedRole).map(p => (
                      <div key={p.name} className="flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 border border-[var(--color-edge)]"
                        style={p.granted ? { borderColor: 'color-mix(in oklab, var(--color-good) 25%, transparent)', background: 'color-mix(in oklab, var(--color-good) 5%, transparent)' } : undefined}>
                        <span className={`flex size-4 shrink-0 items-center justify-center rounded-full ${p.granted ? 'bg-[var(--color-good)] text-black' : 'bg-[var(--color-surface-dim)] text-[var(--color-ink-faint)]'}`}>
                          {p.granted ? <IconCheck size={10}/> : <IconX size={9}/>}
                        </span>
                        <span className={`text-xs ${p.granted ? 'text-[var(--color-ink)] font-medium' : 'text-[var(--color-ink-faint)]'}`}>{p.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : null}
      </div>
      {roleMembersTarget && (
        <RoleMembersView
          roleId={roleMembersTarget.id}
          guildId={guildId}
          roleName={roleMembersTarget.name}
          roleColor={roleMembersTarget.color}
          onClose={() => setRoleMembersTarget(null)}
          onProfileClick={(uid) => { setRoleMembersTarget(null); onProfileClick(uid); }}
        />
      )}
    </div>
  );
}

// ─── React modal ──────────────────────────────────────────────────────────────
function ReactModal({ target, sessions, onClose, onReact }: {
  target: MonitorMessage; sessions: BotSession[];
  onClose: () => void;
  onReact: (emoji: string, botIds: string[]) => Promise<void>;
}) {
  const [emoji, setEmoji] = useState('');
  const [selectedBotIds, setSelectedBotIds] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const onlineSessions = sessions.filter((s) => s.status === 'online');
  const toggleBot = (id: string) => setSelectedBotIds((c) => c.includes(id) ? c.filter((x) => x !== id) : [...c, id]);

  const handle = async () => {
    if (!emoji.trim() || selectedBotIds.length === 0) { toast.bad('Pick at least one bot and enter an emoji'); return; }
    setBusy(true);
    try { await onReact(emoji.trim(), selectedBotIds); }
    finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md animate-rise panel p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-3"><span className="text-[var(--color-accent)]"><IconSmile size={15}/></span><h3 className="text-sm font-bold text-[var(--color-accent)]">React to message</h3></div>
        <div className="mb-4 rounded-lg bg-[var(--color-surface-dim)] border border-[var(--color-edge)] px-3 py-2">
          <p className="text-[10px] font-semibold text-[var(--color-ink-faint)] mb-0.5 uppercase tracking-wider">Message</p>
          <p className="truncate text-xs text-[var(--color-ink)]">{target.content.slice(0, 100) || '[no text]'}</p>
        </div>
        <div className="mb-3">
          <label className="label">Emoji</label>
          <input className="field mt-1 text-lg" placeholder="Emoji or <:name:id>" value={emoji} onChange={(e) => setEmoji(e.target.value)} autoFocus/>
        </div>
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1">
            <label className="label">Select bots</label>
            <div className="flex gap-2">
              <button type="button" onClick={() => setSelectedBotIds(onlineSessions.map((s) => s.id))} className="text-[10px] text-[var(--color-accent)] hover:underline">All</button>
              <button type="button" onClick={() => setSelectedBotIds([])} className="text-[10px] text-[var(--color-ink-faint)] hover:underline">None</button>
            </div>
          </div>
          <div className="flex max-h-40 flex-col gap-1 overflow-y-auto rounded-xl border border-[var(--color-edge)] bg-[var(--color-surface-dim)] p-2">
            {onlineSessions.length === 0 ? <p className="p-2 text-xs text-[var(--color-ink-faint)] text-center">No online bots</p>
            : onlineSessions.map((s) => (
              <button key={s.id} type="button" onClick={() => toggleBot(s.id)}
                className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-xs transition-colors hover:bg-[var(--color-edge)]"
                style={selectedBotIds.includes(s.id) ? { background: 'color-mix(in oklab, var(--color-accent) 8%, transparent)' } : undefined}>
                <span className="flex size-4 shrink-0 items-center justify-center rounded" style={selectedBotIds.includes(s.id) ? { background: 'var(--color-accent)', color: '#000' } : { border: '1.5px solid var(--color-edge-bright)' }}>
                  {selectedBotIds.includes(s.id) && <svg width="8" height="6" viewBox="0 0 8 6" fill="none"><path d="M1 3l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                </span>
                <Avatar url={s.avatarUrl} name={s.username} size={20}/>
                <span className="truncate font-semibold text-[var(--color-ink)]">{s.username}</span>
                <span className="ml-auto text-[9px] text-[var(--color-good)]">online</span>
              </button>
            ))}
          </div>
          {selectedBotIds.length > 0 && <p className="mt-1 text-[10px] text-[var(--color-accent)]">{selectedBotIds.length} bot{selectedBotIds.length !== 1 ? 's' : ''} selected</p>}
        </div>
        <div className="flex gap-2">
          <button className="btn flex-1" onClick={onClose} disabled={busy}>Cancel</button>
          <button className="btn btn-primary flex-1" onClick={handle} disabled={busy || !emoji.trim() || selectedBotIds.length === 0}>
            {busy ? <IconRefresh size={14} className="animate-spin-slow"/> : <IconSmile size={14}/>}
            {busy ? 'Reacting…' : `React (${selectedBotIds.length})`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Message bubble ───────────────────────────────────────────────────────────
function MessageBubble({ msg, canReact, onProfileClick, onReactClick }: {
  msg: MonitorMessage; canReact: boolean;
  onProfileClick: (userId: string) => void;
  onReactClick: (msg: MonitorMessage) => void;
}) {
  return (
    <div className="group flex items-start gap-2.5 rounded-xl px-3 py-2.5 transition-colors hover:bg-[var(--color-surface-dim)]">
      <button onClick={() => onProfileClick(msg.authorId)} className="shrink-0 mt-0.5">
        <Avatar url={msg.authorAvatar} name={msg.authorName} size={32}/>
      </button>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2 flex-wrap">
          <button onClick={() => onProfileClick(msg.authorId)} className="text-xs font-bold text-[var(--color-accent)] hover:underline">{msg.authorName}</button>
          <span className="text-[10px] text-[var(--color-ink-faint)]"><IconClock size={9} className="inline mr-0.5"/>{ago(msg.timestamp)}</span>
        </div>
        <p className="mt-0.5 break-words text-xs leading-relaxed text-[var(--color-ink)]">
          {msg.content || <em className="text-[var(--color-ink-faint)]">[no text content]</em>}
        </p>
        {msg.reactions.length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {msg.reactions.map((r, i) => (
              <span key={i} className="flex items-center gap-1 rounded-md border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-1.5 py-0.5 text-[11px]" style={r.me ? { borderColor: 'color-mix(in oklab, var(--color-accent) 40%, transparent)', background: 'color-mix(in oklab, var(--color-accent) 8%, transparent)' } : undefined}>
                {r.emoji.startsWith('<') ? <span className="font-mono text-[10px] text-[var(--color-ink-faint)]">{r.emoji}</span> : r.emoji}
                <span className="font-mono text-[var(--color-ink-dim)]">{r.count}</span>
              </span>
            ))}
          </div>
        )}
      </div>
      {canReact && (
        <button onClick={() => onReactClick(msg)} className="shrink-0 rounded-lg border border-transparent p-1.5 text-[var(--color-ink-faint)] opacity-0 transition-all group-hover:border-[var(--color-edge)] group-hover:opacity-100 hover:text-[var(--color-accent)]" title="React">
          <IconSmile size={13}/>
        </button>
      )}
    </div>
  );
}

// ─── Message feed (text channel view) ────────────────────────────────────────
function MessageFeed({ channelId, channelName, sessions, role, permissions, onProfileClick, onBack, onAccessDenied }: {
  channelId: string; channelName: string; sessions: BotSession[];
  role: UserRole; permissions?: KeyPermissions;
  onProfileClick: (userId: string) => void; onBack: () => void;
  onAccessDenied?: () => void;
}) {
  const toast = useToast();
  const [messages, setMessages] = useState<MonitorMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [reactTarget, setReactTarget] = useState<MonitorMessage | null>(null);
  const [selectedBotId, setSelectedBotId] = useState<string>('auto');
  const canReact = role === 'owner' || permissions?.canUseAutoReact;
  const onlineSessions = sessions.filter((s) => s.status === 'online');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try { const msgs = await api.monitor.messages(channelId, selectedBotId === 'auto' ? undefined : selectedBotId, 30); setMessages(msgs); }
    catch (e) {
      const msg = e instanceof ApiError ? e.message : 'Failed to load messages';
      setError(msg);
      if (msg.includes('Missing Access') || msg.includes('50001') || msg.includes('403')) {
        onAccessDenied?.();
      }
    }
    finally { setLoading(false); }
  }, [channelId, selectedBotId, onAccessDenied]);

  useEffect(() => { void load(); }, [load]);

  const handleReact = async (emoji: string, botIds: string[]) => {
    if (!reactTarget) return;
    try {
      const result = await api.monitor.react(reactTarget.channelId, reactTarget.id, emoji, botIds);
      if (result.sent > 0) { toast.ok(`Reacted with ${result.sent} bot${result.sent === 1 ? '' : 's'}`); setReactTarget(null); void load(); }
      else toast.bad(result.errors?.[0] ?? 'All reactions failed');
    } catch (e) { toast.bad(e instanceof ApiError ? e.message : 'React failed'); }
  };

  return (
    <div className="flex flex-col gap-3 h-full">
      <div className="flex items-center gap-2">
        <button onClick={onBack} className="flex items-center gap-1 text-[11px] text-[var(--color-ink-faint)] hover:text-[var(--color-accent)] transition-colors">
          <IconChevronLeft size={13}/> Back
        </button>
        <span className="text-[var(--color-edge-bright)]">·</span>
        <p className="text-xs font-bold text-[var(--color-ink)] flex items-center gap-1">
          <span className="text-[var(--color-accent-2)]"><IconHash size={12}/></span>{channelName}
        </p>
        <div className="ml-auto flex items-center gap-2">
          <select className="field py-1 text-xs" style={{ width: 'auto', minWidth: 110 }} value={selectedBotId} onChange={(e) => setSelectedBotId(e.target.value)}>
            <option value="auto">Auto bot</option>
            {onlineSessions.map((s) => <option key={s.id} value={s.id}>{s.username}</option>)}
          </select>
          <button onClick={load} disabled={loading} className="btn px-2.5 py-1.5 text-xs">
            <IconRefresh size={13} className={loading ? 'animate-spin-slow' : undefined}/>
          </button>
        </div>
      </div>
      {error ? (
        error.includes('Missing Access') || error.includes('50001') || error.includes('403') ? (
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <span className="text-[var(--color-ink-faint)]"><IconLock size={32}/></span>
            <p className="text-sm font-semibold text-[var(--color-ink-dim)]">No Access</p>
            <p className="text-xs text-[var(--color-ink-faint)]">The bot doesn't have permission to read this channel.</p>
          </div>
        ) : (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-bad)]/30 p-3 text-xs text-[var(--color-bad)]"><IconAlert size={13}/> {error}</div>
        )
      )
      : loading && messages.length === 0 ? <div className="flex items-center justify-center gap-2 py-10 text-sm text-[var(--color-ink-faint)]"><IconRefresh size={16} className="animate-spin-slow"/> Loading…</div>
      : messages.length === 0 ? <p className="py-8 text-center text-sm text-[var(--color-ink-faint)]">No messages found</p>
      : <div className="flex flex-col gap-0.5 max-h-[460px] overflow-y-auto pr-1">
          {[...messages].reverse().map((msg) => <MessageBubble key={msg.id} msg={msg} canReact={!!canReact} onProfileClick={onProfileClick} onReactClick={setReactTarget}/>)}
        </div>}
      {reactTarget && <ReactModal target={reactTarget} sessions={sessions} onClose={() => setReactTarget(null)} onReact={handleReact}/>}
    </div>
  );
}

// ─── Channel Lookup (with live toggle) ───────────────────────────────────────
function ChannelLookup({ sessions, role, permissions, onProfileClick, onJoinVoice }: {
  sessions: BotSession[]; role: UserRole; permissions?: KeyPermissions;
  onProfileClick: (userId: string) => void;
  onJoinVoice?: (guildId: string, channelId: string) => void;
}) {
  const toast = useToast();
  const [channelId, setChannelId] = useState('');
  const [selectedBotId, setSelectedBotId] = useState('auto');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MonitorChannelLookup | null>(null);
  const [error, setError] = useState('');
  const [reactTarget, setReactTarget] = useState<MonitorMessage | null>(null);
  const [rolesTarget, setRolesTarget] = useState<{ userId: string; guildId: string } | null>(null);
  const [live, setLive] = useState(false);
  const liveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastChannelIdRef = useRef('');

  const canReact = role === 'owner' || permissions?.canUseAutoReact;
  const onlineSessions = sessions.filter((s) => s.status === 'online');

  const lookup = useCallback(async (id?: string) => {
    const target = (id ?? channelId).trim();
    if (!/^\d{17,20}$/.test(target)) {
      if (!id) setError('Enter a valid Discord channel ID (17-20 digits)');
      return;
    }
    setLoading(true); setError('');
    if (!id) setResult(null);
    try {
      const data = await api.monitor.channelLookup(target, selectedBotId === 'auto' ? undefined : selectedBotId);
      setResult(data);
      lastChannelIdRef.current = target;
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Lookup failed');
      setLive(false);
    } finally { setLoading(false); }
  }, [channelId, selectedBotId]);

  // Live refresh timer
  useEffect(() => {
    if (liveTimerRef.current) { clearInterval(liveTimerRef.current); liveTimerRef.current = null; }
    if (!live || !lastChannelIdRef.current) return;
    liveTimerRef.current = setInterval(() => { void lookup(lastChannelIdRef.current); }, 4000);
    return () => { if (liveTimerRef.current) clearInterval(liveTimerRef.current); };
  }, [live, lookup]);

  const handleReact = async (emoji: string, botIds: string[]) => {
    if (!reactTarget) return;
    try {
      const res = await api.monitor.react(reactTarget.channelId, reactTarget.id, emoji, botIds);
      if (res.sent > 0) { toast.ok(`Reacted with ${res.sent} bot${res.sent === 1 ? '' : 's'}`); setReactTarget(null); }
      else toast.bad(res.errors?.[0] ?? 'All reactions failed');
    } catch (e) { toast.bad(e instanceof ApiError ? e.message : 'React failed'); }
  };

  return (
    <div className="panel p-4 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[var(--color-accent)]"><IconSearch size={14}/></span>
          <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Channel Lookup</h3>
        </div>
        {result && (
          <button onClick={() => setLive(v => !v)}
            className="chip cursor-pointer text-xs transition-colors"
            style={live ? { color: 'var(--color-good)', borderColor: 'var(--color-good)', background: 'color-mix(in oklab, var(--color-good) 12%, transparent)' } : { color: 'var(--color-ink-faint)', borderColor: 'var(--color-edge)' }}>
            <span className={`inline-flex size-1.5 rounded-full ${live ? 'animate-pulse bg-[var(--color-good)]' : 'bg-[var(--color-ink-faint)]'}`}/>
            <IconWifi size={11}/> Live {live ? 'ON' : 'OFF'}
          </button>
        )}
      </div>
      <p className="text-[11px] text-[var(--color-ink-faint)] -mt-2">Enter any channel ID — text or voice. Shows messages or who's inside.</p>

      <div className="flex gap-2">
        <input className="field flex-1 py-1.5 text-xs font-mono" placeholder="Channel ID (e.g. 123456789012345678)"
          value={channelId} onChange={(e) => setChannelId(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void lookup()}/>
        <select className="field py-1.5 text-xs shrink-0" style={{ width: 'auto', minWidth: 110 }} value={selectedBotId} onChange={(e) => setSelectedBotId(e.target.value)}>
          <option value="auto">Auto bot</option>
          {onlineSessions.map((s) => <option key={s.id} value={s.id}>{s.username}</option>)}
        </select>
        <button onClick={() => void lookup()} disabled={loading} className="btn btn-primary px-3 py-1.5 text-xs shrink-0">
          {loading ? <IconRefresh size={13} className="animate-spin-slow"/> : <IconSearch size={13}/>}
          {loading ? 'Looking…' : 'Lookup'}
        </button>
      </div>

      {error && (
        error.includes('Missing Access') || error.includes('50001') || error.includes('403') ? (
          <div className="flex flex-col items-center gap-3 py-8 text-center rounded-xl border border-[var(--color-edge)] p-4">
            <span className="text-[var(--color-ink-faint)]"><IconLock size={28}/></span>
            <p className="text-sm font-semibold text-[var(--color-ink-dim)]">No Access</p>
            <p className="text-xs text-[var(--color-ink-faint)]">The selected bot can't access this channel. Try a different bot.</p>
          </div>
        ) : (
          <div className="flex items-center gap-2 rounded-lg border border-[var(--color-bad)]/30 p-3 text-xs text-[var(--color-bad)]"><IconAlert size={13}/> {error}</div>
        )
      )}

      {result && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-2.5">
            <span className="text-[var(--color-accent)] shrink-0">{result.type === 'text' ? <IconHash size={14}/> : <IconSpeaker size={14}/>}</span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-[var(--color-ink)]">{result.name}</p>
              <p className="text-[10px] text-[var(--color-ink-faint)]">
                {result.type === 'text' ? 'Text channel' : result.type === 'stage' ? 'Stage channel' : 'Voice channel'}
                {result.guildName ? ` · ${result.guildName}` : ''}
                {live && <span className="ml-2 text-[var(--color-good)] animate-pulse">● live</span>}
              </p>
            </div>
            <span className="chip shrink-0 text-[10px]" style={result.type === 'text' ? { color: 'var(--color-accent-2)', borderColor: 'color-mix(in oklab, var(--color-accent-2) 35%, transparent)' } : { color: 'var(--color-good)', borderColor: 'color-mix(in oklab, var(--color-good) 35%, transparent)' }}>
              {result.type}
            </span>
          </div>

          {/* Voice members */}
          {result.type !== 'text' && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-semibold text-[var(--color-ink-faint)]"><IconUsers size={11} className="inline mr-1"/>{result.members.length} member{result.members.length !== 1 ? 's' : ''} in channel</p>
                {onJoinVoice && result.guildId && (
                  <button onClick={() => onJoinVoice(result.guildId!, result.id)} className="btn py-1 px-2.5 text-[10px]" style={{ color: 'var(--color-accent)', borderColor: 'color-mix(in oklab, var(--color-accent) 30%, transparent)' }}>
                    <IconSpeaker size={10}/> Dispatch bots here
                  </button>
                )}
              </div>
              {result.members.length === 0
                ? <p className="py-3 text-center text-xs text-[var(--color-ink-faint)]">No one in this channel</p>
                : <div className="flex flex-wrap gap-2">
                    {result.members.map((m) => (
                      <VoiceMemberChip key={m.userId} member={m} guildId={result.guildId ?? undefined}
                        onClick={onProfileClick}
                        onRolesClick={result.guildId ? (uid, gid) => setRolesTarget({ userId: uid, guildId: gid }) : undefined}/>
                    ))}
                  </div>}
            </div>
          )}

          {/* Text messages */}
          {result.type === 'text' && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-semibold text-[var(--color-ink-faint)]">Recent messages</p>
                {!live && <button onClick={() => void lookup()} disabled={loading} className="btn px-2 py-1 text-[10px]"><IconRefresh size={11} className={loading ? 'animate-spin-slow' : undefined}/> Refresh</button>}
              </div>
              {result.messages.length === 0
                ? <p className="py-3 text-center text-xs text-[var(--color-ink-faint)]">No messages</p>
                : <div className="flex flex-col gap-0.5 max-h-[400px] overflow-y-auto pr-1">
                    {[...result.messages].reverse().map((msg) => (
                      <MessageBubble key={msg.id} msg={msg} canReact={!!canReact} onProfileClick={onProfileClick} onReactClick={setReactTarget}/>
                    ))}
                  </div>}
            </div>
          )}
        </div>
      )}

      {reactTarget && <ReactModal target={reactTarget} sessions={sessions} onClose={() => setReactTarget(null)} onReact={handleReact}/>}
      {rolesTarget && <MemberRolesPopup userId={rolesTarget.userId} guildId={rolesTarget.guildId} onClose={() => setRolesTarget(null)} onViewPermissions={(uid, gid) => { setRolesTarget(null); setTimeout(() => setRolesTarget({ userId: uid, guildId: gid }), 50); }}/>}
    </div>
  );
}

// ─── Main Monitor ─────────────────────────────────────────────────────────────
interface Props {
  sessions: BotSession[];
  role: UserRole;
  permissions?: KeyPermissions;
  onJoinVoice?: (guildId: string, channelId: string) => void;
}

export function Monitor({ sessions, role, permissions, onJoinVoice }: Props) {
  const toast = useToast();
  const [guilds, setGuilds] = useState<MonitorGuildSummary[]>([]);
  const [guildsLoading, setGuildsLoading] = useState(true);
  // Server, channel and Live switch are remembered, so coming back lands on the same screen.
  const [selectedGuildId, setSelectedGuildId] = usePersistedState<string | null>('monitor:guild', null);
  const [guildData, setGuildData] = useState<MonitorGuild | null>(null);
  const [guildLoading, setGuildLoading] = useState(false);
  const [selectedChannelId, setSelectedChannelId] = usePersistedState<string | null>('monitor:channel', null);
  const [profileUserId, setProfileUserId] = useState<string | null>(null);
  const [rolesTarget, setRolesTarget] = useState<{ userId: string; guildId: string } | null>(null);
  const [permTarget, setPermTarget] = useState<{ userId: string; guildId: string } | null>(null);
  const [guildRolesGuildId, setGuildRolesGuildId] = useState<string | null>(null);
  const [guildSearch, setGuildSearch] = useState('');
  const [channelSearch, setChannelSearch] = useState('');
  const [autoRefresh, setAutoRefresh] = usePersistedState<boolean>('monitor:live', true);
  const [lockedChannelIds, setLockedChannelIds] = useState<Set<string>>(new Set());
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const activeGuildRef = useRef<string | null>(selectedGuildId);
  const prevGuildRef = useRef<string | null>(selectedGuildId);
  const guildBusyRef = useRef(false);
  activeGuildRef.current = selectedGuildId;

  const selectedChannel: MonitorChannel | null =
    guildData?.channels.find((c) => c.id === selectedChannelId) ?? null;
  const setSelectedChannel = useCallback(
    (channel: MonitorChannel | null) => setSelectedChannelId(channel?.id ?? null),
    [setSelectedChannelId],
  );

  useEffect(() => {
    setGuildsLoading(true);
    api.monitor.guilds()
      .then((g) => setGuilds(g))
      .catch((e: unknown) => toast.bad(e instanceof ApiError ? e.message : 'Failed to load guilds'))
      .finally(() => setGuildsLoading(false));
  }, []);

  const loadGuild = useCallback(async (guildId: string) => {
    guildBusyRef.current = true;
    setGuildLoading(true);
    try {
      const data = await api.monitor.guild(guildId);
      // A slow answer for the server we just left must not overwrite the one on screen.
      if (activeGuildRef.current === guildId) setGuildData(data);
    }
    catch (e) { if (activeGuildRef.current === guildId) toast.bad(e instanceof ApiError ? e.message : 'Failed to load guild'); }
    finally { guildBusyRef.current = false; setGuildLoading(false); }
  }, [toast]);

  useEffect(() => {
    if (!selectedGuildId) return;
    setGuildData(null); // clear stale data from previous guild
    // Only a real server change clears the channel; the first run after a reload keeps it.
    if (prevGuildRef.current !== selectedGuildId) {
      setSelectedChannelId(null);
      prevGuildRef.current = selectedGuildId;
    }
    setLockedChannelIds(new Set());
    void loadGuild(selectedGuildId);
  }, [selectedGuildId, loadGuild, setSelectedChannelId]);

  // Voice auto-refresh (5s)
  useEffect(() => {
    if (refreshTimerRef.current) { clearInterval(refreshTimerRef.current); refreshTimerRef.current = null; }
    if (!autoRefresh || !selectedGuildId) return;
    // Skip while the page is hidden or the previous poll is still running, and catch up the
    // moment the page is visible again.
    const tick = () => {
      if (document.visibilityState === 'hidden' || guildBusyRef.current) return;
      void loadGuild(selectedGuildId);
    };
    refreshTimerRef.current = setInterval(tick, 5000);
    document.addEventListener('visibilitychange', tick);
    return () => {
      if (refreshTimerRef.current) clearInterval(refreshTimerRef.current);
      document.removeEventListener('visibilitychange', tick);
    };
  }, [autoRefresh, selectedGuildId, loadGuild]);

  const filteredGuilds = guilds.filter((g) => g.name.toLowerCase().includes(guildSearch.toLowerCase()));
  const filteredChannels = guildData ? guildData.channels.filter((c) => c.name.toLowerCase().includes(channelSearch.toLowerCase()) || (c.parentName ?? '').toLowerCase().includes(channelSearch.toLowerCase())) : [];
  const voiceChannels = filteredChannels.filter((c) => c.type === 'voice' || c.type === 'stage');
  const textChannels = filteredChannels.filter((c) => c.type === 'text');
  const selectedGuild = guilds.find((g) => g.id === selectedGuildId);

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-4">
      {/* ── Sidebar ── */}
      <div className="lg:col-span-1 flex flex-col gap-3">
        <div className="panel p-3 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Servers</p>
            {guildsLoading && <IconRefresh size={13} className="animate-spin-slow text-[var(--color-ink-faint)]"/>}
          </div>
          <input className="field py-1.5 text-xs" placeholder="Search servers…" value={guildSearch} onChange={(e) => setGuildSearch(e.target.value)}/>
          {filteredGuilds.length === 0 && !guildsLoading
            ? <p className="py-4 text-center text-xs text-[var(--color-ink-faint)]">{guildSearch ? 'No results' : 'No servers found'}</p>
            : <div className="flex max-h-[50vh] flex-col gap-0.5 overflow-y-auto">
                {filteredGuilds.map((g) => (
                  <button key={g.id} onClick={() => setSelectedGuildId(g.id)}
                    className="flex items-center gap-2.5 rounded-xl px-2 py-2 text-left transition-colors hover:bg-[var(--color-surface-dim)]"
                    style={selectedGuildId === g.id ? { background: 'color-mix(in oklab, var(--color-accent) 10%, transparent)' } : undefined}>
                    <GuildIcon guild={g} size={30}/>
                    <div className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-semibold" style={selectedGuildId === g.id ? { color: 'var(--color-accent)' } : { color: 'var(--color-ink-dim)' }}>{g.name}</span>
                      {g.memberCount != null && <span className="text-[10px] text-[var(--color-ink-faint)]"><IconUsers size={9} className="inline mr-0.5"/>{g.memberCount.toLocaleString()} members</span>}
                    </div>
                  </button>
                ))}
              </div>}
        </div>
      </div>

      {/* ── Main content ── */}
      <div className="lg:col-span-3 flex flex-col gap-4">
        {!selectedGuildId ? (
          <div className="panel flex flex-col items-center gap-4 p-12 text-center">
            <span className="text-[var(--color-edge-bright)]"><IconRadar size={48}/></span>
            <p className="text-sm font-semibold text-[var(--color-ink-dim)]">Select a server</p>
            <p className="max-w-xs text-xs text-[var(--color-ink-faint)]">Choose a server from the left to browse its channels and see who's in voice.</p>
          </div>
        ) : guildLoading && !guildData ? (
          <div className="panel flex flex-col items-center gap-3 p-12 text-center"><IconRefresh size={24} className="animate-spin-slow text-[var(--color-accent)]"/><p className="text-sm text-[var(--color-ink-faint)]">Loading server…</p></div>
        ) : guildData ? (
          <>
            {/* Guild header */}
            <div className="panel flex items-center justify-between gap-3 p-4">
              <div className="flex items-center gap-3 min-w-0">
                {selectedGuild && <GuildIcon guild={selectedGuild} size={40}/>}
                <div className="min-w-0">
                  <h2 className="truncate text-base font-extrabold text-white">{guildData.name}</h2>
                  <p className="text-xs text-[var(--color-ink-faint)]">
                    {(() => {
                      const inVoice = guildData.channels.filter((c) => c.type !== 'text').reduce((s, c) => s + (c.memberCount ?? 0), 0);
                      const voiceChs = guildData.channels.filter((c) => c.type !== 'text').length;
                      const textChs = guildData.channels.filter((c) => c.type === 'text').length;
                      return <>{inVoice > 0 ? <span style={{color:'var(--color-good)'}}>{inVoice} in voice</span> : '0 in voice'} · {voiceChs} voice · {textChs} text</>;
                    })()}
                    {guildData.memberCount != null && <> · <IconUsers size={10} className="inline mx-0.5"/>{guildData.memberCount.toLocaleString()} members</>}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => setGuildRolesGuildId(selectedGuildId)} className="btn px-2.5 py-1.5 text-xs" title="View server roles">
                  <IconShield size={13}/> Roles
                </button>
                <button onClick={() => setAutoRefresh((v) => !v)}
                  className="chip cursor-pointer text-xs"
                  style={autoRefresh ? { color: 'var(--color-good)', borderColor: 'var(--color-good)', background: 'color-mix(in oklab, var(--color-good) 12%, transparent)' } : { color: 'var(--color-ink-faint)' }}>
                  <span className={`inline-block size-1.5 rounded-full ${autoRefresh ? 'animate-pulse bg-[var(--color-good)]' : 'bg-[var(--color-ink-faint)]'}`}/>
                  Live {autoRefresh ? 'ON' : 'OFF'}
                </button>
                <button onClick={() => loadGuild(selectedGuildId!)} disabled={guildLoading} className="btn px-2.5 py-1.5 text-xs">
                  <IconRefresh size={13} className={guildLoading ? 'animate-spin-slow' : undefined}/>
                </button>
              </div>
            </div>

            {/* filter bar shared */}
            <input className="field py-1.5 text-xs" placeholder="Filter voice & text channels…" value={channelSearch} onChange={(e) => setChannelSearch(e.target.value)}/>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {/* Voice channels */}
              <div className="panel p-4 flex flex-col gap-3">
                <div className="flex items-center gap-2">
                  <IconSpeaker size={14} className="text-[var(--color-accent)]"/>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Voice Channels</h3>
                  <div className="ml-auto flex items-center gap-1.5">
                    {(() => {
                      const inVoice = voiceChannels.reduce((s, c) => s + (c.members?.length ?? 0), 0);
                      return inVoice > 0 ? (
                        <span className="chip text-[10px]" style={{ color: 'var(--color-good)', borderColor: 'color-mix(in oklab, var(--color-good) 35%, transparent)', background: 'color-mix(in oklab, var(--color-good) 8%, transparent)' }}>
                          <IconUsers size={9}/>{inVoice} in voice
                        </span>
                      ) : null;
                    })()}
                    <span className="chip border-[var(--color-edge)] text-[10px] text-[var(--color-ink-faint)]">{voiceChannels.length}</span>
                  </div>
                </div>
                {voiceChannels.length === 0
                  ? <p className="py-4 text-center text-xs text-[var(--color-ink-faint)]">{channelSearch ? 'No matching voice channels' : 'No voice channels'}</p>
                  : (() => {
                    const activeVoice = voiceChannels.filter(c => (c.members ?? []).length > 0);
                    const emptyVoice = voiceChannels.filter(c => (c.members ?? []).length === 0);
                    return (
                      <div className="flex max-h-[55vh] flex-col gap-2 overflow-y-auto pr-1">
                        {/* Active channels first — always visible */}
                        {activeVoice.map((ch) => {
                          const members = ch.members ?? [];
                          return (
                            <div key={ch.id} className="rounded-xl overflow-hidden transition-all"
                              style={{ border: '1px solid color-mix(in oklab, var(--color-good) 40%, transparent)', background: 'color-mix(in oklab, var(--color-good) 5%, var(--color-surface-dim))', boxShadow: '0 0 0 1px color-mix(in oklab, var(--color-good) 12%, transparent)' }}>
                              <div className="flex items-center gap-2.5 px-3 py-2.5">
                                <span className="shrink-0 relative">
                                  <span className="text-[var(--color-good)]">
                                    {ch.type === 'stage'
                                      ? <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="6" r="3"/><path d="M3 14c0-2.8 2.2-5 5-5s5 2.2 5 5"/><path d="M8 3V1M5.5 4.5L4 3M10.5 4.5L12 3"/></svg>
                                      : <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M11 1v14M5 3v10M8 2v12M2 5v6M14 5v6"/></svg>}
                                  </span>
                                  <span className="absolute -bottom-0.5 -right-0.5 flex size-2 rounded-full bg-[var(--color-good)]">
                                    <span className="animate-ping absolute inline-flex size-full rounded-full bg-[var(--color-good)] opacity-50"/>
                                  </span>
                                </span>
                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-sm font-bold text-[var(--color-ink)] leading-snug">{ch.name || <span className="text-[var(--color-ink-faint)] italic text-xs">Unnamed</span>}</p>
                                  {ch.parentName && <p className="text-[10px] text-[var(--color-ink-faint)] truncate">{ch.parentName}</p>}
                                </div>
                                <span className="flex items-center gap-1 rounded-lg px-2 py-0.5 text-[11px] font-bold shrink-0 border"
                                  style={{ borderColor: 'color-mix(in oklab, var(--color-good) 40%, transparent)', color: 'var(--color-good)', background: 'color-mix(in oklab, var(--color-good) 12%, transparent)' }}>
                                  <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M2 8a6 6 0 1 0 12 0A6 6 0 0 0 2 8z"/><path d="M8 5v3l2 2"/></svg>
                                  {members.length}
                                </span>
                              </div>
                              {/* Members always visible */}
                              <div className="border-t px-2.5 pb-2.5 pt-2 flex flex-wrap gap-1.5"
                                style={{ borderColor: 'color-mix(in oklab, var(--color-good) 20%, transparent)' }}>
                                {members.map((m) => (
                                  <VoiceMemberChip key={m.userId} member={m} guildId={guildData.id} onClick={setProfileUserId}
                                    onRolesClick={(uid, gid) => setRolesTarget({ userId: uid, guildId: gid })}/>
                                ))}
                              </div>
                              {onJoinVoice && (
                                <div className="border-t px-2 py-1.5" style={{ borderColor: 'color-mix(in oklab, var(--color-good) 20%, transparent)' }}>
                                  <button onClick={() => onJoinVoice(guildData.id, ch.id)} className="btn w-full py-1.5 text-[10px]" style={{ color: 'var(--color-accent)', borderColor: 'color-mix(in oklab, var(--color-accent) 30%, transparent)' }}>
                                    <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M11 1v14M5 3v10M8 2v12M2 5v6M14 5v6"/></svg> Dispatch bots here
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}

                        {/* Empty channels — compact rows */}
                        {emptyVoice.length > 0 && (
                          <div className="flex flex-col gap-0.5 mt-1">
                            {activeVoice.length > 0 && (
                              <p className="text-[9px] font-semibold uppercase tracking-wider text-[var(--color-ink-faint)] px-1 mb-1">
                                Empty channels ({emptyVoice.length})
                              </p>
                            )}
                            {emptyVoice.map((ch) => (
                              <div key={ch.id} className="flex items-center gap-2 rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-1.5 transition-colors hover:border-[var(--color-accent)]/20">
                                <span className="shrink-0 text-[var(--color-ink-faint)]">
                                  {ch.type === 'stage'
                                    ? <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="6" r="3"/><path d="M3 14c0-2.8 2.2-5 5-5s5 2.2 5 5"/></svg>
                                    : <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M11 1v14M5 3v10M8 2v12M2 5v6M14 5v6"/></svg>}
                                </span>
                                <p className="truncate text-xs text-[var(--color-ink-faint)] flex-1">{ch.name}</p>
                                {ch.parentName && <p className="text-[10px] text-[var(--color-ink-faint)] shrink-0 truncate max-w-[80px]">{ch.parentName}</p>}
                                <span className="text-[10px] text-[var(--color-ink-faint)] shrink-0 border border-[var(--color-edge)] rounded px-1">0</span>
                                {onJoinVoice && (
                                  <button onClick={() => onJoinVoice(guildData.id, ch.id)} className="shrink-0 rounded-md border border-[var(--color-edge)] px-1.5 py-0.5 text-[9px] text-[var(--color-ink-faint)] hover:border-[var(--color-accent)]/30 hover:text-[var(--color-accent)] transition-colors">
                                    Send
                                  </button>
                                )}
                              </div>
                            ))}
                          </div>
                        )}

                        {!channelSearch && activeVoice.length === 0 && (
                          <p className="py-2 text-center text-[10px] text-[var(--color-ink-faint)]">No one in voice right now</p>
                        )}
                      </div>
                    );
                  })()}
              </div>

              {/* Text channels */}
              <div className="panel p-4 flex flex-col gap-3">
                {selectedChannel ? (
                  <MessageFeed channelId={selectedChannel.id} channelName={selectedChannel.name} sessions={sessions} role={role} permissions={permissions} onProfileClick={setProfileUserId} onBack={() => setSelectedChannel(null)} onAccessDenied={() => setLockedChannelIds(prev => { const next = new Set(prev); next.add(selectedChannel.id); return next; })}/>
                ) : (
                  <>
                    <div className="flex items-center gap-2">
                      <span className="text-[var(--color-accent-2)]"><IconHash size={14}/></span>
                      <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Text Channels</h3>
                      <span className="ml-auto chip border-[var(--color-edge)] text-[10px] text-[var(--color-ink-faint)]">{textChannels.length}</span>
                    </div>
                    {textChannels.length === 0
                      ? <p className="py-4 text-center text-xs text-[var(--color-ink-faint)]">{channelSearch ? 'No matching text channels' : 'No text channels'}</p>
                      : <div className="flex max-h-[55vh] flex-col gap-0.5 overflow-y-auto pr-1">
                          {textChannels.map((ch) => {
                            const isLocked = lockedChannelIds.has(ch.id);
                            return isLocked ? (
                              /* Locked channel — red border, visible lock badge */
                              <div key={ch.id}
                                className="flex items-center gap-2.5 rounded-xl px-3 py-2 border"
                                style={{ borderColor: 'color-mix(in oklab, var(--color-bad) 30%, transparent)', background: 'color-mix(in oklab, var(--color-bad) 5%, transparent)' }}
                                title="Bot has no access to this channel">
                                <span style={{ color: 'var(--color-bad)' }} className="shrink-0">
                                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="10" height="8" rx="1.5"/><path d="M5 7V5a3 3 0 016 0v2"/></svg>
                                </span>
                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-xs font-semibold" style={{ color: 'color-mix(in oklab, var(--color-bad) 80%, var(--color-ink-faint))' }}>{ch.name}</p>
                                  {ch.parentName && <p className="text-[10px] text-[var(--color-ink-faint)]">{ch.parentName}</p>}
                                </div>
                                <span className="shrink-0 flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[9px] font-semibold"
                                  style={{ borderColor: 'color-mix(in oklab, var(--color-bad) 35%, transparent)', color: 'var(--color-bad)', background: 'color-mix(in oklab, var(--color-bad) 8%, transparent)' }}>
                                  <svg width="8" height="8" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M2 2l8 8M10 2L2 10"/></svg>
                                  no access
                                </span>
                              </div>
                            ) : (
                              /* Normal channel */
                              <button key={ch.id} onClick={() => setSelectedChannel(ch)}
                                className="group flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-left border border-transparent transition-colors hover:bg-[var(--color-surface-dim)] hover:border-[var(--color-edge)]">
                                <span className="shrink-0 text-[var(--color-ink-faint)] transition-colors group-hover:text-[var(--color-accent-2)]">
                                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><line x1="4" y1="5" x2="12" y2="5"/><line x1="3" y1="9" x2="13" y2="9"/><line x1="6" y1="2" x2="5" y2="14"/><line x1="11" y1="2" x2="10" y2="14"/></svg>
                                </span>
                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-xs font-semibold text-[var(--color-ink-dim)] group-hover:text-[var(--color-ink)] transition-colors">{ch.name}</p>
                                  {ch.parentName && <p className="text-[10px] text-[var(--color-ink-faint)]">{ch.parentName}</p>}
                                </div>
                                <span className="shrink-0 text-[10px] text-[var(--color-ink-faint)] opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                                  View
                                  <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="7" cy="7" r="5"/><path d="M11 11l3 3"/></svg>
                                </span>
                              </button>
                            );
                          })}
                        </div>}
                  </>
                )}
              </div>
            </div>
          </>
        ) : null}
      </div>

      {/* ── Channel Lookup ── */}
      <div className="lg:col-span-4">
        <ChannelLookup sessions={sessions} role={role} permissions={permissions} onProfileClick={setProfileUserId} onJoinVoice={onJoinVoice}/>
      </div>

      {/* Popups */}
      {profileUserId && <ProfilePopup userId={profileUserId} onClose={() => setProfileUserId(null)} onJoinVoice={onJoinVoice}/>}
      {rolesTarget && (
        <MemberRolesPopup userId={rolesTarget.userId} guildId={rolesTarget.guildId}
          onClose={() => setRolesTarget(null)}
          onViewPermissions={(uid, gid) => { setRolesTarget(null); setTimeout(() => setPermTarget({ userId: uid, guildId: gid }), 0); }}/>
      )}
      {permTarget && <MemberPermissionsPopup userId={permTarget.userId} guildId={permTarget.guildId} onClose={() => setPermTarget(null)}/>}
      {guildRolesGuildId && selectedGuild && (
        <GuildRolesPanel guildId={guildRolesGuildId} guildName={selectedGuild.name} onClose={() => setGuildRolesGuildId(null)} onProfileClick={(uid) => { setGuildRolesGuildId(null); setProfileUserId(uid); }}/>
      )}
    </div>
  );
}
