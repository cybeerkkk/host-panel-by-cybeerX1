import { useCallback, useEffect, useRef, useState } from 'react';
import type { BotSession, KeyPermissions, UserRole } from '@shared/types';
import { IconBolt, IconMessage, IconSpeaker, IconStop, IconSend, IconLoop, IconTarget } from './Icons';

/* ── helpers ──────────────────────────────────────────────── */
const isSnowflake = (v: string) => /^\d{17,20}$/.test(v.trim());

function spinMessage(template: string): string {
  let result = template.replace(/\{([^}]+)\}/g, (_: string, inner: string) => {
    const choices = inner.split('|');
    return choices[Math.floor(Math.random() * choices.length)];
  });
  const zw = ['\u200b', '\u200c', '\u200d', '\u2060'];
  const n = Math.floor(Math.random() * 3) + 1;
  for (let i = 0; i < n; i++) {
    const pos = Math.floor(Math.random() * (result.length + 1));
    result = result.slice(0, pos) + zw[Math.floor(Math.random() * zw.length)] + result.slice(pos);
  }
  return result;
}

const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

/* ── sub-components ───────────────────────────────────────── */
function Badge({ sent, total, active, stopped }: { sent: number; total: number; active: boolean; stopped: boolean }) {
  if (stopped) return (
    <span className="chip" style={{ color: 'var(--color-bad)', borderColor: 'color-mix(in oklab,var(--color-bad) 35%,transparent)', background: 'color-mix(in oklab,var(--color-bad) 9%,transparent)' }}>
      Stopped · {sent} sent
    </span>
  );
  if (!active) return null;
  const pct = total > 0 ? Math.round((sent / total) * 100) : null;
  return (
    <span className="chip flex items-center gap-1.5" style={{ color: 'var(--color-accent)', borderColor: 'color-mix(in oklab,var(--color-accent) 35%,transparent)', background: 'color-mix(in oklab,var(--color-accent) 9%,transparent)' }}>
      <span className="relative flex size-1.5 shrink-0">
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-accent)] opacity-60" />
        <span className="relative inline-flex size-1.5 rounded-full bg-[var(--color-accent)]" />
      </span>
      {sent}{total > 0 ? `/${total}` : ''}{pct !== null ? ` · ${pct}%` : ''}
    </span>
  );
}

function Log({ lines }: { lines: { id: number; text: string; ok: boolean }[] }) {
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [lines]);
  if (lines.length === 0) return null;
  return (
    <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-surface-dim)] p-3 max-h-44 overflow-y-auto flex flex-col gap-0">
      {lines.map(l => (
        <div key={l.id} className={`flex items-start gap-2 py-[1px] font-mono text-[0.6875rem] ${l.ok ? 'text-[var(--color-good)]' : 'text-[var(--color-bad)]'}`}>
          <span className="shrink-0 mt-[2px]">{l.ok ? '✓' : '✗'}</span>
          <span className="break-all">{l.text}</span>
        </div>
      ))}
      <div ref={endRef} />
    </div>
  );
}

/* ── types ─────────────────────────────────────────────────── */
interface Props {
  sessions: BotSession[];
  role?: UserRole;
  permissions?: KeyPermissions;
}

/* ── main component ─────────────────────────────────────────── */
export function MessageSpammer({ sessions, role = 'owner', permissions }: Props) {
  // target
  const [targetType, setTargetType] = useState<'channel' | 'user' | 'voice'>('channel');
  const [targetId, setTargetId]     = useState('');
  // voice channel override: send to a specific voice channel ID instead of bot's current one
  const [voiceChannelId, setVoiceChannelId] = useState('');
  // message
  const [message, setMessage]       = useState('');
  // config
  const [totalMsgs, setTotalMsgs]   = useState('20');   // total messages to send
  const [delayMs, setDelayMs]       = useState('0');     // delay between batches in ms
  const [mode, setMode]             = useState<'once' | 'auto'>('once');
  // bot selection
  const [botScope, setBotScope]     = useState<'all' | 'specific'>('all');
  const [selectedBots, setSelectedBots] = useState<string[]>([]);
  // runtime
  const [running, setRunning]       = useState(false);
  const [stopped, setStopped]       = useState(false);
  const [sent, setSent]             = useState(0);
  const [total, setTotal]           = useState(0);
  const [logs, setLogs]             = useState<{ id: number; text: string; ok: boolean }[]>([]);

  const cancelRef  = useRef(false);
  const logId      = useRef(0);
  const dmCache    = useRef<Map<string, string>>(new Map());

  const canUse = role === 'owner' || permissions?.canUseSpammer === true;

  // derived
  const online = sessions.filter(s => s.status === 'online');
  const bots   = botScope === 'all' ? online : online.filter(s => selectedBots.includes(s.id));

  const targetOk      = targetType === 'voice' || isSnowflake(targetId);
  const voiceIdOk     = !voiceChannelId || isSnowflake(voiceChannelId);
  const msgOk         = message.trim().length > 0 && message.trim().length <= 2000;
  const botsOk        = bots.length > 0;
  const totalNum      = Math.max(1, parseInt(totalMsgs, 10) || 1);
  const delayNum      = Math.max(0, parseInt(delayMs, 10) || 0);
  const canSend       = !running && targetOk && voiceIdOk && msgOk && botsOk && canUse;

  const addLog = useCallback((text: string, ok: boolean) => {
    setLogs(prev => [...prev.slice(-149), { id: logId.current++, text, ok }]);
  }, []);

  // ── server helpers ──────────────────────────────────────────
  async function apiSend(botId: string, channelId: string, content: string): Promise<void> {
    const r = await fetch('/api/spammer/send', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ botId, channelId, content }),
    });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw new Error((e as any)?.error ?? `HTTP ${r.status}`); }
  }

  async function getDM(botId: string, userId: string): Promise<string> {
    const key = `${botId}:${userId}`;
    if (dmCache.current.has(key)) return dmCache.current.get(key)!;
    const r = await fetch('/api/spammer/dm-channel', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ botId, userId }),
    });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw new Error((e as any)?.error ?? `HTTP ${r.status}`); }
    const ch = ((await r.json()) as { channelId: string }).channelId;
    dmCache.current.set(key, ch);
    return ch;
  }

  // ── resolve channel for a bot ───────────────────────────────
  async function resolveChannel(bot: BotSession): Promise<string | null> {
    if (targetType === 'channel') return targetId.trim();
    if (targetType === 'user')    return getDM(bot.id, targetId.trim());
    // Voice target: use the manual override ID if provided, else bot's current voice channel
    if (voiceChannelId.trim() && isSnowflake(voiceChannelId.trim())) {
      return voiceChannelId.trim();
    }
    return bot.channelId ?? bot.voiceSlots?.[0]?.channelId ?? null;
  }

  // ── send one message from one bot ──────────────────────────
  async function sendOne(bot: BotSession, sentRef: { v: number }, totalTarget: number): Promise<boolean> {
    if (cancelRef.current) return false;
    let channelId: string | null;
    try { channelId = await resolveChannel(bot); }
    catch (err) { addLog(`${bot.username}: ${(err as Error).message}`, false); return false; }
    if (!channelId) { addLog(`${bot.username}: not in voice`, false); return false; }
    const content = spinMessage(message.trim());
    try {
      await apiSend(bot.id, channelId, content);
      sentRef.v++;
      setSent(sentRef.v);
      const label = totalTarget > 0 ? ` (${sentRef.v}/${totalTarget})` : ` (${sentRef.v})`;
      addLog(`${bot.username} ✓ ${label}`, true);
      return true;
    } catch (err) {
      addLog(`${bot.username}: ${(err as Error).message}`, false);
      return false;
    }
  }

  // ── main handler ────────────────────────────────────────────
  const handleSend = useCallback(async () => {
    if (!canSend) return;
    cancelRef.current = false;
    dmCache.current.clear();
    setStopped(false);
    setRunning(true);
    setSent(0);
    setLogs([]);

    const activeBots  = [...bots];
    const isAuto      = mode === 'auto';
    const sentRef     = { v: 0 };
    const delay       = delayNum;

    if (isAuto) {
      // ── AUTO MODE: every cycle, all bots fire simultaneously ──────
      setTotal(0);
      while (!cancelRef.current) {
        const promises = activeBots.map(bot => sendOne(bot, sentRef, 0));
        await Promise.all(promises);
        if (cancelRef.current) break;
        // Use user-configured delay (min 200ms to avoid hammering)
        await sleep(Math.max(200, delay) + Math.random() * 100);
      }
    } else {
      // ── ONCE MODE: distribute totalNum messages across bots ──
      // Build round-robin queue
      setTotal(totalNum);
      const queue: BotSession[] = [];
      for (let i = 0; i < totalNum; i++) {
        queue.push(activeBots[i % activeBots.length]);
      }

      if (delay > 0) {
        // ── STAGGERED: send one by one with delay between each ──
        // Group by bot for smarter staggering: each bot gets its turn
        for (let i = 0; i < queue.length; i++) {
          if (cancelRef.current) break;
          await sendOne(queue[i], sentRef, totalNum);
          if (i < queue.length - 1 && !cancelRef.current) {
            await sleep(delay);
          }
        }
      } else {
        // ── BURST: fire ALL in parallel at once ──
        const promises = queue.map(bot => sendOne(bot, sentRef, totalNum));
        await Promise.all(promises);
      }
    }

    setRunning(false);
    if (cancelRef.current) setStopped(true);
  }, [canSend, bots, mode, totalNum, delayNum, message, targetType, targetId, voiceChannelId, addLog]);

  const handleKill = () => { cancelRef.current = true; };

  const toggleBot = (id: string) =>
    setSelectedBots(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  // ── summary line ────────────────────────────────────────────
  const summaryLine = (() => {
    if (!botsOk || !msgOk || !targetOk) return null;
    if (mode === 'auto') {
      const cycleMs = Math.max(200, delayNum);
      const msgsPerMin = Math.round((bots.length / cycleMs) * 60_000);
      return `All ${bots.length} bot${bots.length > 1 ? 's' : ''} fire simultaneously · loops · ~${msgsPerMin} msg/min`;
    }
    const perBot = Math.ceil(totalNum / bots.length);
    if (delayNum > 0) {
      const totalTime = ((totalNum - 1) * delayNum / 1000).toFixed(1);
      return `${totalNum} messages · ${bots.length} bot${bots.length > 1 ? 's' : ''} · ${delayNum}ms delay · ~${totalTime}s total`;
    }
    return `${totalNum} messages → ${bots.length} bot${bots.length > 1 ? 's' : ''} · ~${perBot} per bot · burst (all at once)`;
  })();

  // Speed indicator for delay
  const speedLabel = (() => {
    if (mode === 'auto') {
      const cycleMs = Math.max(200, delayNum);
      return `~${Math.round(60_000 / cycleMs * bots.length)} msg/min`;
    }
    if (delayNum === 0) return 'Burst mode';
    return `${(1000 / delayNum).toFixed(1)} msg/sec`;
  })();

  /* ── render ─────────────────────────────────────────────────── */
  return (
    <section className="animate-rise panel flex flex-col gap-5 p-5 sm:p-6">

      {/* ── Header ── */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex size-7 items-center justify-center rounded-lg bg-[var(--color-accent-2)]/15 text-[var(--color-accent-2)]">
            <IconMessage size={15} />
          </span>
          <h2 className="text-sm font-bold tracking-tight">Message Spammer</h2>
        </div>
        <Badge sent={sent} total={total} active={running} stopped={stopped} />
      </div>

      {/* ── Target type ── */}
      <div className="flex flex-col gap-2">
        <span className="label flex items-center gap-1.5"><IconTarget size={12} />Target</span>
        <div className="flex gap-2 flex-wrap">
          {(['channel', 'user', 'voice'] as const).map(t => (
            <button key={t} type="button"
              onClick={() => { setTargetType(t); setTargetId(''); setVoiceChannelId(''); }}
              className="btn text-xs px-3 py-1.5"
              style={targetType === t ? {
                color: 'var(--color-accent-2)',
                borderColor: 'color-mix(in oklab,var(--color-accent-2) 45%,transparent)',
                background: 'color-mix(in oklab,var(--color-accent-2) 11%,transparent)',
              } : undefined}
            >
              {t === 'channel' ? '# Channel' : t === 'user' ? '@ User DM' : <><IconSpeaker size={12} /> Voice chat</>}
            </button>
          ))}
        </div>
      </div>

      {/* ── Target ID (channel / user) ── */}
      {targetType !== 'voice' && (
        <div className="flex flex-col gap-1.5">
          <label className="label" htmlFor="sp-tid">
            {targetType === 'channel' ? 'Channel ID' : 'User ID'}
          </label>
          <input id="sp-tid" className="field" type="text" inputMode="numeric"
            placeholder="000000000000000000" value={targetId}
            onChange={e => setTargetId(e.target.value.trim())}
            style={targetId && !targetOk ? { borderColor: 'color-mix(in oklab,var(--color-bad) 55%,transparent)' } : undefined}
          />
          {targetId && !targetOk && <span className="text-[0.6875rem] text-[var(--color-bad)]">Discord ID = 17-20 digits</span>}
        </div>
      )}

      {/* ── Voice Channel ID override (voice target) ── */}
      {targetType === 'voice' && (
        <div className="flex flex-col gap-1.5">
          <label className="label" htmlFor="sp-vcid">
            Voice Channel ID <span className="text-[var(--color-ink-faint)] font-normal">(optional)</span>
          </label>
          <input id="sp-vcid" className="field" type="text" inputMode="numeric"
            placeholder="Auto (bot's current channel)"
            value={voiceChannelId}
            onChange={e => setVoiceChannelId(e.target.value.trim())}
            style={voiceChannelId && !voiceIdOk ? { borderColor: 'color-mix(in oklab,var(--color-bad) 55%,transparent)' } : undefined}
          />
          {voiceChannelId && !voiceIdOk
            ? <span className="text-[0.6875rem] text-[var(--color-bad)]">Discord ID = 17-20 digits</span>
            : <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                Leave empty to use each bot's current voice channel
              </span>
          }
        </div>
      )}

      {/* ── Message ── */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <label className="label" htmlFor="sp-msg">Message</label>
          <span className={`text-[0.6875rem] ${message.length > 2000 ? 'text-[var(--color-bad)]' : 'text-[var(--color-ink-faint)]'}`}>
            {message.length}/2000
          </span>
        </div>
        <textarea id="sp-msg" className="field min-h-[76px] resize-y"
          placeholder={"Ton message ici…\nTip: {mot1|mot2} pour varier automatiquement"}
          value={message} onChange={e => setMessage(e.target.value)}
          style={message && !msgOk ? { borderColor: 'color-mix(in oklab,var(--color-bad) 55%,transparent)' } : undefined}
        />
        <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
          Variation invisible auto-appliquée · <code className="text-[var(--color-ink)]">{'{opt1|opt2}'}</code> pour spinner
        </span>
      </div>

      {/* ── Config row ── */}
      <div className="grid grid-cols-2 gap-4 border-t border-[var(--color-edge)] pt-4">

        {/* Total messages (once mode) */}
        <div className="flex flex-col gap-1.5">
          <label className="label" htmlFor="sp-total">Nombre de messages</label>
          <input id="sp-total" className="field" type="number" min={1} max={500}
            value={totalMsgs} onChange={e => setTotalMsgs(e.target.value)}
            disabled={mode === 'auto'}
            style={mode === 'auto' ? { opacity: 0.4 } : undefined}
          />
          <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
            {mode === 'auto' ? 'Infini en auto mode' : `Répartis entre ${bots.length || '?'} bots`}
          </span>
        </div>

        {/* Mode */}
        <div className="flex flex-col gap-1.5">
          <span className="label">Mode</span>
          <div className="flex gap-2">
            <button type="button" onClick={() => setMode('once')}
              className="btn text-xs px-2 py-2 flex-1"
              style={mode === 'once' ? {
                color: 'var(--color-good)',
                borderColor: 'color-mix(in oklab,var(--color-good) 45%,transparent)',
                background: 'color-mix(in oklab,var(--color-good) 10%,transparent)',
              } : undefined}
            >
              <IconSend size={12} />Une fois
            </button>
            <button type="button" onClick={() => setMode('auto')}
              className="btn text-xs px-2 py-2 flex-1"
              style={mode === 'auto' ? {
                color: 'var(--color-warn)',
                borderColor: 'color-mix(in oklab,var(--color-warn) 45%,transparent)',
                background: 'color-mix(in oklab,var(--color-warn) 10%,transparent)',
              } : undefined}
            >
              <IconLoop size={12} />Auto
            </button>
          </div>
          <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
            {mode === 'auto' ? 'Boucle jusqu\'au stop' : 'Envoie une fois et stop'}
          </span>
        </div>
      </div>

      {/* ── Delay / Speed control ── */}
      <div className="flex flex-col gap-1.5 border-t border-[var(--color-edge)] pt-4">
        <div className="flex items-center justify-between">
          <label className="label" htmlFor="sp-delay">Délai entre messages</label>
          <span className="text-[0.6875rem] font-mono"
            style={{ color: delayNum === 0 ? 'var(--color-warn)' : 'var(--color-accent)' }}>
            {speedLabel}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <input
            id="sp-delay"
            type="range"
            min={0}
            max={5000}
            step={50}
            value={delayMs}
            onChange={e => setDelayMs(e.target.value)}
            className="flex-1 h-1.5 rounded-full appearance-none cursor-pointer"
            style={{
              accentColor: delayNum === 0 ? 'var(--color-warn)' : 'var(--color-accent)',
            }}
          />
          <div className="flex items-center gap-1">
            <input
              type="number"
              min={0}
              max={5000}
              step={50}
              value={delayMs}
              onChange={e => setDelayMs(e.target.value)}
              className="field w-20 text-center font-mono text-xs py-1"
            />
            <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">ms</span>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {[
            { label: 'Burst', val: '0' },
            { label: '100ms', val: '100' },
            { label: '500ms', val: '500' },
            { label: '1s', val: '1000' },
            { label: '2s', val: '2000' },
          ].map(({ label, val }) => (
            <button key={val} type="button"
              onClick={() => setDelayMs(val)}
              className="btn text-xs px-2.5 py-1"
              style={delayMs === val ? {
                color: val === '0' ? 'var(--color-warn)' : 'var(--color-accent)',
                borderColor: `color-mix(in oklab,${val === '0' ? 'var(--color-warn)' : 'var(--color-accent)'} 45%,transparent)`,
                background: `color-mix(in oklab,${val === '0' ? 'var(--color-warn)' : 'var(--color-accent)'} 11%,transparent)`,
              } : undefined}
            >
              {label}
            </button>
          ))}
        </div>
        <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
          {delayNum === 0
            ? <><IconBolt size={12} className="inline" /> Burst — tous les messages en parallèle simultanément</>
            : `${delayNum}ms entre chaque message · staggered`}
        </span>
      </div>

      {/* ── Bot selection ── */}
      <div className="flex flex-col gap-2 border-t border-[var(--color-edge)] pt-4">
        <div className="flex items-center justify-between">
          <span className="label">Bots</span>
          <div className="flex gap-1.5">
            <button type="button" onClick={() => setBotScope('all')}
              className="btn text-xs px-2.5 py-1"
              style={botScope === 'all' ? {
                color: 'var(--color-accent)',
                borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
              } : undefined}
            >
              Tous ({online.length})
            </button>
            <button type="button" onClick={() => setBotScope('specific')}
              className="btn text-xs px-2.5 py-1"
              style={botScope === 'specific' ? {
                color: 'var(--color-accent)',
                borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
              } : undefined}
            >
              Sélection
            </button>
            {botScope === 'specific' && online.length > 0 && (
              <button type="button"
                onClick={() => setSelectedBots(
                  selectedBots.length === online.length ? [] : online.map(s => s.id)
                )}
                className="btn text-xs px-2.5 py-1"
                style={{ color: 'var(--color-ink-dim)' }}
              >
                {selectedBots.length === online.length ? 'None' : 'All'}
              </button>
            )}
          </div>
        </div>

        {botScope === 'specific' && (
          <div className="flex flex-wrap gap-1.5">
            {online.length === 0
              ? <span className="text-xs text-[var(--color-ink-faint)]">Aucun bot en ligne</span>
              : online.map(s => {
                  const sel = selectedBots.includes(s.id);
                  return (
                    <button key={s.id} type="button" onClick={() => toggleBot(s.id)}
                      className="btn text-xs px-2.5 py-1.5 flex items-center gap-1.5"
                      style={sel ? {
                        color: 'var(--color-accent)',
                        borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                        background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
                      } : undefined}
                    >
                      {s.avatarUrl && <img src={s.avatarUrl} alt="" className="size-4 rounded-full" />}
                      {s.username}
                      {sel && <span className="text-[0.6rem] opacity-60">✓</span>}
                    </button>
                  );
                })
            }
          </div>
        )}

        {/* Selected bots count */}
        {botScope === 'specific' && selectedBots.length > 0 && (
          <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
            {selectedBots.length} bot{selectedBots.length > 1 ? 's' : ''} sélectionné{selectedBots.length > 1 ? 's' : ''}
          </span>
        )}
      </div>

      {/* ── Summary + Action ── */}
      <div className="flex flex-col gap-3 border-t border-[var(--color-edge)] pt-4">

        {/* Preview line */}
        {summaryLine && (
          <div className="rounded-lg border border-[var(--color-accent-2)]/20 bg-[var(--color-accent-2)]/5 px-3 py-2 text-[0.75rem] text-[var(--color-ink-dim)]">
            <span className="font-semibold text-[var(--color-accent-2)]">Plan · </span>
            {summaryLine}
          </div>
        )}

        <div className="flex items-center gap-3">
          {running ? (
            <button type="button" onClick={handleKill} className="btn btn-danger">
              <IconStop size={15} />Stop
            </button>
          ) : (
            <button type="button" onClick={() => void handleSend()} disabled={!canSend}
              className="btn btn-primary disabled:opacity-50"
            >
              <IconSend size={15} />
              {mode === 'auto' ? 'Lancer auto-send' : `Envoyer ${botsOk && msgOk ? totalNum : ''} messages`}
            </button>
          )}

          {logs.length > 0 && !running && (
            <button type="button" onClick={() => { setLogs([]); setStopped(false); setSent(0); }}
              className="btn text-xs"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* ── Log ── */}
      <Log lines={logs} />

    </section>
  );
}
