import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { AuthSessionInfo, Snapshot } from '@shared/types';
import type { ConnectionState } from '../lib/useLiveData';
import {
  BrandMark,
  IconCrown,
  IconExit,
  IconGlobe,
  IconKey,
  IconPower,
  IconShield,
  IconShieldOff,
  IconSpeaker,
  IconUsers,
} from './Icons';

interface StatProps {
  icon: ReactNode;
  label: string;
  value: string | number;
  tone?: string;
}

function Stat({ icon, label, value, tone = 'var(--color-accent)' }: StatProps) {
  const [tickKey, setTickKey] = useState(0);
  const previous = useRef(value);

  useEffect(() => {
    if (previous.current !== value) {
      previous.current = value;
      setTickKey((n) => n + 1);
    }
  }, [value]);

  return (
    <div className="flex items-center gap-3 rounded-xl border border-[var(--color-edge)] bg-[color-mix(in_oklab,var(--color-void)_55%,transparent)] px-3.5 py-2.5">
      <span
        className="flex size-8 shrink-0 items-center justify-center rounded-lg"
        style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}
      >
        {icon}
      </span>
      <div className="min-w-0 leading-tight">
        <div className="font-mono text-base font-bold tabular-nums">
          <span key={tickKey} className={tickKey > 0 ? 'value-tick' : undefined}>
            {value}
          </span>
        </div>
        <div className="text-[0.625rem] uppercase tracking-wider text-[var(--color-ink-faint)]">
          {label}
        </div>
      </div>
    </div>
  );
}

const CONNECTION_LABEL: Record<ConnectionState, { text: string; tone: string }> = {
  live: { text: 'Live', tone: 'var(--color-good)' },
  connecting: { text: 'Connecting', tone: 'var(--color-warn)' },
  reconnecting: { text: 'Reconnecting', tone: 'var(--color-warn)' },
  offline: { text: 'Offline', tone: 'var(--color-bad)' },
};

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

interface HeaderProps {
  snapshot: Snapshot | null;
  connection: ConnectionState;
  role?: 'owner' | 'user';
  keyInfo?: AuthSessionInfo['keyInfo'];
  onToggleAntiLeave: () => void;
  onOpenOwnerPanel?: () => void;
  onOpenUserPanel?: () => void;
  onLogout: () => void;
}

function maskKey(key: string): string {
  const parts = key.split('-');
  if (parts.length < 4) return key.slice(0, 4) + '****';
  const visible = parts.slice(0, 2).join('-');
  const masked = parts.slice(2, -1).map(() => '****').join('-');
  const last = parts[parts.length - 1];
  return `${visible}-${masked}-${last}`;
}

export function Header({
  snapshot,
  connection,
  role = 'owner',
  keyInfo,
  onToggleAntiLeave,
  onOpenOwnerPanel,
  onOpenUserPanel,
  onLogout,
}: HeaderProps) {
  const stats = snapshot?.stats;
  const antiLeave = snapshot?.config.globalAntiLeave ?? false;
  const status = CONNECTION_LABEL[connection];

  const now = Date.now();
  const isKeyExpiring = keyInfo?.expiresAt && keyInfo.expiresAt - now < 3600 * 1000;
  const remainingHours = keyInfo?.expiresAt
    ? Math.max(0, Math.round((keyInfo.expiresAt - now) / (3600 * 1000)))
    : null;

  return (
    <header className="animate-rise flex flex-col gap-0">

      {/* ── TOP BAR — Kaito-style sticky nav ── */}
      <div
        className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--color-edge)] px-4 py-3 sm:px-5"
        style={{
          background: 'linear-gradient(160deg, color-mix(in oklab, var(--color-panel-2) 92%, transparent), color-mix(in oklab, var(--color-panel) 96%, transparent))',
          backdropFilter: 'blur(12px)',
          position: 'relative',
        }}
      >
        {/* Hairline top edge highlight */}
        <span
          aria-hidden="true"
          style={{
            position: 'absolute',
            inset: '0 0 auto 0',
            height: '1px',
            borderRadius: '1rem 1rem 0 0',
            background: 'linear-gradient(90deg, transparent, color-mix(in oklab, var(--color-accent) 45%, transparent), transparent)',
            opacity: 0.7,
          }}
        />

        {/* Left: brand */}
        <div className="flex items-center gap-3">
          <BrandMark size={36} />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold leading-tight tracking-tight sm:text-lg">
                Ghost <span className="text-[var(--color-accent)]">Voice Control</span>
              </h1>
              {role === 'owner' ? (
                <span className="flex items-center gap-1 rounded-full bg-amber-500/15 px-2.5 py-0.5 text-[0.6875rem] font-bold text-amber-400">
                  <IconCrown size={11} />
                  Owner
                </span>
              ) : (
                <span className="flex items-center gap-1 rounded-full bg-cyan-500/15 px-2.5 py-0.5 text-[0.6875rem] font-bold text-cyan-400">
                  <IconKey size={11} />
                  User Key
                </span>
              )}
            </div>
            <p className="mt-0.5 text-[0.6875rem] text-[var(--color-ink-faint)]">
              {role === 'owner'
                ? 'Full administrative control of discord bot fleet & access keys'
                : keyInfo?.note
                  ? `Licensed to: ${keyInfo.note}`
                  : 'Authorized bot control session'}
            </p>
          </div>
        </div>

        {/* Right: controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Key info badge (user only) */}
          {role === 'user' && keyInfo && (
            <div className="flex items-center gap-2 rounded-xl border border-[var(--color-line-soft)] bg-[var(--color-surface-dim)] px-3 py-1.5 text-xs">
              <span className="font-mono text-[0.6875rem] text-[var(--color-ink-dim)]">
                {maskKey(keyInfo.key)}
              </span>
              {remainingHours !== null ? (
                <span
                  className={`rounded-md px-1.5 py-0.5 text-[0.625rem] font-bold ${
                    isKeyExpiring
                      ? 'animate-pulse bg-red-500/20 text-red-400'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {remainingHours > 0 ? `${remainingHours}h remaining` : 'Expiring soon'}
                </span>
              ) : (
                <span className="rounded-md bg-blue-500/20 px-1.5 py-0.5 text-[0.625rem] font-bold text-blue-400">
                  Permanent
                </span>
              )}
            </div>
          )}

          {/* Connection status */}
          <span
            className="chip"
            style={{
              color: status.tone,
              borderColor: `color-mix(in oklab, ${status.tone} 32%, transparent)`,
              background: `color-mix(in oklab, ${status.tone} 10%, transparent)`,
            }}
          >
            <span className="relative flex size-1.5" style={{ color: status.tone }}>
              <span className="absolute inset-0 rounded-full bg-current" />
              {connection === 'live' && <span className="pulse-ring absolute inset-0" />}
            </span>
            {status.text}
          </span>

          {/* Owner Panel */}
          {role === 'owner' && onOpenOwnerPanel && (
            <button
              onClick={onOpenOwnerPanel}
              className="btn border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
              title="Open Owner Panel"
            >
              <IconCrown size={14} />
              <span className="font-bold">Owner Panel</span>
            </button>
          )}

          {/* My Account (user only) */}
          {role === 'user' && onOpenUserPanel && (
            <button
              onClick={onOpenUserPanel}
              className="btn border-cyan-500/40 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20"
              title="My Account"
            >
              <IconKey size={14} />
              <span className="font-bold">My Account</span>
            </button>
          )}

          {/* Anti-leave toggle */}
          {(role === 'owner' || keyInfo?.permissions.canUseAntiLeave) && (
            <button
              onClick={onToggleAntiLeave}
              className="btn"
              style={
                antiLeave
                  ? {
                      color: 'var(--color-good)',
                      borderColor: 'color-mix(in oklab, var(--color-good) 38%, transparent)',
                      background: 'color-mix(in oklab, var(--color-good) 10%, transparent)',
                    }
                  : undefined
              }
              title="When on, any account pulled out of voice is sent back automatically"
            >
              {antiLeave ? <IconShield size={14} /> : <IconShieldOff size={14} />}
              Anti-leave {antiLeave ? 'on' : 'off'}
            </button>
          )}

          <button onClick={onLogout} className="btn" title="Lock the panel">
            <IconExit size={14} />
            <span className="hidden sm:inline">Exit</span>
          </button>
        </div>
      </div>

      {/* ── STATS ROW — 4 cards below the bar ── */}
      <div className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <Stat
          icon={<IconUsers size={15} />}
          label={keyInfo?.permissions.botScope === 'specific' ? 'Assigned Bots' : 'Accounts'}
          value={stats?.total ?? 0}
        />
        <Stat
          icon={<IconPower size={15} />}
          label="Online"
          value={stats?.online ?? 0}
          tone="var(--color-good)"
        />
        <Stat
          icon={<IconSpeaker size={15} />}
          label="In voice"
          value={stats?.inVoice ?? 0}
          tone="var(--color-accent-2)"
        />
        <Stat
          icon={<IconGlobe size={15} />}
          label="Uptime"
          value={formatUptime(stats?.uptimeSeconds ?? 0)}
          tone="var(--color-warn)"
        />
      </div>
    </header>
  );
}
