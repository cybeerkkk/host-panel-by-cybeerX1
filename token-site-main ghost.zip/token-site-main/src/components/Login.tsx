import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { api, ApiError } from '../lib/api';
import { unlockAccessSound } from '../lib/accessSound';
import { BrandMark, IconHome, IconLock, IconPulse, IconRadar, IconRefresh, IconSearch } from './Icons';
import { AccessGranted } from './AccessGranted';
import { PublicUserInfo } from './PublicUserInfo';

const OWNER_UNLOCK_CLICKS = 5;
const OWNER_UNLOCK_WINDOW_MS = 3000;

const GHOST_PROFILE_URL = 'https://discord.com/users/1245143759906406442';

type HealthResponse = { ok?: boolean; sessions?: number; online?: number; uptime?: number };

export function Login({ onSuccess }: { onSuccess: () => void }) {
  const [view, setView] = useState<'home' | 'info'>('home');
  const [tab, setTab] = useState<'key' | 'owner'>('key');
  const [keyInput, setKeyInput] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [ownerUnlocked, setOwnerUnlocked] = useState(false);
  const [showAccessAnim, setShowAccessAnim] = useState(false);
  const [health, setHealth] = useState<{ sessions: number; online: number } | null>(null);
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);

  const clickTimestamps = useRef<number[]>([]);

  // Mouse-parallax for the right-column orbit visual
  const sceneRef = useRef<HTMLDivElement>(null);
  const sceneInnerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/health', { credentials: 'include' })
      .then((res) => res.json() as Promise<HealthResponse>)
      .then((data) => {
        if (cancelled) return;
        setApiOnline(true);
        if (typeof data.sessions === 'number') {
          setHealth({ sessions: data.sessions, online: typeof data.online === 'number' ? data.online : 0 });
        }
      })
      .catch(() => { if (!cancelled) setApiOnline(false); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const scene = sceneRef.current;
    const inner = sceneInnerRef.current;
    if (!scene || !inner || !window.matchMedia('(pointer: fine)').matches) return;
    let tx = 0, ty = 0, cx = 0, cy = 0, frame = 0;
    const onMove = (e: MouseEvent) => {
      const r = scene.getBoundingClientRect();
      tx = ((e.clientX - r.left) / r.width - 0.5) * 14;
      ty = ((e.clientY - r.top) / r.height - 0.5) * -14;
    };
    const onLeave = () => { tx = 0; ty = 0; };
    const tick = () => {
      cx += (tx - cx) * 0.08;
      cy += (ty - cy) * 0.08;
      inner.style.transform = `rotateY(${cx}deg) rotateX(${cy}deg)`;
      frame = requestAnimationFrame(tick);
    };
    scene.addEventListener('mousemove', onMove);
    scene.addEventListener('mouseleave', onLeave);
    frame = requestAnimationFrame(tick);
    return () => {
      scene.removeEventListener('mousemove', onMove);
      scene.removeEventListener('mouseleave', onLeave);
      cancelAnimationFrame(frame);
    };
  }, []);

  const handleLogoClick = () => {
    const now = Date.now();
    const ts = clickTimestamps.current;
    ts.push(now);
    const recent = ts.filter((t) => now - t <= OWNER_UNLOCK_WINDOW_MS);
    clickTimestamps.current = recent;
    if (recent.length >= OWNER_UNLOCK_CLICKS) {
      clickTimestamps.current = [];
      setOwnerUnlocked(true);
      setTab('owner');
    }
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');
    unlockAccessSound();
    if (tab === 'key') {
      if (!keyInput.trim() || busy) return;
      setBusy(true);
      try {
        await api.login({ key: keyInput.trim() });
        setShowAccessAnim(true);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Could not validate access key');
      } finally { setBusy(false); }
    } else {
      if (!password || busy) return;
      setBusy(true);
      try {
        await api.login({ password });
        setShowAccessAnim(true);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Incorrect password');
        setPassword('');
      } finally { setBusy(false); }
    }
  };

  if (showAccessAnim) return <AccessGranted onDone={onSuccess} />;

  const apiStatusColor =
    apiOnline === true ? 'var(--color-good)' :
    apiOnline === false ? 'var(--color-bad)' :
    'var(--color-ink-faint)';

  return (
    <main className="flex min-h-dvh flex-col">

      {/* ── TOP NAV ── */}
      <nav className="sticky top-0 z-20 flex items-center gap-3 border-b border-[var(--color-line-soft)]/60 bg-[var(--color-void)]/80 px-4 py-2.5 backdrop-blur-md sm:gap-6 sm:px-8 sm:py-3">
        {/* Logo: click 5x to unlock owner tab */}
        <button
          type="button"
          onClick={handleLogoClick}
          aria-label="Logo"
          className="flex shrink-0 cursor-default select-none items-center gap-2.5 focus:outline-none"
          tabIndex={-1}
        >
          <BrandMark size={26} />
          <span className="hidden text-sm font-extrabold tracking-tight md:inline">
            Ghost <span className="text-[var(--color-accent)]">Voice Control</span>
          </span>
        </button>

        <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto" role="tablist">
          {([
            ['home', 'Home', IconHome],
            ['info', 'User Info', IconRadar],
          ] as const).map(([id, label, TabIcon]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={view === id}
              onClick={() => setView(id)}
              className="topnav-tab"
            >
              <TabIcon size={16} />
              <span>{label}</span>
            </button>
          ))}
        </div>

        <div className="flex shrink-0 items-center gap-3">
          <a
            href={GHOST_PROFILE_URL}
            target="_blank"
            rel="noreferrer"
            className="hidden text-xs font-semibold text-[var(--color-ink-dim)] transition-colors hover:text-[var(--color-accent)] md:inline"
          >
            𝐆𝐡𝐨𝐬𝐭
          </a>
          <span
            className="chip"
            title={apiOnline === null ? 'Checking…' : apiOnline ? 'API online' : 'API offline'}
            style={{
              color: apiStatusColor,
              borderColor: `color-mix(in oklab, ${apiStatusColor} 35%, transparent)`,
              background: `color-mix(in oklab, ${apiStatusColor} 10%, transparent)`,
            }}
          >
            <span
              className="size-1.5 rounded-full"
              style={{ background: apiStatusColor, boxShadow: apiOnline === true ? `0 0 6px ${apiStatusColor}` : undefined }}
            />
            <span className="hidden sm:inline">
              {apiOnline === null ? 'Checking…' : apiOnline ? 'API online' : 'API offline'}
            </span>
          </span>
        </div>
      </nav>

      {view === 'info' ? (
        <PublicUserInfo onGetAccess={() => setView('home')} />
      ) : (
      <>
      {/* ── HERO: centered, search-bar style (Kaito layout) + right column visual ── */}
      <div className="mx-auto grid w-full max-w-6xl flex-1 grid-cols-1 items-center gap-10 px-5 py-10 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:py-14">

        {/* Left column — label + heading + search form + live stats */}
        <div className="order-2 lg:order-1">

          {/* Badge label */}
          <div className="mb-5 inline-flex items-center gap-2 text-[0.6875rem] font-bold uppercase tracking-[0.14em] text-[var(--color-accent)]">
            <span className="size-1.5 rounded-full bg-[var(--color-accent)]" style={{ boxShadow: '0 0 6px var(--color-accent)' }} />
            Discord Ops Center
          </div>

          {/* Main heading — Kaito big-title style */}
          <h1 className="text-3xl font-extrabold leading-[1.08] tracking-tight sm:text-4xl lg:text-5xl">
            Ghost Voice Control
            <br />
            <span className="text-[var(--color-accent)]">
              Access Portal
            </span>
          </h1>

          <p className="mt-4 max-w-md text-sm text-[var(--color-ink-dim)]">
            Voice control and live session management behind an access key.
            Looking someone up? Use User Info, it is free.
          </p>

          {/* Owner tab switcher — only visible after 5-click unlock */}
          {ownerUnlocked && (
            <div className="mt-5 flex w-full max-w-sm rounded-xl bg-[var(--color-surface-dim)] p-1">
              <button
                type="button"
                onClick={() => { setTab('key'); setError(''); }}
                className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-colors ${
                  tab === 'key'
                    ? 'bg-[var(--color-surface)] text-[var(--color-ink)] shadow-sm'
                    : 'text-[var(--color-ink-dim)] hover:text-[var(--color-ink)]'
                }`}
              >
                Access Key
              </button>
              <button
                type="button"
                onClick={() => { setTab('owner'); setError(''); }}
                className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-colors ${
                  tab === 'owner'
                    ? 'bg-[var(--color-surface)] text-[var(--color-ink)] shadow-sm'
                    : 'text-[var(--color-ink-dim)] hover:text-[var(--color-ink)]'
                }`}
              >
                Owner
              </button>
            </div>
          )}

          {/* Search-bar style auth form (Kaito User Info layout) */}
          <form onSubmit={submit} className="mt-6 w-full max-w-sm">
            <div
              className="flex items-center overflow-hidden rounded-2xl border border-[var(--color-edge-bright)] bg-[color-mix(in_oklab,var(--color-void)_75%,transparent)] transition-all focus-within:border-[color-mix(in_oklab,var(--color-accent)_55%,transparent)] focus-within:shadow-[0_0_0_3px_color-mix(in_oklab,var(--color-accent)_12%,transparent)]"
            >
              {/* Hash prefix (Kaito #-icon left side) */}
              <span className="select-none pl-4 pr-1 font-mono text-base font-bold text-[var(--color-ink-faint)]">
                #
              </span>

              {tab === 'key' ? (
                <input
                  type="text"
                  autoComplete="off"
                  autoFocus
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  placeholder="Enter your access key"
                  className="flex-1 bg-transparent py-3.5 pr-2 font-mono text-sm text-[var(--color-ink)] placeholder:text-[var(--color-ink-faint)] focus:outline-none"
                />
              ) : (
                <input
                  type="password"
                  autoComplete="current-password"
                  autoFocus
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Owner password"
                  className="flex-1 bg-transparent py-3.5 pr-2 text-sm text-[var(--color-ink)] placeholder:text-[var(--color-ink-faint)] focus:outline-none"
                />
              )}

              {/* Hint text */}
              <span className="hidden select-none pr-3 text-[0.7rem] text-[var(--color-ink-faint)] sm:inline">
                {tab === 'key' ? 'GVC-XXXX' : ''}
              </span>

              {/* Submit button — solid cyan like Kaito Search */}
              <button
                type="submit"
                disabled={busy || (tab === 'key' ? !keyInput.trim() : !password)}
                className="m-1.5 flex shrink-0 items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-bold text-[#04121a] transition-all disabled:opacity-40"
                style={{
                  background: 'var(--color-accent)',
                  boxShadow: '0 2px 14px -4px color-mix(in oklab, var(--color-accent) 55%, transparent)',
                }}
              >
                {busy ? (
                  <IconRefresh size={14} className="animate-spin-slow" />
                ) : tab === 'key' ? (
                  <IconSearch size={14} />
                ) : (
                  <IconLock size={14} />
                )}
                {busy ? 'Checking…' : tab === 'key' ? 'Search' : 'Unlock'}
              </button>
            </div>

            {error && (
              <div className="animate-rise mt-3 rounded-xl bg-[var(--color-bad-soft)] px-3 py-2 text-xs font-medium text-[var(--color-bad)]">
                {error}
              </div>
            )}

            <p className="mt-3 text-[0.6875rem] text-[var(--color-ink-faint)]">
              {tab === 'key'
                ? "Don't have a key? Contact the administrator for access."
                : 'Restricted access — owner only.'}
            </p>
          </form>

          {/* Live stats row */}
          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-base font-bold text-[var(--color-ink)]">
                {health ? health.sessions : '—'}
              </span>
              <span className="text-[var(--color-ink-faint)]">active sessions</span>
            </div>
            <span className="h-3 w-px bg-[var(--color-line-soft)]" />
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-base font-bold text-[var(--color-ink)]">
                {health ? health.online : '—'}
              </span>
              <span className="text-[var(--color-ink-faint)]">online now</span>
            </div>
            <span className="h-3 w-px bg-[var(--color-line-soft)]" />
            <div className="flex items-baseline gap-1.5">
              <span className={`font-mono text-base font-bold ${apiOnline ? 'text-[var(--color-good)]' : 'text-[var(--color-bad)]'}`}>
                {apiOnline === null ? '…' : apiOnline ? 'Live' : 'Down'}
              </span>
              <span className="text-[var(--color-ink-faint)]">network status</span>
            </div>
          </div>
        </div>

        {/* Right column — original orbit visual preserved */}
        <div className="order-1 flex justify-center lg:order-2">
          <div
            ref={sceneRef}
            className="relative flex size-64 items-center justify-center sm:size-80"
            style={{ perspective: '900px' }}
          >
            <div
              ref={sceneInnerRef}
              className="relative flex size-full items-center justify-center transition-transform duration-200 ease-out"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <span className="absolute size-[85%] animate-[spin_16s_linear_infinite] rounded-full border border-[var(--color-edge-bright)]/60" />
              <span className="absolute size-[62%] animate-[spin_11s_linear_infinite] rounded-full border border-[var(--color-edge-bright)]/40 [animation-direction:reverse]" />
              <span className="absolute size-[40%] rounded-full border border-dashed border-[var(--color-edge)]" />

              <div className="panel relative z-10 flex size-28 items-center justify-center rounded-full sm:size-32">
                <BrandMark size={56} />
              </div>

              {/* Floating info card — "Live network pulse" (Kaito style) */}
              <div className="panel absolute -left-2 top-4 flex w-40 flex-col gap-1 p-3 text-left sm:-left-10 sm:w-44">
                <div className="flex items-center gap-1.5 text-[var(--color-accent)]">
                  <IconPulse size={13} />
                  <span className="text-[0.6875rem] font-bold uppercase tracking-wide">
                    Live network pulse
                  </span>
                </div>
                <p className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                  {health
                    ? `${health.online} of ${health.sessions} bots online`
                    : 'Mutual data, clearly surfaced.'}
                </p>
              </div>

              <div className="panel absolute -right-2 bottom-4 flex w-36 flex-col gap-1 p-3 text-left sm:-right-8 sm:w-40">
                <div className="flex items-center gap-1.5 text-[var(--color-accent)]">
                  <IconLock size={13} />
                  <span className="text-[0.6875rem] font-bold uppercase tracking-wide">
                    Encrypted
                  </span>
                </div>
                <p className="text-[0.6875rem] text-[var(--color-ink-faint)]">
                  Key exchange over HTTPS only
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      </>
      )}

      {/* ── FOOTER ── */}
      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--color-line-soft)]/50 px-6 pb-5 pt-4 text-[0.6875rem] text-[var(--color-ink-faint)] sm:px-8">
        <span>Ghost Voice Control</span>
        <span>Discord Mutual Server Intelligence</span>
        <a
          href={GHOST_PROFILE_URL}
          target="_blank"
          rel="noreferrer"
          className="transition-colors hover:text-[var(--color-accent)]"
        >
          𝐆𝐡𝐨𝐬𝐭
        </a>
        <span>© 2026 Ghost Voice Control</span>
      </footer>
    </main>
  );
}
