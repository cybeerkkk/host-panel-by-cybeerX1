import { useEffect, useRef, useState } from 'react';
import type { LogType, SystemLog } from '@shared/types';
import { IconTerminal } from './Icons';

/** Colour per log kind. The old build encoded this with emoji in the message. */
const TONE: Record<LogType, string> = {
  info: 'var(--color-ink-dim)',
  join: 'var(--color-accent)',
  leave: 'var(--color-ink-faint)',
  'anti-leave': 'var(--color-good)',
  'anti-move': 'var(--color-warn)',
  'anti-host': 'var(--color-warn)',
  follow: 'var(--color-accent-2)',
  react: 'var(--color-good)',
  warn: 'var(--color-warn)',
  error: 'var(--color-bad)',
};

const LABEL: Record<LogType, string> = {
  info: 'info',
  join: 'join',
  leave: 'exit',
  'anti-leave': 'guard',
  'anti-move': 'move',
  'anti-host': 'host',
  follow: 'trail',
  react: 'react',
  warn: 'warn',
  error: 'fail',
};

function clock(at: number): string {
  return new Date(at).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function Console({ logs }: { logs: SystemLog[] }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [pinned, setPinned] = useState(true);

  // Auto-scroll, but release it the moment the user scrolls up to read history.
  useEffect(() => {
    if (!pinned) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs, pinned]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    setPinned(el.scrollHeight - el.scrollTop - el.clientHeight < 40);
  };

  return (
    <section className="animate-rise panel flex min-h-0 flex-1 flex-col gap-3 p-5">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[var(--color-ink-dim)]">
          <IconTerminal size={15} className="text-[var(--color-accent)]" />
          Gateway log
        </h2>
        {!pinned && (
          <button
            onClick={() => {
              setPinned(true);
              const el = scrollRef.current;
              if (el) el.scrollTop = el.scrollHeight;
            }}
            className="chip border-[var(--color-edge-bright)] text-[var(--color-ink-dim)] transition-colors hover:text-[var(--color-accent)]"
          >
            Jump to latest
          </button>
        )}
      </div>

      <div
        ref={scrollRef}
        onScroll={onScroll}
        className="min-h-[15rem] flex-1 overflow-y-auto rounded-xl border border-[var(--color-edge)] bg-[color-mix(in_oklab,var(--color-void)_80%,transparent)] p-3 font-mono text-[0.6875rem] leading-relaxed"
      >
        {logs.length === 0 ? (
          <p className="py-8 text-center text-[var(--color-ink-faint)]">Waiting for activity…</p>
        ) : (
          <ul className="flex flex-col gap-1">
            {logs.map((log) => (
              <li key={log.id} className="flex gap-2">
                <span className="shrink-0 text-[var(--color-ink-faint)] tabular-nums">
                  {clock(log.at)}
                </span>
                <span
                  className="w-11 shrink-0 font-semibold uppercase"
                  style={{ color: TONE[log.type] }}
                >
                  {LABEL[log.type]}
                </span>
                <span className="min-w-0 break-words text-[var(--color-ink-dim)]">
                  {log.message}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
