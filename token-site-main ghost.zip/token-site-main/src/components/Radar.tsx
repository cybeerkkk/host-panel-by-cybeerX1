import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import type { AppConfig, UserProfile } from '@shared/types';
import { api, ApiError } from '../lib/api';
import { RankBadge, rankCardStyle, sortGuilds, useGuildRanks } from './GuildRank';
import type {
  MonitorGuildRoleInfo,
  MonitorMemberRoleDetails,
  MonitorMemberSearchResult,
} from '../lib/api';
import {
  IconAlert,
  IconClock,
  IconGlobe,
  IconMic,
  IconMicOff,
  IconRadar,
  IconRefresh,
  IconSearch,
  IconShield,
  IconSpeaker,
  IconUsers,
} from './Icons';

function EmptyState() {
  return (
    <div className="panel flex flex-col items-center gap-4 p-12 text-center">
      <span className="text-[var(--color-edge-bright)]">
        <IconRadar size={52} />
      </span>
      <div>
        <p className="text-sm font-semibold text-[var(--color-ink-dim)]">No user selected</p>
        <p className="mt-1 max-w-xs text-xs text-[var(--color-ink-faint)]">
          Enter a Discord user ID to look up the profile and shared-server activity visible to your connected accounts.
        </p>
      </div>
    </div>
  );
}

function Scanning() {
  return (
    <div className="panel shimmer flex flex-col items-center gap-4 p-12 text-center">
      <span className="animate-radar text-[var(--color-accent)]">
        <IconRadar size={52} />
      </span>
      <p className="text-sm text-[var(--color-ink-dim)]">Scanning connected servers…</p>
    </div>
  );
}

type TierKey = 'owner' | 'administrator' | 'admin' | 'member';
type MemberRole = MonitorMemberRoleDetails['roles'][number];

const TIERS: Record<TierKey, { label: string; level: number; tone: string }> = {
  owner: { label: 'Owner', level: 5, tone: 'bg-[color-mix(in_oklab,var(--color-accent)_16%,transparent)] text-[var(--color-accent)] border-[color-mix(in_oklab,var(--color-accent)_35%,transparent)]' },
  administrator: { label: 'Administrator', level: 4, tone: 'bg-[color-mix(in_oklab,var(--color-accent-2)_18%,transparent)] text-[var(--color-accent-2)] border-[color-mix(in_oklab,var(--color-accent-2)_35%,transparent)]' },
  admin: { label: 'Admin', level: 3, tone: 'bg-[color-mix(in_oklab,var(--color-good)_15%,transparent)] text-[var(--color-good)] border-[color-mix(in_oklab,var(--color-good)_35%,transparent)]' },
  member: { label: 'Member', level: 1, tone: 'bg-[color-mix(in_oklab,var(--color-ink-dim)_14%,transparent)] text-[var(--color-ink-dim)] border-[var(--color-edge)]' },
};

function getRoleTierKey(role: MemberRole): TierKey {
  if (role.administrator) return 'administrator';
  if (role.elevated) return 'admin';
  return 'member';
}

function getRoleTier(role: MemberRole) {
  return TIERS[getRoleTierKey(role)];
}

function getMemberRank(roles: MemberRole[], isOwner: boolean) {
  if (isOwner) return TIERS.owner;
  return roles.reduce<(typeof TIERS)[TierKey]>(
    (best, role) => {
      const tier = getRoleTier(role);
      return tier.level > best.level ? tier : best;
    },
    TIERS.member,
  );
}

const roleCatalogCache = new Map<string, { at: number; roles: MonitorGuildRoleInfo[] }>();

/** Role catalogs change rarely, so reuse one for 2 minutes instead of refetching on every click. */
async function getRoleCatalog(guildId: string, force: boolean): Promise<MonitorGuildRoleInfo[]> {
  const hit = roleCatalogCache.get(guildId);
  if (!force && hit && Date.now() - hit.at < 120_000) return hit.roles;
  const { roles } = await api.monitor.guildRoles(guildId);
  roleCatalogCache.set(guildId, { at: Date.now(), roles });
  return roles;
}

function ProfileCard({
  profile,
  onJoinVoice,
  onSelectUser,
  allowServerDetails,
  preferredGuildId,
}: {
  profile: UserProfile;
  onJoinVoice?: (guildId: string, channelId: string) => void;
  onSelectUser: (userId: string, guildId: string) => void;
  allowServerDetails: boolean;
  preferredGuildId: string | null;
}) {
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [selectedGuildId, setSelectedGuildId] = useState<string | null>(preferredGuildId);
  const [guildRoles, setGuildRoles] = useState<MonitorGuildRoleInfo[]>([]);
  const [guildRolesError, setGuildRolesError] = useState('');
  const [memberRoles, setMemberRoles] = useState<MonitorMemberRoleDetails | null>(null);
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [rolesError, setRolesError] = useState('');
  const [loadingGuild, setLoadingGuild] = useState(false);
  const [detailsAttempt, setDetailsAttempt] = useState(0);
  const created = profile.createdAt
    ? new Date(profile.createdAt).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      })
    : null;

  useEffect(() => {
    if (!allowServerDetails || !selectedGuildId) {
      setGuildRoles([]);
      setGuildRolesError('');
      setMemberRoles(null);
      setRolesError('');
      setLoadingGuild(false);
      return;
    }

    let cancelled = false;
    setLoadingGuild(true);
    setGuildRoles([]);
    setGuildRolesError('');
    setMemberRoles(null);
    setRolesError('');

    const rolesRequest = api.monitor.memberRoleDetails(selectedGuildId, profile.userId);
    const roleCatalogRequest = getRoleCatalog(selectedGuildId, detailsAttempt > 0);
    rolesRequest.then(
      (details) => {
        if (!cancelled) setMemberRoles(details);
      },
      (error: unknown) => {
        if (!cancelled) {
          setRolesError(error instanceof ApiError ? error.message : 'Could not load member roles');
        }
      },
    );
    roleCatalogRequest.then(
      (roles) => {
        if (!cancelled) setGuildRoles(roles);
      },
      (error: unknown) => {
        if (!cancelled) {
          setGuildRolesError(error instanceof ApiError ? error.message : 'Could not load role permissions');
        }
      },
    );

    void Promise.allSettled([rolesRequest, roleCatalogRequest]).then(() => {
      if (!cancelled) setLoadingGuild(false);
    });

    return () => {
      cancelled = true;
    };
  }, [allowServerDetails, detailsAttempt, profile.userId, selectedGuildId]);

  const ranks = useGuildRanks(profile.userId, api.radarRanks);
  const selectedGuild = profile.mutualGuilds.find((guild) => guild.id === selectedGuildId);
  const selectedRole = memberRoles?.roles.find((role) => role.id === selectedRoleId) ?? null;
  const selectedRoleInfo = guildRoles.find((role) => role.id === selectedRoleId);

  useEffect(() => {
    if (!memberRoles) {
      setSelectedRoleId(null);
      return;
    }
    setSelectedRoleId((current) =>
      memberRoles.roles.some((role) => role.id === current)
        ? current
        : [...memberRoles.roles].sort(
            (a, b) => getRoleTier(b).level - getRoleTier(a).level || b.position - a.position,
          )[0]?.id ?? null,
    );
  }, [memberRoles]);

  useEffect(() => {
    if (!selectedGuildId) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedGuildId(null);
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [selectedGuildId]);

  return (
    <div className="animate-rise panel overflow-hidden">
      <div
        className="relative h-32 sm:h-44"
        style={{
          background: profile.bannerUrl
            ? `center/cover no-repeat url(${JSON.stringify(profile.bannerUrl)})`
            : `linear-gradient(120deg, ${profile.accentColor ?? 'var(--color-accent)'}33, var(--color-accent-2)22)`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-panel)] via-[var(--color-panel)]/25 to-transparent" />
        <div className="absolute right-4 top-4 flex items-center gap-2 rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-[10px] font-semibold text-white/80 backdrop-blur">
          <span className={`size-1.5 rounded-full ${profile.inVoice ? 'bg-[var(--color-good)]' : 'bg-white/35'}`} />
          {profile.inVoice ? 'Active in voice' : 'User info'}
        </div>
      </div>

      <div className="relative px-5 pb-6 sm:px-7">
        <div className="absolute -top-16 left-5 sm:-top-[4.5rem] sm:left-7">
          {profile.avatarUrl && !avatarFailed ? (
            <img
              src={profile.avatarUrl}
              alt=""
              decoding="async"
              onError={() => setAvatarFailed(true)}
              className="size-24 rounded-[1.6rem] border-4 border-[var(--color-panel)] object-cover bg-[var(--color-panel)] shadow-xl shadow-black/30 sm:size-28"
            />
          ) : (
            <div className="flex size-24 items-center justify-center rounded-[1.6rem] border-4 border-[var(--color-panel)] bg-[var(--color-panel-2)] font-mono text-2xl font-bold text-[var(--color-accent)] shadow-xl shadow-black/30 sm:size-28">
              {profile.username.slice(0, 2).toUpperCase()}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-4 pt-7 sm:flex-row sm:items-end sm:justify-between sm:pt-8">
          <div className="min-w-0 pt-12 sm:pt-8">
            <p className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--color-accent)]">
                {profile.isBot ? 'Bot info' : 'User info'}
                {profile.isBot && (
                <span className="inline-flex items-center rounded-md bg-[#5865F2] px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                  {profile.isVerifiedBot ? '✓ BOT' : 'BOT'}
                </span>
                )}
              </p>
            <h3 className="truncate text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              {profile.globalName || profile.username}
            </h3>
            <p className="mt-1 truncate text-sm text-[var(--color-ink-dim)]">
              @{profile.username}<span className="mx-2 text-[var(--color-edge-bright)]">/</span>
              <span className="font-mono text-xs text-[var(--color-ink-faint)]">{profile.userId}</span>
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:min-w-64">
            <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 px-3 py-2.5">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">Shared servers</p>
              <p className="mt-1 text-lg font-bold text-[var(--color-ink)]">{profile.mutualGuilds.length}</p>
            </div>
            <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 px-3 py-2.5">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[var(--color-ink-faint)]">{profile.isBot ? 'Bot created' : 'Account created'}</p>
              <p className="mt-1 truncate text-sm font-bold text-[var(--color-ink)]">{created ?? 'Unknown'}</p>
            </div>
          </div>
        </div>

        {profile.bio && (
          <div className="mt-4">
            <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-[var(--color-ink-dim)]">About Me</h4>
            <p className="whitespace-pre-wrap rounded-lg bg-[color-mix(in_oklab,var(--color-void)_30%,transparent)] p-3 text-sm leading-relaxed text-[var(--color-ink)]">
              {profile.bio}
            </p>
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          {profile.badges.map((badge) => (
            <span key={badge} className="chip border-[var(--color-edge-bright)] bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]">
              <IconShield size={12} />
              {badge.replaceAll('_', ' ').toLowerCase()}
            </span>
          ))}
        </div>

        {/* The old build hardcoded inVoice:false, so this box never appeared. */}
        <div
          className="mt-4 flex items-start gap-3 rounded-xl border p-4"
          style={
            profile.inVoice
              ? {
                  borderColor: 'color-mix(in oklab, var(--color-good) 38%, transparent)',
                  background: 'color-mix(in oklab, var(--color-good) 9%, transparent)',
                }
              : { borderColor: 'var(--color-edge)' }
          }
        >
          <span
            className="mt-0.5 shrink-0"
            style={{
              color: profile.inVoice ? 'var(--color-good)' : 'var(--color-ink-faint)',
            }}
          >
            <IconSpeaker size={17} />
          </span>
          {profile.inVoice ? (
            <div className="min-w-0">
              <p className="text-sm font-bold text-[var(--color-good)]">
                In voice · {profile.voiceChannelName ?? profile.voiceChannelId}
              </p>
              <p className="mt-0.5 truncate text-xs text-[var(--color-ink-dim)]">
                {profile.voiceGuildName}
                {profile.voiceMemberCount > 0 && ` · ${profile.voiceMemberCount} connected`}
              </p>
              {(profile.voiceSelfMute || profile.voiceSelfDeaf) && (
                <p className="mt-1 flex gap-2 text-[0.6875rem] text-[var(--color-warn)]">
                  {profile.voiceSelfMute && <span className="inline-flex items-center gap-1"><IconMicOff size={12} /> Muted</span>}
                  {profile.voiceSelfDeaf && <span className="inline-flex items-center gap-1"><IconSpeaker size={12} /> Deafened</span>}
                </p>
              )}
              <p className="mt-1 font-mono text-[0.625rem] text-[var(--color-ink-faint)]">
                {profile.voiceGuildId} / {profile.voiceChannelId}
              </p>
            </div>
          ) : (
            <div>
              <p className="text-sm font-semibold text-[var(--color-ink-dim)]">Not in voice</p>
              <p className="mt-0.5 text-xs text-[var(--color-ink-faint)]">
                Only servers your accounts share with them can be checked.
              </p>
            </div>
          )}
        </div>

        {profile.inVoice && profile.voiceGuildId && profile.voiceChannelId && onJoinVoice && (
          <button
            onClick={() => onJoinVoice(profile.voiceGuildId!, profile.voiceChannelId!)}
            className="btn btn-primary mt-3 w-full py-2 text-xs font-bold"
          >
            <IconSpeaker size={14} />
            Dispatch Bots to Target's Channel
          </button>
        )}

        {profile.mutualGuilds.length > 0 && (
          <section className="mt-7 border-t border-[var(--color-edge)] pt-5">
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--color-accent)]">Network</p>
                <h4 className="mt-1 text-base font-bold text-[var(--color-ink)]">Mutual servers</h4>
              </div>
              <span className="rounded-full border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-1 text-xs font-semibold text-[var(--color-ink-dim)]">
                {profile.mutualGuilds.length} shared
              </span>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {sortGuilds(profile.mutualGuilds, ranks).map((guild) => (
                <button
                  key={guild.id}
                  style={rankCardStyle(ranks[guild.id])}
                  type="button"
                  disabled={!allowServerDetails}
                  onClick={() => setSelectedGuildId(guild.id)}
                  className={`group flex min-w-0 items-center gap-3 rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/30 p-3 text-left transition-all ${
                    allowServerDetails
                      ? 'cursor-pointer hover:-translate-y-0.5 hover:border-[color-mix(in_oklab,var(--color-accent)_45%,var(--color-edge))] hover:bg-[var(--color-surface-dim)]'
                      : 'cursor-default'
                  }`}
                  title={allowServerDetails ? `Open ${guild.name}` : 'Detailed server information is owner-only'}
                >
                  {guild.iconUrl ? (
                    <img src={guild.iconUrl} alt="" loading="lazy" className="size-12 shrink-0 rounded-2xl object-cover shadow-md shadow-black/20" />
                  ) : (
                    <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-[var(--color-surface)] text-[var(--color-accent)]">
                      <IconGlobe size={21} />
                    </span>
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="flex min-w-0 items-center gap-2"><span className="truncate text-sm font-bold text-[var(--color-ink)] transition-colors group-hover:text-[var(--color-accent)]">{guild.name}</span><RankBadge rank={ranks[guild.id]} /></span>
                    <span className="mt-1 block truncate font-mono text-[9px] text-[var(--color-ink-faint)]">{guild.id}</span>
                  </span>
                  <span className="shrink-0 text-[var(--color-ink-faint)] transition-transform group-hover:translate-x-0.5 group-hover:text-[var(--color-accent)]">
                    <IconGlobe size={15} />
                  </span>
                </button>
              ))}
            </div>
            {!allowServerDetails && (
              <p className="mt-3 text-[10px] text-[var(--color-ink-faint)]">
                Detailed server roles and channels are restricted to the owner.
              </p>
            )}
          </section>
        )}
      </div>

      {allowServerDetails && selectedGuildId && createPortal(
        <div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm sm:p-6"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setSelectedGuildId(null);
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="server-profile-title"
            className="animate-rise flex max-h-[min(90dvh,900px)] w-full max-w-5xl flex-col overflow-hidden rounded-3xl border border-[var(--color-edge-bright)] bg-[var(--color-panel)] shadow-2xl shadow-black/50"
          >
            <header className="relative flex shrink-0 items-center gap-4 overflow-hidden border-b border-[var(--color-edge)] p-5 sm:p-7">
              <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-accent)]/10 via-transparent to-[var(--color-accent-2)]/10" />
              {selectedGuild?.iconUrl ? (
                <img src={selectedGuild.iconUrl} alt="" className="relative size-14 rounded-2xl object-cover ring-1 ring-white/10 sm:size-16" />
              ) : (
                <span className="relative flex size-14 items-center justify-center rounded-2xl bg-[var(--color-surface)] text-[var(--color-accent)] sm:size-16">
                  <IconGlobe size={26} />
                </span>
              )}
              <div className="relative min-w-0 flex-1">
                <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-[var(--color-accent)]">Server profile</p>
                <h3 id="server-profile-title" className="mt-1 truncate text-xl font-extrabold text-white sm:text-2xl">
                  {selectedGuild?.name ?? 'Server details'}
                </h3>
                <p className="mt-1 truncate font-mono text-[10px] text-[var(--color-ink-faint)]">{selectedGuildId}</p>
              </div>
              <button type="button" className="btn relative z-10 shrink-0 px-3 py-2" onClick={() => setSelectedGuildId(null)} aria-label="Close server details">
                Close
              </button>
            </header>

            <div className="grid min-h-0 flex-1 grid-cols-1 overflow-y-auto md:grid-cols-[minmax(220px,0.8fr)_minmax(0,1.5fr)] md:overflow-hidden">
              <aside className="border-b border-[var(--color-edge)] p-4 md:overflow-y-auto md:border-b-0 md:border-r sm:p-5">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--color-ink-faint)]">Member roles</p>
                    <h4 className="mt-1 text-sm font-bold text-[var(--color-ink)]">Role list</h4>
                  </div>
                  <span className="rounded-full bg-[color-mix(in_oklab,var(--color-accent)_14%,transparent)] px-2.5 py-1 text-xs font-bold text-[var(--color-accent)]">
                    {memberRoles?.roles.length ?? 0}
                  </span>
                </div>

                {memberRoles && (
                  <div className="mb-4 flex items-center gap-3 rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/35 p-3">
                    {memberRoles.avatarUrl ? (
                      <img src={memberRoles.avatarUrl} alt="" className="size-10 rounded-xl object-cover" />
                    ) : (
                      <span className="flex size-10 items-center justify-center rounded-xl bg-[var(--color-surface)] text-xs font-bold text-[var(--color-accent)]">
                        {(memberRoles.nickname ?? profile.username).slice(0, 2).toUpperCase()}
                      </span>
                    )}
                    <span className="min-w-0">
                      <span className="block truncate text-xs font-bold text-[var(--color-ink)]">{memberRoles.nickname ?? profile.globalName ?? profile.username}</span>
                      <span className="mt-0.5 block truncate text-[10px] text-[var(--color-ink-faint)]">@{profile.username}</span>
                    </span>
                  </div>
                )}

                {memberRoles && (() => {
                  const rank = getMemberRank(memberRoles.roles, memberRoles.isOwner);
                  return (
                    <div className={`mb-4 flex items-center justify-between rounded-2xl border p-3 ${rank.tone}`}>
                      <span className="text-[9px] font-bold uppercase tracking-[0.18em] opacity-80">Rank</span>
                      <span className="text-sm font-extrabold">{rank.label}</span>
                    </div>
                  );
                })()}

                {loadingGuild && (
                  <p className="flex items-center gap-2 rounded-xl bg-[var(--color-surface-dim)] p-3 text-xs text-[var(--color-ink-dim)]">
                    <IconRefresh size={14} className="animate-spin-slow" /> Loading server profile…
                  </p>
                )}
                {(rolesError || guildRolesError) && (
                  <div className="rounded-xl bg-[var(--color-bad-soft)] p-3 text-xs text-[var(--color-bad)]">
                    <p>{rolesError || guildRolesError}</p>
                    <button
                      type="button"
                      className="btn mt-2 w-full py-2 text-xs"
                      onClick={() => setDetailsAttempt((attempt) => attempt + 1)}
                    >
                      <IconRefresh size={13} /> Retry
                    </button>
                  </div>
                )}
                {memberRoles && memberRoles.roles.length > 0 && (
                  <div className="flex gap-2 overflow-x-auto pb-1 md:flex-col md:overflow-visible">
                    {[...memberRoles.roles]
                      .sort((a, b) => getRoleTier(b).level - getRoleTier(a).level || (b.position ?? 0) - (a.position ?? 0))
                      .map((role) => {
                        const tier = getRoleTier(role);
                        return (
                          <button
                            key={role.id}
                            type="button"
                            onClick={() => setSelectedRoleId(role.id)}
                            aria-pressed={selectedRoleId === role.id}
                            className={`flex min-w-44 items-center gap-2.5 rounded-xl border p-3 text-left transition-colors md:min-w-0 ${
                              selectedRoleId === role.id
                                ? 'border-[color-mix(in_oklab,var(--color-accent)_55%,var(--color-edge))] bg-[color-mix(in_oklab,var(--color-accent)_10%,var(--color-surface-dim))]'
                                : 'border-[var(--color-edge)] bg-[var(--color-void)]/25 hover:border-[var(--color-edge-bright)]'
                            }`}
                          >
                            <span className="size-2.5 shrink-0 rounded-full" style={{ background: role.color ?? 'var(--color-ink-faint)' }} />
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-xs font-semibold text-[var(--color-ink)]">{role.name}</span>
                              <span className={`mt-1 inline-flex rounded-full border px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider ${tier.tone}`}>
                                {tier.label}
                              </span>
                            </span>
                            <IconShield size={13} className={selectedRoleId === role.id ? 'text-[var(--color-accent)]' : 'text-[var(--color-ink-faint)]'} />
                          </button>
                        );
                      })}
                  </div>
                )}
                {memberRoles?.roles.length === 0 && (
                  <p className="rounded-xl border border-dashed border-[var(--color-edge-bright)] p-4 text-xs text-[var(--color-ink-faint)]">No visible roles for this member.</p>
                )}
              </aside>

              <div className="min-h-0 space-y-5 p-4 md:overflow-y-auto sm:p-6">
                {selectedRole ? (
                  <section className="rounded-2xl border border-[var(--color-edge)] bg-[var(--color-void)]/30 p-4 sm:p-5">
                    <div className="flex items-start gap-3">
                      <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--color-surface)]">
                        <IconShield size={20} style={{ color: selectedRole.color ?? 'var(--color-accent)' }} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-[var(--color-ink-faint)]">Selected role</p>
                        <h4 className="mt-1 break-words text-lg font-extrabold text-[var(--color-ink)]">{selectedRole.name}</h4>
                      </div>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <span className={`inline-flex rounded-full border px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.12em] ${getRoleTier(selectedRole).tone}`}>
                        {getRoleTier(selectedRole).label}
                      </span>
                      <span className="inline-flex rounded-full border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.12em] text-[var(--color-ink-dim)]">
                        #{selectedRole.position}
                      </span>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
                      <div className="rounded-xl bg-[var(--color-surface-dim)] p-3">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Displayed separately</p>
                        <p className="mt-1 text-sm font-bold text-[var(--color-ink)]">{selectedRole.hoist ? 'Yes' : 'No'}</p>
                      </div>
                      <div className="rounded-xl bg-[var(--color-surface-dim)] p-3">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Mentionable</p>
                        <p className="mt-1 text-sm font-bold text-[var(--color-ink)]">{selectedRoleInfo ? (selectedRoleInfo.mentionable ? 'Yes' : 'No') : '…'}</p>
                      </div>
                      <div className="col-span-2 rounded-xl bg-[var(--color-surface-dim)] p-3 sm:col-span-1">
                        <p className="text-[9px] uppercase tracking-wider text-[var(--color-ink-faint)]">Role ID</p>
                        <p className="mt-1 truncate font-mono text-[10px] text-[var(--color-ink-dim)]" title={selectedRole.id}>{selectedRole.id}</p>
                      </div>
                    </div>
                    <div className="mt-4 border-t border-[var(--color-edge)] pt-4">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[9px] font-bold uppercase tracking-[0.16em] text-[var(--color-ink-faint)]">Permissions</p>
                        <span className="text-[10px] text-[var(--color-ink-faint)]">{selectedRoleInfo?.permissionNames.length ?? 0} granted</span>
                      </div>
                      {selectedRoleInfo && selectedRoleInfo.permissionNames.length > 0 ? (
                        <div className="mt-2 flex max-h-40 flex-wrap gap-1.5 overflow-y-auto">
                          {selectedRoleInfo.permissionNames.map((permission) => (
                            <span key={permission} className="rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-2 py-1 text-[10px] font-medium text-[var(--color-ink-dim)]">
                              {permission.replace(/([a-z])([A-Z])/g, '$1 $2').replaceAll('_', ' ').toLowerCase()}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="mt-2 text-xs text-[var(--color-ink-faint)]">
                          {guildRolesError ? 'Role permissions could not be loaded.' : selectedRoleInfo ? 'This role has no explicit permissions.' : 'Loading role permissions…'}
                        </p>
                      )}
                    </div>
                  </section>
                ) : (
                  <section className="rounded-2xl border border-dashed border-[var(--color-edge-bright)] p-5 text-center">
                    <IconShield size={22} className="mx-auto text-[var(--color-ink-faint)]" />
                    <p className="mt-2 text-sm font-semibold text-[var(--color-ink-dim)]">Select a role to inspect it</p>
                    <p className="mt-1 text-xs text-[var(--color-ink-faint)]">Choose a role from the list to view its available details.</p>
                  </section>
                )}

                {memberRoles?.joinedAt && (
                  <div className="flex items-center gap-2 text-xs text-[var(--color-ink-dim)]">
                    <IconClock size={14} className="text-[var(--color-accent)]" />
                    Joined this server {new Date(memberRoles.joinedAt).toLocaleDateString()}
                  </div>
                )}

              </div>
            </div>
          </section>
        </div>,
        document.body,
      )}
    </div>
  );
}

interface Props {
  config: AppConfig;
  followerCount: number;
  onSave: (patch: Partial<AppConfig>) => void;
  onJoinVoice?: (guildId: string, channelId: string) => void;
  allowServerDetails: boolean;
  isOwner: boolean;
}

export function Radar({ config, followerCount, onSave, onJoinVoice, allowServerDetails, isOwner }: Props) {
  const [userId, setUserId] = useState(config.autoFollowTargetId);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [memberMatches, setMemberMatches] = useState<MonitorMemberSearchResult[]>([]);
  const [preferredGuildId, setPreferredGuildId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [liveScan, setLiveScan] = useState(false);

  useEffect(() => {
    setUserId((current) => current || config.autoFollowTargetId);
  }, [config.autoFollowTargetId]);

  const validUserId = /^\d{17,20}$/.test(userId);
  const validUsername = isOwner && userId.trim().length >= 2 && userId.trim().length <= 32;
  const validSearch = validUserId || validUsername;

  const searchUser = async (targetUserId: string, guildId: string | null = null) => {
    if (!/^\d{17,20}$/.test(targetUserId) || loading) return;
    setUserId(targetUserId);
    setProfile(null);
    setMemberMatches([]);
    setPreferredGuildId(guildId);
    setLoading(true);
    setError('');
    try {
      setProfile(await api.radar(targetUserId));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not reach the server');
    } finally {
      setLoading(false);
    }
  };
  const search = async () => {
    const value = userId.trim();
    if (loading) return;
    if (/^\d{17,20}$/.test(value)) {
      await searchUser(value);
      return;
    }
    if (!isOwner) {
      setError('Username search is restricted to the owner. Search by user ID instead.');
      return;
    }
    if (value.length < 2 || value.length > 32) {
      setError('Enter a 17-20 digit user ID or a username between 2 and 32 characters.');
      return;
    }

    setProfile(null);
    setMemberMatches([]);
    setPreferredGuildId(null);
    setLoading(true);
    setError('');
    try {
      const results = await api.monitor.searchMembers(value);
      setMemberMatches(results);
      if (results.length === 0) {
        setError('No matching members were found in the connected accounts’ cached server data.');
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not search cached server members');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!liveScan || !validUserId) return;
    const timer = setInterval(async () => {
      try {
        const p = await api.radar(userId);
        setProfile(p);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Live user refresh failed');
        setLiveScan(false);
      }
    }, 5000);
    return () => clearInterval(timer);
  }, [liveScan, validUserId, userId]);

  const following = config.autoFollowEnabled;

  return (
    <div className="flex flex-col gap-5">
      <header className="animate-rise panel relative flex items-center gap-4 overflow-hidden p-5">
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-accent)]/10 via-transparent to-[var(--color-accent-2)]/10" />
        <span className="relative flex size-12 shrink-0 items-center justify-center rounded-2xl border border-[color-mix(in_oklab,var(--color-accent)_35%,transparent)] bg-[color-mix(in_oklab,var(--color-accent)_12%,transparent)] text-[var(--color-accent)]">
          <IconRadar size={24} className={liveScan ? 'animate-radar' : undefined} />
        </span>
        <div className="relative min-w-0">
          <h2 className="text-lg font-extrabold tracking-tight text-white">User Info</h2>
          <p className="text-xs text-[var(--color-ink-dim)]">
            Profile, shared servers, roles and voice presence of any Discord user.
          </p>
        </div>
      </header>
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="flex flex-col gap-5 lg:col-span-1">
        <section className="animate-rise panel flex flex-col gap-4 p-5">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-bold text-[var(--color-accent)]">
              <IconSearch size={16} />
              Lookup
            </h2>
            {profile && (
              <button
                type="button"
                onClick={() => setLiveScan((prev) => !prev)}
                className="chip cursor-pointer text-xs"
                style={
                  liveScan
                    ? {
                        color: 'var(--color-good)',
                        borderColor: 'var(--color-good)',
                        background: 'color-mix(in oklab, var(--color-good) 12%, transparent)',
                      }
                    : { color: 'var(--color-ink-faint)' }
                }
                title="Automatically refresh radar every 5 seconds"
              >
                <span
                  className={`inline-block size-2 rounded-full ${
                    liveScan ? 'animate-pulse bg-[var(--color-good)]' : 'bg-[var(--color-ink-faint)]'
                  }`}
                />
                Live {liveScan ? 'ON' : 'OFF'}
              </button>
            )}
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="label" htmlFor="targetId">
              Discord user ID or username
            </label>
            <div className="flex gap-2">
              <input
                id="targetId"
                className="field"
                placeholder="User ID or username"
                value={userId}
                onChange={(e) => {
                  setUserId(e.target.value.trim());
                  setProfile(null);
                  setMemberMatches([]);
                  setPreferredGuildId(null);
                  setError('');
                  setLiveScan(false);
                }}
                onKeyDown={(e) => e.key === 'Enter' && search()}
              />
              <button onClick={() => void search()} disabled={!validSearch || loading} className="btn btn-primary px-3">
                {loading ? (
                  <IconRefresh size={15} className="animate-spin-slow" />
                ) : (
                  <IconSearch size={15} />
                )}
              </button>
            </div>
            {userId && !validSearch && (
              <span className="text-[0.6875rem] text-[var(--color-bad)]">
                Enter a 17-20 digit ID{isOwner ? ' or a username (2-32 characters)' : ''}
              </span>
            )}
            {isOwner && (
              <p className="text-[10px] text-[var(--color-ink-faint)]">
                Username search checks every server your connected accounts are in.
              </p>
            )}
            {memberMatches.length > 0 && (
              <div className="mt-2 flex max-h-64 flex-col gap-1.5 overflow-y-auto border-t border-[var(--color-edge)] pt-3">
                <p className="label">{memberMatches.length} matching server members</p>
                {memberMatches.map((member) => (
                  <button
                    key={`${member.userId}:${member.guildId}`}
                    type="button"
                    onClick={() => void searchUser(member.userId, member.guildId)}
                    className="flex items-center gap-2 rounded-lg border border-[var(--color-edge)] p-2 text-left transition-colors hover:border-[var(--color-accent)]/50"
                  >
                    {member.avatarUrl ? (
                      <img src={member.avatarUrl} alt="" className="size-8 rounded-full object-cover" />
                    ) : (
                      <span className="flex size-8 items-center justify-center rounded-full bg-[var(--color-panel)] text-[10px] font-bold">
                        {member.username.slice(0, 2).toUpperCase()}
                      </span>
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-semibold text-[var(--color-ink)]">
                        {member.nickname ?? member.globalName ?? member.username}
                      </span>
                      <span className="block truncate text-[10px] text-[var(--color-ink-faint)]">
                        @{member.username} · {member.guildName}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 border-t border-[var(--color-edge)] pt-4">
            <p className="label">Auto-follow</p>
            <p className="text-[0.6875rem] leading-relaxed text-[var(--color-ink-faint)]">
              When the target moves to another voice channel, every account marked
              <span className="mx-1 text-[var(--color-accent-2)]">Follow</span>
              moves with them.
            </p>

            <button
              onClick={() =>
                onSave({
                  autoFollowTargetId: userId,
                  autoFollowEnabled: !following,
                })
              }
              disabled={!validUserId}
              className="btn mt-1 w-full"
              style={
                following
                  ? {
                      color: 'var(--color-good)',
                      borderColor: 'color-mix(in oklab, var(--color-good) 40%, transparent)',
                      background: 'color-mix(in oklab, var(--color-good) 10%, transparent)',
                    }
                  : undefined
              }
            >
              <IconRadar size={15} className={following ? 'animate-radar' : undefined} />
              {following ? 'Following target' : 'Enable auto-follow'}
            </button>

            <p className="text-[0.6875rem] text-[var(--color-ink-faint)]">
              {followerCount > 0
                ? `${followerCount} account${followerCount === 1 ? '' : 's'} set to follow.`
                : 'No accounts set to follow yet — turn on Follow on a card.'}
            </p>
          </div>
        </section>

        <section className="panel flex items-start gap-3 p-4">
          <span className="mt-0.5 shrink-0 text-[var(--color-ink-faint)]">
            <IconUsers size={15} />
          </span>
          <p className="text-[0.6875rem] leading-relaxed text-[var(--color-ink-faint)]">
            Voice presence is read from the servers your own accounts are in. A user in a server
            none of your accounts joined cannot be seen.
          </p>
        </section>
      </div>

      <div className="lg:col-span-2">
        {loading ? (
          <Scanning />
        ) : error ? (
          <div
            className="animate-rise panel flex items-center gap-3 p-6"
            style={{ borderColor: 'color-mix(in oklab, var(--color-bad) 38%, transparent)' }}
          >
            <span className="text-[var(--color-bad)]">
              <IconAlert size={18} />
            </span>
            <p className="text-sm text-[var(--color-bad)]">{error}</p>
          </div>
        ) : profile ? (
          <ProfileCard
            key={`${profile.userId}:${preferredGuildId ?? ''}`}
            profile={profile}
            onJoinVoice={onJoinVoice}
            allowServerDetails={allowServerDetails}
            preferredGuildId={preferredGuildId}
            onSelectUser={(targetUserId, guildId) => void searchUser(targetUserId, guildId)}
          />
        ) : (
          <EmptyState />
        )}
      </div>
    </div>
    </div>
  );
}
