import { useState } from 'react';
import type { CSSProperties } from 'react';
import type { StorageStatus } from '@shared/types';
import { IconPlus, IconRefresh, IconTrash } from './Icons';

interface Props {
  busy: boolean;
  hasSessions: boolean;
  canRemoveAll: boolean;
  /** Where accounts are saved, and whether that survives a redeploy. */
  storage?: StorageStatus;
  onImport: (tokens: string) => Promise<void>;
  onRemoveAll: () => void;
}

export function ImportPanel({ busy, hasSessions, canRemoveAll, storage, onImport, onRemoveAll }: Props) {
  const [value, setValue] = useState('');

  const count = value
    .split(/[\r\n,;]+/)
    .map((t) => t.trim())
    .filter((t) => t.length >= 30).length;

  const submit = async () => {
    if (count === 0 || busy) return;
    await onImport(value);
    setValue('');
  };

  return (
    <section className="animate-rise panel flex flex-col gap-3 p-5">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-sm font-bold text-[var(--color-accent)]">
          <IconPlus size={16} />
          Import accounts
        </h2>
        {hasSessions && canRemoveAll && (
          <button
            onClick={onRemoveAll}
            disabled={busy}
            className="rounded-lg p-1.5 text-[var(--color-ink-faint)] transition-colors hover:bg-[color-mix(in_oklab,var(--color-bad)_14%,transparent)] hover:text-[var(--color-bad)]"
            title="Remove every account"
          >
            <IconTrash size={15} />
          </button>
        )}
      </div>

      <textarea
        rows={5}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={'One token per line'}
        spellCheck={false}
        autoComplete="off"
        className="field resize-none leading-relaxed"
        style={{ WebkitTextSecurity: 'disc' } as CSSProperties}
      />

      <div className="flex items-center justify-between gap-2">
        <span className="text-[0.6875rem] text-[var(--color-ink-faint)]">
          {count > 0 ? `${count} token${count === 1 ? '' : 's'} detected` : 'Paste to begin'}
        </span>
        <button onClick={submit} disabled={count === 0 || busy} className="btn btn-primary">
          {busy ? <IconRefresh size={15} className="animate-spin-slow" /> : <IconPlus size={15} />}
          {busy ? 'Connecting' : 'Connect'}
        </button>
      </div>

      <p className="text-[0.6875rem] leading-relaxed text-[var(--color-ink-faint)]">
        Tokens are encrypted (AES-256-GCM) before they are saved and are never sent back to this page.
      </p>

      {storage && (
        <p
          className="text-[0.6875rem] font-semibold leading-relaxed"
          style={{ color: storage.durable ? 'var(--color-good)' : 'var(--color-warn)' }}
        >
          {storage.durable ? '● ' : '⚠ '}
          {storage.message}
        </p>
      )}
    </section>
  );
}
