import React, { useState } from 'react';
import type { BotSession, KeyPermissions, UserRole, VoiceSlot } from '@shared/types';
import {
  IconAlert,
  IconCheckSquare,
  IconEdit,
  IconMic,
  IconMicOff,
  IconRadar,
  IconRefresh,
  IconShield,
  IconShieldOff,
  IconSpeaker,
  IconSpeakerOff,
  IconSquare,
  IconTrash,
} from './Icons';

const STATUS_TONE: Record<BotSession['status'], string> = {
  online: 'var(--color-good)',
  connecting: 'var(--color-warn)',
  offline: 'var(--color-ink-faint)',
  error: 'var(--color-bad)',
};

function initials(name: string): string {
  return (name || '?').slice(0, 2).toUpperCase();
}

/** One row in the multi-server voice list */
interface VoiceSlotRowProps {
  slot: VoiceSlot;
  canMuteDeaf: boolean;
  pending?: string | null;
  onMute: (guildId: string) => void;
  onDeaf: (guildId: string) => void;
  onLeave: (guildId: string) => void;
}

function VoiceSlotRow({ slot, canMuteDeaf, pending, onMute, onDeaf, onLeave }: VoiceSlotRowProps) {
  return (
    <div className="flex items-center gap-2 rounded-md bg-[var(--color-good)]/8 border border-[var(--color-good)]/15 px-2.5 py-1.5 min-w-0">
      {/* live pulse */}
      <span className="relative flex size-1.5 shrink-0">
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-good)] opacity-50" />
        <span className="relative inline-flex size-1.5 rounded-full bg-[var(--color-good)]" />
      </span>

      <div className="min-w-0 flex-1">
        <p className="truncate text-[0.625rem] font-semibold leading-tight text-[var(--color-good)]">
          {slot.guildName ?? slot.guildId}
        </p>
        <p className="truncate text-[0.5625rem] leading-tight text-[var(--color-ink-dim)] opacity-70">
          {slot.channelName ?? slot.channelId}
        </p>
      </div>

      {canMuteDeaf && (
        <div className="flex shrink-0 items-center gap-0.5">
          <button
            type="button"
            onClick={() => onMute(slot.guildId)}
            disabled={pending !== null}
            aria-pressed={slot.selfMute}
            className="rounded p-1 transition-colors disabled:opacity-40"
            style={{ color: slot.selfMute ? 'var(--color-warn)' : 'var(--color-ink-faint)' }}
            title={slot.selfMute ? 'Unmute' : 'Mute'}
          >
            {slot.selfMute ? <IconMicOff size={11} /> : <IconMic size={11} />}
          </button>
          <button
            type="button"
            onClick={() => onDeaf(slot.guildId)}
            disabled={pending !== null}
            aria-pressed={slot.selfDeaf}
            className="rounded p-1 transition-colors disabled:opacity-40"
            style={{ color: slot.selfDeaf ? 'var(--color-warn)' : 'var(--color-ink-faint)' }}
            title={slot.selfDeaf ? 'Undeafen' : 'Deafen'}
          >
            {slot.selfDeaf ? <IconSpeakerOff size={11} /> : <IconSpeaker size={11} />}
          </button>
        </div>
      )}

      {/* leave this specific guild */}
      <button
        type="button"
        onClick={() => onLeave(slot.guildId)}
        className="shrink-0 rounded p-1 text-[var(--color-ink-faint)] transition-colors hover:text-[var(--color-bad)]"
        title={`Leave ${slot.guildName ?? slot.guildId}`}
      >
        {/* ✕ */}
        <svg width="9" height="9" viewBox="0 0 10 10" fill="none">
          <path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
      </button>
    </div>
  );
}

interface Props {
  key?: string | number;
  session: BotSession;
  selected: boolean;
  index: number;
  role?: UserRole;
  permissions?: KeyPermissions;
  onToggleSelect: (id: string) => void;
  onRemove: (session: BotSession) => void;
  onReconnect: (session: BotSession) => void;
  /** Replace this account's token (owner / keys allowed to import + delete bots). */
  onReplaceToken?: (session: BotSession, token: string) => Promise<void>;
  onToggleFlag: (session: BotSession, flag: 'antiLeave' | 'autoFollow') => void;
  onSetVoiceState: (session: BotSession, patch: { selfMute?: boolean; selfDeaf?: boolean }, guildId: string) => void;
  onLeaveGuild: (session: BotSession, guildId: string) => void;
}

export function SessionCard({
  session,
  selected,
  index,
  role = 'owner',
  permissions,
  onToggleSelect,
  onRemove,
  onReconnect,
  onReplaceToken,
  onToggleFlag,
  onSetVoiceState,
  onLeaveGuild,
}: Props) {
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [voicePending, setVoicePending] = useState<string | null>(null);
  const [editingToken, setEditingToken] = useState(false);
  const [newToken, setNewToken] = useState('');
  const [savingToken, setSavingToken] = useState(false);
  const tone = STATUS_TONE[session.status];
  const showAvatar = session.avatarUrl && !avatarFailed;

  const canDelete      = role === 'owner' || permissions?.canDeleteBots      !== false;
  const canMuteDeaf   = role === 'owner' || permissions?.canMuteDeaf        !== false;
  const canAntiLeave  = role === 'owner' || permissions?.canUseAntiLeave    !== false;
  const canAutoFollow = role === 'owner' || permissions?.canUseAutoFollow    !== false;
  const canLeave      = role === 'owner' || permissions?.canLeaveVoice      !== false;
  const canReconnect  = role === 'owner' || permissions?.canReconnectBots   !== false;
  const canEditToken  =
    Boolean(onReplaceToken) &&
    (role === 'owner' || (permissions?.canImportBots === true && permissions?.canDeleteBots === true));

  const saveToken = async () => {
    if (!onReplaceToken || newToken.trim().length < 30 || savingToken) return;
    setSavingToken(true);
    try {
      await onReplaceToken(session, newToken);
      setNewToken('');
      setEditingToken(false);
    } finally {
      setSavingToken(false);
    }
  };

  // voiceSlots — fall back to legacy single-slot shape for old server versions
  const slots: VoiceSlot[] = session.voiceSlots?.length
    ? session.voiceSlots
    : session.inVoice && session.guildId && session.channelId
      ? [{
          guildId: session.guildId,
          guildName: session.guildName,
          channelId: session.channelId,
          channelName: session.channelName,
          selfMute: session.selfMute,
          selfDeaf: session.selfDeaf,
        }]
      : [];

  const flipFlag = (guildId: string, flag: 'mute' | 'deaf') => {
    if (voicePending) return;
    setVoicePending(guildId + flag);
    const slot = slots.find((s) => s.guildId === guildId);
    if (!slot) return;
    const patch = flag === 'mute' ? { selfMute: !slot.selfMute } : { selfDeaf: !slot.selfDeaf };
    onSetVoiceState(session, patch, guildId);
    window.setTimeout(() => setVoicePending(null), 600);
  };

  // Subtle 3D tilt that follows the mouse. Lives on a wrapper because the card's own
  // entrance animation keeps control of its transform.
  const tiltMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return;
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    el.style.setProperty('--tilt-y', `${(px * 6).toFixed(2)}deg`);
    el.style.setProperty('--tilt-x', `${(-py * 6).toFixed(2)}deg`);
  };
  const tiltReset = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.style.setProperty('--tilt-x', '0deg');
    e.currentTarget.style.setProperty('--tilt-y', '0deg');
  };

  return (
    <div className="tilt-3d h-full" onPointerMove={tiltMove} onPointerLeave={tiltReset}>
    <article
      className={`animate-rise panel group flex h-full flex-col gap-0 overflow-hidden transition-[border-color,transform] duration-200 hover:-translate-y-0.5 ${
        session.inVoice ? 'live-glow' : ''
      }`}
      style={{
        animationDelay: `${Math.min(index * 45, 400)}ms`,
        borderColor: selected
          ? 'color-mix(in oklab, var(--color-accent) 55%, transparent)'
          : undefined,
        boxShadow: selected
          ? '0 0 0 1px color-mix(in oklab, var(--color-accent) 30%, transparent), 0 10px 34px -20px var(--color-accent)'
          : undefined,
      }}
    >
      {/* ── top section ─────────────────────────────────── */}
      <div className="flex items-start gap-3 p-4">
        {/* checkbox */}
        <button
          onClick={() => onToggleSelect(session.id)}
          className="mt-0.5 shrink-0 text-[var(--color-ink-faint)] transition-colors hover:text-[var(--color-accent)]"
          style={selected ? { color: 'var(--color-accent)' } : undefined}
          aria-pressed={selected}
          aria-label={selected ? `Deselect ${session.username}` : `Select ${session.username}`}
        >
          {selected ? <IconCheckSquare size={18} /> : <IconSquare size={18} />}
        </button>

        {/* avatar */}
        <div className="relative shrink-0">
          {showAvatar ? (
            <img
              src={session.avatarUrl ?? ''}
              alt=""
              loading="lazy"
              decoding="async"
              onError={() => setAvatarFailed(true)}
              className="size-11 rounded-full border border-[var(--color-edge-bright)] object-cover"
            />
          ) : (
            <div className="flex size-11 items-center justify-center rounded-full border border-[var(--color-edge-bright)] bg-[color-mix(in_oklab,var(--color-accent)_10%,transparent)] font-mono text-xs font-bold text-[var(--color-accent)]">
              {initials(session.username)}
            </div>
          )}
          <span
            className="absolute -bottom-0.5 -right-0.5 flex size-3.5 items-center justify-center rounded-full border-2 border-[var(--color-panel)]"
            style={{ background: tone }}
            title={session.status}
          />
        </div>

        {/* name / status */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-sm font-bold">{session.username}</p>
            <span className="shrink-0 font-mono text-[0.625rem] text-[var(--color-ink-faint)]">
              ···{session.tokenHint}
            </span>
          </div>

          {session.status === 'error' ? (
            <p className="mt-1 flex items-center gap-1.5 truncate text-[0.6875rem] text-[var(--color-bad)]">
              <IconAlert size={12} className="shrink-0" />
              {session.error ?? 'Connection failed'}
            </p>
          ) : slots.length === 0 ? (
            <p className="mt-1 font-mono text-[0.6875rem] text-[var(--color-ink-faint)]">
              {session.status === 'online'
                ? `Idle · ${session.guildCount} servers`
                : session.status}
            </p>
          ) : (
            /* voice count badge when in ≥1 guild */
            <p className="mt-1 text-[0.6875rem] font-medium text-[var(--color-good)]">
              In voice · {slots.length} {slots.length === 1 ? 'server' : 'servers'}
            </p>
          )}
        </div>

        {/* top-right actions */}
        <div className="flex shrink-0 items-center gap-0.5">
          {session.status !== 'online' && canReconnect && (
            <button
              onClick={() => onReconnect(session)}
              className="rounded-lg p-1.5 text-[var(--color-ink-faint)] transition-colors hover:bg-[var(--color-edge)] hover:text-[var(--color-accent)]"
              title="Reconnect this account"
            >
              <IconRefresh size={15} />
            </button>
          )}
          {canEditToken && (
            <button
              onClick={() => {
                setEditingToken((v) => !v);
                setNewToken('');
              }}
              className="rounded-lg p-1.5 text-[var(--color-ink-faint)] transition-colors hover:bg-[var(--color-edge)] hover:text-[var(--color-accent)]"
              title="Edit this account's token"
            >
              <IconEdit size={15} />
            </button>
          )}
          {canDelete && (
            <button
              onClick={() => onRemove(session)}
              className="rounded-lg p-1.5 text-[var(--color-ink-faint)] transition-colors hover:bg-[color-mix(in_oklab,var(--color-bad)_14%,transparent)] hover:text-[var(--color-bad)]"
              title="Remove this account"
            >
              <IconTrash size={15} />
            </button>
          )}
        </div>
      </div>

      {/* ── edit token ───────────────────────────────────── */}
      {editingToken && canEditToken && (
        <div className="flex flex-col gap-2 px-4 pb-3">
          <input
            type="password"
            value={newToken}
            onChange={(e) => setNewToken(e.target.value)}
            placeholder="Paste the new token"
            spellCheck={false}
            autoComplete="off"
            className="field"
          />
          <div className="flex items-center justify-between gap-2">
            <span className="text-[0.625rem] text-[var(--color-ink-faint)]">
              Checked by logging in first - the old token is only replaced if the new one works.
            </span>
            <div className="flex shrink-0 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setEditingToken(false);
                  setNewToken('');
                }}
                className="btn"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void saveToken()}
                disabled={newToken.trim().length < 30 || savingToken}
                className="btn btn-primary"
              >
                {savingToken ? 'Checking' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── voice slots ──────────────────────────────────── */}
      {slots.length > 0 && (
        <div className="flex flex-col gap-1.5 px-4 pb-3">
          {slots.map((slot) => (
            <React.Fragment key={slot.guildId}>
              <VoiceSlotRow
                slot={slot}
                canMuteDeaf={canMuteDeaf}
                pending={voicePending}
                onMute={(g) => flipFlag(g, 'mute')}
                onDeaf={(g) => flipFlag(g, 'deaf')}
                onLeave={(g) => canLeave && onLeaveGuild(session, g)}
              />
            </React.Fragment>
          ))}
        </div>
      )}

      {/* ── bottom chips ─────────────────────────────────── */}
      <div className="flex items-center gap-1.5 border-t border-[var(--color-edge)] px-4 py-2.5">
        {canAntiLeave && (
          <button
            onClick={() => onToggleFlag(session, 'antiLeave')}
            className="chip cursor-pointer transition-colors"
            style={
              session.antiLeave
                ? {
                    color: 'var(--color-good)',
                    borderColor: 'color-mix(in oklab, var(--color-good) 32%, transparent)',
                    background: 'color-mix(in oklab, var(--color-good) 10%, transparent)',
                  }
                : { color: 'var(--color-ink-faint)', borderColor: 'var(--color-edge)' }
            }
            title="Rejoin automatically if pulled out of voice"
          >
            {session.antiLeave ? <IconShield size={12} /> : <IconShieldOff size={12} />}
            Anti-leave
          </button>
        )}

        {canAutoFollow && (
          <button
            onClick={() => onToggleFlag(session, 'autoFollow')}
            className="chip cursor-pointer transition-colors"
            style={
              session.autoFollow
                ? {
                    color: 'var(--color-accent-2)',
                    borderColor: 'color-mix(in oklab, var(--color-accent-2) 34%, transparent)',
                    background: 'color-mix(in oklab, var(--color-accent-2) 12%, transparent)',
                  }
                : { color: 'var(--color-ink-faint)', borderColor: 'var(--color-edge)' }
            }
            title="Move with the tracked target when they change channel"
          >
            <IconRadar size={12} />
            Follow
          </button>
        )}
      </div>
    </article>
    </div>
  );
}
