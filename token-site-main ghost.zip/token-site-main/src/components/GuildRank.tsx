import type { CSSProperties } from 'react';
import { useEffect, useState } from 'react';
import type { GuildRank } from '../lib/api';
import { IconCrown, IconShield } from './Icons';

const RANKS: Record<GuildRank, { label: string; color: string; order: number }> = {
  owner: { label: 'Owner', color: '#fbbf24', order: 0 },
  administrator: { label: 'Administrator', color: '#f472b6', order: 1 },
  admin: { label: 'Admin', color: '#34d399', order: 2 },
};

/** Loads the per-server ranks after the profile is shown; never blocks the page. */
export function useGuildRanks(
  userId: string | undefined,
  load: (userId: string) => Promise<Record<string, GuildRank>>,
): Record<string, GuildRank> {
  const [ranks, setRanks] = useState<Record<string, GuildRank>>({});
  useEffect(() => {
    setRanks({});
    if (!userId) return;
    let cancelled = false;
    load(userId)
      .then((r) => { if (!cancelled) setRanks(r); })
      .catch(() => { /* no badges if it fails */ });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);
  return ranks;
}

/** Ranked servers first (owner, administrator, admin), the rest keep their order. */
export function sortGuilds<T extends { id: string }>(guilds: T[], ranks: Record<string, GuildRank>): T[] {
  const weight = (g: T) => (ranks[g.id] ? RANKS[ranks[g.id]].order : 99);
  return guilds
    .map((g, i) => ({ g, i }))
    .sort((a, b) => weight(a.g) - weight(b.g) || a.i - b.i)
    .map((x) => x.g);
}

export function rankCardStyle(rank: GuildRank | undefined): CSSProperties | undefined {
  if (!rank) return undefined;
  const c = RANKS[rank].color;
  return { borderColor: `${c}80`, backgroundColor: `${c}14`, boxShadow: `0 0 0 1px ${c}22` };
}

export function RankBadge({ rank }: { rank: GuildRank | undefined }) {
  if (!rank) return null;
  const { label, color } = RANKS[rank];
  const Icon = rank === 'owner' ? IconCrown : IconShield;
  return (
    <span
      className="inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider"
      style={{ color, borderColor: `${color}66`, backgroundColor: `${color}1f` }}
      title={`${label} in this server`}
    >
      <Icon size={10} />
      {label}
    </span>
  );
}
