import { useCallback, useEffect, useId, useRef, useState } from 'react';
import type { BotSession, KeyPermissions, UserRole } from '@shared/types';
import {
  IconAlert,
  IconBolt,
  IconBomb,
  IconCheck,
  IconMic,
  IconRefresh,
  IconSearch,
  IconShield,
  IconSpeaker,
  IconStop,
} from './Icons';

/* ─────────────────────────────────────────────────────────── types */
interface DiscordChannel {
  id: string;
  name: string;
  type: 'text' | 'voice' | 'stage';
  parentId: string | null;
}

interface LogLine {
  id: number;
  ok: boolean;
  text: string;
}

interface ScanResult {
  guildId: string;
  channels: DiscordChannel[];
}

interface Props {
  sessions: BotSession[];
  role?: UserRole;
  permissions?: KeyPermissions;
}

/* ─────────────────────────────────────────────────────────── helpers */
const isSnowflake = (v: string) => /^\d{17,20}$/.test(v.trim());

function fmtMs(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

/* ─────────────────────────────────────────────────────────── sub-components */
function ChannelTag({ ch, selected, onToggle }: {
  ch: DiscordChannel;
  selected: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="btn text-xs px-2.5 py-1.5 flex items-center gap-1.5 transition-all"
      style={selected ? {
        color: 'var(--color-accent)',
        borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
        background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
      } : undefined}
    >
      <span className="text-[0.65rem] opacity-60 shrink-0">
        {ch.type === 'text' ? '#' : ch.type === 'voice' ? <IconSpeaker size={12} /> : <IconMic size={12} />}
      </span>
      <span className="truncate max-w-[100px]">{ch.name}</span>
    </button>
  );
}

function LiveLog({ lines }: { lines: LogLine[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { ref.current?.scrollIntoView({ behavior: 'smooth' }); }, [lines]);
  if (lines.length === 0) return null;
  return (
    <div className="rounded-xl border border-[var(--color-edge)] bg-[var(--color-surface-dim)] p-3 max-h-52 overflow-y-auto">
      {lines.map(l => (
        <div key={l.id} className={`flex items-start gap-2 py-[2px] font-mono text-[0.6rem] leading-4 ${l.ok ? 'text-[var(--color-good)]' : 'text-[var(--color-bad)]'}`}>
          <span className="shrink-0">{l.ok ? <IconCheck size={12} /> : <IconAlert size={12} />}</span>
          <span className="break-all">{l.text}</span>
        </div>
      ))}
      <div ref={ref} />
    </div>
  );
}

function ProgressBar({ sent, total }: { sent: number; total: number }) {
  if (total === 0) return null;
  const pct = Math.min(100, Math.round((sent / total) * 100));
  return (
    <div className="flex flex-col gap-1">
      <div className="flex justify-between text-[0.6875rem]">
        <span className="text-[var(--color-ink-faint)]">Progress</span>
        <span className="font-mono font-bold text-[var(--color-accent)]">{sent}/{total} · {pct}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-[var(--color-edge)] overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-200"
          style={{
            width: `${pct}%`,
            background: pct === 100
              ? 'var(--color-good)'
              : 'linear-gradient(90deg, var(--color-accent), var(--color-accent-2))',
          }}
        />
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── main */
export function GuildBlast({ sessions, role = 'owner', permissions }: Props) {
  const uid = useId();

  // ── scan state
  const [guildId, setGuildId]         = useState('');
  const [scanBotId, setScanBotId]     = useState('');
  const [scanning, setScanning]       = useState(false);
  const [scanError, setScanError]     = useState('');
  const [scanResult, setScanResult]   = useState<ScanResult | null>(null);

  // ── channel selection
  const [selChannels, setSelChannels] = useState<Set<string>>(new Set());
  const [filterType, setFilterType]   = useState<'all' | 'text' | 'voice'>('all');

  // ── bot selection
  const [botScope, setBotScope]       = useState<'all' | 'specific'>('all');
  const [selBots, setSelBots]         = useState<string[]>([]);

  // ── blast config
  const [message, setMessage]         = useState('');
  const [msgsPerChannel, setMsgsPerChannel] = useState('1');
  const [delayMs, setDelayMs]         = useState('0');
  const [smartMode, setSmartMode]     = useState(true);

  // ── runtime
  const [blasting, setBlasting]       = useState(false);
  const [done, setDone]               = useState(false);
  const [sent, setSent]               = useState(0);
  const [errors, setErrors]           = useState(0);
  const [logs, setLogs]               = useState<LogLine[]>([]);
  const [jobId, setJobId]             = useState('');

  const logId = useRef(0);
  const canUse = role === 'owner' || permissions?.canUseSpammer === true;

  const online = sessions.filter(s => s.status === 'online');
  const activeBots = botScope === 'all' ? online : online.filter(s => selBots.includes(s.id));

  const msgsNum  = Math.max(1, parseInt(msgsPerChannel, 10) || 1);
  const delayNum = Math.max(0, parseInt(delayMs, 10) || 0);
  const totalTarget = selChannels.size * msgsNum;

  const guildOk   = isSnowflake(guildId);
  const msgOk     = message.trim().length > 0 && message.trim().length <= 2000;
  const canScan   = guildOk && online.length > 0 && !scanning && canUse;
  const canBlast  = !blasting && selChannels.size > 0 && msgOk && activeBots.length > 0 && canUse;

  const addLog = useCallback((text: string, ok: boolean) => {
    setLogs(prev => [...prev.slice(-199), { id: logId.current++, text, ok }]);
  }, []);

  // ── auto-pick first online bot for scanning
  useEffect(() => {
    if (!scanBotId && online.length > 0) setScanBotId(online[0].id);
  }, [online.length]);

  // ── scan
  const handleScan = useCallback(async () => {
    if (!canScan || !scanBotId) return;
    setScanning(true);
    setScanError('');
    setScanResult(null);
    setSelChannels(new Set());
    setLogs([]);
    setDone(false);
    setSent(0);
    setErrors(0);

    try {
      const res = await fetch(`/api/spammer/scan-guild?botId=${encodeURIComponent(scanBotId)}&guildId=${encodeURIComponent(guildId.trim())}`, {
        credentials: 'include',
      });
      const data = await res.json() as { channels?: DiscordChannel[]; error?: string };
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
      setScanResult({ guildId: guildId.trim(), channels: data.channels ?? [] });
      // Auto-select all
      setSelChannels(new Set(data.channels?.map(c => c.id) ?? []));
      addLog(`Scan: ${data.channels?.length ?? 0} channels found in ${guildId.trim().slice(-6)}`, true);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Scan failed';
      setScanError(msg);
      addLog(`Scan error: ${msg}`, false);
    } finally {
      setScanning(false);
    }
  }, [canScan, scanBotId, guildId, addLog]);

  // ── blast
  const handleBlast = useCallback(async () => {
    if (!canBlast || !scanResult) return;

    const newJobId = crypto.randomUUID();
    setJobId(newJobId);
    setBlasting(true);
    setDone(false);
    setSent(0);
    setErrors(0);
    setLogs([]);

    const body = JSON.stringify({
      jobId: newJobId,
      botIds: activeBots.map(b => b.id),
      guildId: scanResult.guildId,
      channelIds: Array.from(selChannels),
      message: message.trim(),
      delayMs: delayNum,
      msgsPerChannel: msgsNum,
      smartMode,
    });

    try {
      const res = await fetch('/api/spammer/blast', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body,
      });

      if (!res.ok || !res.body) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? `HTTP ${res.status}`);
      }

      // Read SSE stream
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';

      while (true) {
        const { value, done: streamDone } = await reader.read();
        if (streamDone) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split('\n\n');
        buf = parts.pop() ?? '';
        for (const part of parts) {
          const line = part.trim();
          if (!line.startsWith('data:')) continue;
          try {
            const ev = JSON.parse(line.slice(5)) as {
              type: string;
              botName?: string;
              channelId?: string;
              error?: string;
              totalSent?: number;
              totalErrors?: number;
              cancelled?: boolean;
              wait?: number;
            };
            if (ev.type === 'sent') {
              setSent(ev.totalSent ?? 0);
              const chName = scanResult.channels.find(c => c.id === ev.channelId)?.name ?? ev.channelId?.slice(-6) ?? '?';
              addLog(`${ev.botName} → #${chName}`, true);
            } else if (ev.type === 'error') {
              setErrors(prev => prev + 1);
              const chName = scanResult.channels.find(c => c.id === ev.channelId)?.name ?? '?';
              addLog(`${ev.botName} → #${chName}: ${ev.error}`, false);
            } else if (ev.type === 'ratelimit') {
              addLog(`Rate limit — waiting ${fmtMs(ev.wait ?? 0)}`, false);
            } else if (ev.type === 'done') {
              addLog(
                ev.cancelled
                  ? `Stopped — ${ev.totalSent} sent, ${ev.totalErrors} errors`
                  : `Done — ${ev.totalSent} sent, ${ev.totalErrors} errors`,
                !ev.cancelled,
              );
            }
          } catch { /* ignore malformed SSE */ }
        }
      }
    } catch (err) {
      addLog(`Blast error: ${err instanceof Error ? err.message : String(err)}`, false);
    } finally {
      setBlasting(false);
      setDone(true);
    }
  }, [canBlast, scanResult, activeBots, selChannels, message, delayNum, msgsNum, smartMode, addLog]);

  // ── kill
  const handleKill = useCallback(async () => {
    if (!jobId) return;
    await fetch('/api/spammer/blast-kill', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId }),
    }).catch(() => null);
  }, [jobId]);

  // ── channel filter
  const visibleChannels = (scanResult?.channels ?? []).filter(c =>
    filterType === 'all' || c.type === filterType
  );

  const toggleChannel = (id: string) => setSelChannels(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });

  const toggleBot = (id: string) => setSelBots(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  );

  const selectAllChannels = () => setSelChannels(new Set(visibleChannels.map(c => c.id)));
  const clearChannels = () => setSelChannels(new Set());

  // ── speed label
  const speedLabel = (() => {
    if (delayNum === 0) return 'Burst';
    const msgsPerSec = (1000 / delayNum) * activeBots.length;
    return `~${msgsPerSec.toFixed(1)} msg/s`;
  })();

  /* ── render ─────────────────────────────────────────────── */
  return (
    <section className="animate-rise panel flex flex-col gap-5 p-5 sm:p-6">

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex size-7 items-center justify-center rounded-lg text-[var(--color-accent)]"><IconBomb size={18} /></span>
          <div>
            <h2 className="text-sm font-bold tracking-tight">Guild Blast</h2>
            <p className="text-[0.6rem] text-[var(--color-ink-faint)]">Scan server → select channels → send to all</p>
          </div>
        </div>
        {blasting && (
          <span className="chip flex items-center gap-1.5 text-[var(--color-warn)]"
            style={{ borderColor: 'color-mix(in oklab,var(--color-warn) 35%,transparent)', background: 'color-mix(in oklab,var(--color-warn) 9%,transparent)' }}>
            <span className="relative flex size-1.5 shrink-0">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-warn)] opacity-70" />
              <span className="relative inline-flex size-1.5 rounded-full bg-[var(--color-warn)]" />
            </span>
            Blasting…
          </span>
        )}
        {done && !blasting && (
          <span className="chip text-[var(--color-good)]"
            style={{ borderColor: 'color-mix(in oklab,var(--color-good) 35%,transparent)', background: 'color-mix(in oklab,var(--color-good) 9%,transparent)' }}>
            Done · {sent} sent
          </span>
        )}
      </div>

      {/* ── STEP 1: Guild ID + scan bot */}
      <div className="flex flex-col gap-3 rounded-xl border border-[var(--color-edge)] p-4">
        <span className="text-[0.6rem] font-bold uppercase tracking-widest text-[var(--color-ink-faint)]">
          Step 1 — Target Server
        </span>

        <div className="flex gap-3">
          <div className="flex-1 flex flex-col gap-1">
            <label className="label text-[0.6875rem]" htmlFor={`${uid}-gid`}>Server (Guild) ID</label>
            <input
              id={`${uid}-gid`}
              className="field font-mono text-sm"
              type="text"
              inputMode="numeric"
              placeholder="000000000000000000"
              value={guildId}
              onChange={e => { setGuildId(e.target.value.trim()); setScanResult(null); setSelChannels(new Set()); }}
              style={guildId && !guildOk ? { borderColor: 'color-mix(in oklab,var(--color-bad) 55%,transparent)' } : undefined}
            />
          </div>
          <div className="flex flex-col gap-1 min-w-0 w-36">
            <label className="label text-[0.6875rem]" htmlFor={`${uid}-sbot`}>Scan via bot</label>
            <select
              id={`${uid}-sbot`}
              className="field text-xs"
              value={scanBotId}
              onChange={e => setScanBotId(e.target.value)}
            >
              {online.map(s => (
                <option key={s.id} value={s.id}>{s.username}</option>
              ))}
              {online.length === 0 && <option value="">No bots online</option>}
            </select>
          </div>
        </div>

        <button
          type="button"
          disabled={!canScan}
          onClick={handleScan}
          className="btn btn-primary disabled:opacity-40 self-start"
        >
          {scanning ? (
            <>
              <IconRefresh size={14} className="animate-spin" />
              Scanning…
            </>
          ) : (
            <><IconSearch size={14} /> Scan Channels</>
          )}
        </button>

        {scanError && (
          <div className="rounded-lg bg-[var(--color-bad-soft)] px-3 py-2 text-xs text-[var(--color-bad)]">
            {scanError}
          </div>
        )}
      </div>

      {/* ── STEP 2: Channel selection */}
      {scanResult && (
        <div className="flex flex-col gap-3 rounded-xl border border-[var(--color-edge)] p-4">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[0.6rem] font-bold uppercase tracking-widest text-[var(--color-ink-faint)]">
              Step 2 — Channels ({selChannels.size}/{scanResult.channels.length})
            </span>
            <div className="flex gap-1.5">
              {(['all', 'text', 'voice'] as const).map(f => (
                <button key={f} type="button" onClick={() => setFilterType(f)}
                  className="btn text-[0.6rem] px-2 py-1"
                  style={filterType === f ? {
                    color: 'var(--color-accent-2)',
                    borderColor: 'color-mix(in oklab,var(--color-accent-2) 45%,transparent)',
                    background: 'color-mix(in oklab,var(--color-accent-2) 11%,transparent)',
                  } : undefined}
                >
                  {f === 'all' ? 'All' : f === 'text' ? '# Text' : <><IconSpeaker size={11} /> Voice</>}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button type="button" onClick={selectAllChannels} className="btn text-xs px-2.5 py-1">
              Select all ({visibleChannels.length})
            </button>
            <button type="button" onClick={clearChannels} className="btn text-xs px-2.5 py-1">
              Clear
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto">
            {visibleChannels.length === 0
              ? <span className="text-xs text-[var(--color-ink-faint)]">No channels of this type</span>
              : visibleChannels.map(ch => (
                <ChannelTag
                  key={ch.id}
                  ch={ch}
                  selected={selChannels.has(ch.id)}
                  onToggle={() => toggleChannel(ch.id)}
                />
              ))
            }
          </div>
        </div>
      )}

      {/* ── STEP 3: Message + config */}
      {scanResult && (
        <div className="flex flex-col gap-4 rounded-xl border border-[var(--color-edge)] p-4">
          <span className="text-[0.6rem] font-bold uppercase tracking-widest text-[var(--color-ink-faint)]">
            Step 3 — Message & Config
          </span>

          {/* Message */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <label className="label" htmlFor={`${uid}-msg`}>Message</label>
              <span className={`text-[0.6875rem] ${message.length > 2000 ? 'text-[var(--color-bad)]' : 'text-[var(--color-ink-faint)]'}`}>
                {message.length}/2000
              </span>
            </div>
            <textarea
              id={`${uid}-msg`}
              className="field min-h-[72px] resize-y"
              placeholder={"Message here…\nUse {option1|option2} to spin variants"}
              value={message}
              onChange={e => setMessage(e.target.value)}
            />
          </div>

          {/* Config row */}
          <div className="grid grid-cols-2 gap-4">
            {/* msgs per channel */}
            <div className="flex flex-col gap-1.5">
              <label className="label text-[0.6875rem]" htmlFor={`${uid}-mpc`}>Msgs / channel</label>
              <input
                id={`${uid}-mpc`}
                type="number" min={1} max={100}
                className="field"
                value={msgsPerChannel}
                onChange={e => setMsgsPerChannel(e.target.value)}
              />
              <span className="text-[0.6rem] text-[var(--color-ink-faint)]">
                Total: {totalTarget} msgs to {selChannels.size} ch
              </span>
            </div>

            {/* delay */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between">
                <label className="label text-[0.6875rem]" htmlFor={`${uid}-delay`}>Delay (ms)</label>
                <span className="text-[0.6rem] font-mono" style={{ color: 'var(--color-accent)' }}>
                  {speedLabel}
                </span>
              </div>
              <input
                id={`${uid}-delay`}
                type="number" min={0} max={10000} step={50}
                className="field font-mono"
                value={delayMs}
                onChange={e => setDelayMs(e.target.value)}
              />
              <div className="flex gap-1 flex-wrap">
                {[['0', 'Burst'], ['100', '100ms'], ['500', '500ms'], ['1000', '1s']].map(([v, l]) => (
                  <button key={v} type="button"
                    onClick={() => setDelayMs(v)}
                    className="btn text-[0.6rem] px-2 py-0.5"
                    style={delayMs === v ? {
                      color: v === '0' ? 'var(--color-warn)' : 'var(--color-accent)',
                      borderColor: `color-mix(in oklab,${v === '0' ? 'var(--color-warn)' : 'var(--color-accent)'} 40%,transparent)`,
                      background: `color-mix(in oklab,${v === '0' ? 'var(--color-warn)' : 'var(--color-accent)'} 10%,transparent)`,
                    } : undefined}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Smart mode */}
          <button
            type="button"
            onClick={() => setSmartMode(p => !p)}
            className="flex items-center gap-2.5 rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-dim)] px-3 py-2.5 text-left transition-all"
            style={smartMode ? {
              borderColor: 'color-mix(in oklab,var(--color-good) 40%,transparent)',
              background: 'color-mix(in oklab,var(--color-good) 6%,transparent)',
            } : undefined}
          >
            <span className={smartMode ? 'text-[var(--color-good)]' : 'text-[var(--color-warn)]'}>
              {smartMode ? <IconShield size={17} /> : <IconBolt size={17} />}
            </span>
            <div className="flex-1">
              <p className="text-xs font-semibold">{smartMode ? 'Smart Mode ON' : 'Smart Mode OFF'}</p>
              <p className="text-[0.6rem] text-[var(--color-ink-faint)]">
                {smartMode
                  ? 'Jitter timing · invisible zero-width chars · anti-detect headers'
                  : 'Raw speed — no anti-detect protection'}
              </p>
            </div>
            <span
              className="size-4 rounded-full border-2 transition-colors shrink-0"
              style={{
                borderColor: smartMode ? 'var(--color-good)' : 'var(--color-edge)',
                background: smartMode ? 'var(--color-good)' : 'transparent',
              }}
            />
          </button>

          {/* Bot scope */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="label">Bots to use</span>
              <div className="flex gap-1.5">
                <button type="button" onClick={() => setBotScope('all')}
                  className="btn text-xs px-2.5 py-1"
                  style={botScope === 'all' ? {
                    color: 'var(--color-accent)',
                    borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                    background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
                  } : undefined}
                >
                  All ({online.length})
                </button>
                <button type="button" onClick={() => setBotScope('specific')}
                  className="btn text-xs px-2.5 py-1"
                  style={botScope === 'specific' ? {
                    color: 'var(--color-accent)',
                    borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                    background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
                  } : undefined}
                >
                  Pick
                </button>
              </div>
            </div>
            {botScope === 'specific' && (
              <div className="flex flex-wrap gap-1.5">
                {online.map(s => {
                  const sel = selBots.includes(s.id);
                  return (
                    <button key={s.id} type="button" onClick={() => toggleBot(s.id)}
                      className="btn text-xs px-2.5 py-1.5 flex items-center gap-1.5"
                      style={sel ? {
                        color: 'var(--color-accent)',
                        borderColor: 'color-mix(in oklab,var(--color-accent) 45%,transparent)',
                        background: 'color-mix(in oklab,var(--color-accent) 11%,transparent)',
                      } : undefined}
                    >
                      {s.avatarUrl && <img src={s.avatarUrl} alt="" className="size-3.5 rounded-full" />}
                      {s.username}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Progress */}
      {blasting && (
        <ProgressBar sent={sent} total={totalTarget} />
      )}

      {/* ── Actions */}
      {scanResult && (
        <div className="flex items-center gap-3">
          {blasting ? (
            <button
              type="button"
              onClick={handleKill}
              className="btn text-sm font-bold px-5 py-2.5 flex items-center gap-2"
              style={{
                color: 'var(--color-bad)',
                borderColor: 'color-mix(in oklab,var(--color-bad) 50%,transparent)',
                background: 'color-mix(in oklab,var(--color-bad) 12%,transparent)',
              }}
            >
              <IconStop size={14} /> Stop
            </button>
          ) : (
            <button
              type="button"
              disabled={!canBlast}
              onClick={handleBlast}
              className="btn btn-primary text-sm font-bold px-5 py-2.5 disabled:opacity-40 flex items-center gap-2"
            >
              <IconBomb size={14} /> Send ({totalTarget} msgs → {selChannels.size} channels)
            </button>
          )}

          {(done || logs.length > 0) && !blasting && (
            <button
              type="button"
              onClick={() => { setLogs([]); setDone(false); setSent(0); setErrors(0); }}
              className="btn text-xs"
            >
              Clear log
            </button>
          )}

          {blasting && (
            <span className="text-xs text-[var(--color-ink-faint)] font-mono">
              {sent}/{totalTarget} · {errors > 0 ? `${errors} err` : 'no errors'}
            </span>
          )}
        </div>
      )}

      {/* ── Live log */}
      <LiveLog lines={logs} />

    </section>
  );
}
