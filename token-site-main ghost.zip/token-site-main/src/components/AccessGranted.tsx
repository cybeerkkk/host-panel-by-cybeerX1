import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { IconCheck } from './Icons';
import {
  ACCESS_AUDIO_MS,
  ACCESS_ENVELOPE,
  ENVELOPE_STEP_MS,
  playAccessSound,
  stopAccessSound,
  unlockAccessSound,
} from '../lib/accessSound';

/*
 * Timings are cut to the audio in /public/access-granted.mp3 (6.58 s):
 *   0.00 – 0.55  silence, the panel settles in
 *   0.55 – 2.40  first voice   → "verifying" phase
 *   2.40 – 3.10  a beat of quiet
 *   3.10 – 6.40  second voice  → "granted" burst lands on the downbeat
 * If the file cannot play (autoplay blocked, decode failure) the same timers
 * still drive the visuals, so the sequence never stalls.
 */
/**
 * The second, louder voice enters at 3.10 s in the mix. The burst fires a
 * fraction before it so the reveal reads as leading the sound rather than
 * lagging behind it.
 */
const VERIFY_MS = 3050;
/**
 * The sequence always runs to the end — there is no skip. These timers are
 * only the fallback for when the audio never played (autoplay blocked, file
 * missing); when it does play, its own 'ended' event ends the sequence so the
 * last word is never cut off. Both are longer than the audio itself.
 */
const FALLBACK_TOTAL_MS = ACCESS_AUDIO_MS + 250;
/** Hard ceiling so onDone fires even if a timer is starved by a busy tab. */
const MAX_TOTAL_MS = ACCESS_AUDIO_MS + 2000;

function hexBlock(len: number) {
  const chars = '0123456789ABCDEF';
  let out = '';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

/* ── Glitch text scrambler ───────────────────────────────────────────── */

function ScrambleRow({
  label,
  value,
  delay,
  done,
}: {
  label: string;
  value: string;
  delay: number;
  done: boolean;
}) {
  const [display, setDisplay] = useState(() => hexBlock(value.length));
  const [settled, setSettled] = useState(false);

  useEffect(() => {
    let raf = 0;
    let frame = 0;
    const totalFrames = 18;
    const start = performance.now() + delay;

    const tick = (now: number) => {
      if (now < start) {
        raf = requestAnimationFrame(tick);
        return;
      }
      frame++;
      const settleFrom = Math.floor((frame / totalFrames) * value.length);
      let next = '';
      for (let i = 0; i < value.length; i++) {
        next += i < settleFrom ? value[i] : hexBlock(1);
      }
      setDisplay(next);
      if (frame < totalFrames) {
        raf = requestAnimationFrame(tick);
      } else {
        setDisplay(value);
        setSettled(true);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [delay, value]);

  return (
    <div className="ag-row">
      <span className="ag-row-label">{label}</span>
      <span className={`ag-row-value ${settled ? 'ag-row-value--ok' : ''}`}>{display}</span>
      {done && (
        <span className="ag-row-check">
          <IconCheck size={11} />
        </span>
      )}
    </div>
  );
}

/* ── Ghost face ──────────────────────────────────────────────────────── */

function GhostFace({ phase }: { phase: 'verifying' | 'granted' }) {
  const granted = phase === 'granted';
  return (
    <svg viewBox="0 0 60 70" width="36" height="42" fill="none" className="ag-ghost-svg">
      <path
        d="M5 30 Q5 5 30 5 Q55 5 55 30 L55 62 Q47 55 40 62 Q32 55 30 62 Q22 55 20 62 Q13 55 5 62 Z"
        fill={
          granted
            ? 'color-mix(in oklab,var(--color-good) 80%,white)'
            : 'color-mix(in oklab,var(--color-accent) 70%,white)'
        }
        className="ag-ghost-body"
      />
      <ellipse cx="21" cy="30" rx="5" ry={granted ? 3 : 6} fill="var(--color-void)" className="ag-ghost-eye" />
      <ellipse cx="39" cy="30" rx="5" ry={granted ? 3 : 6} fill="var(--color-void)" className="ag-ghost-eye" />
      {granted ? (
        <path
          d="M18 46 Q30 56 42 46"
          stroke="var(--color-void)"
          strokeWidth="2.5"
          strokeLinecap="round"
          fill="none"
          className="ag-ghost-mouth"
        />
      ) : (
        <ellipse cx="30" cy="46" rx="6" ry="4" fill="var(--color-void)" className="ag-ghost-mouth" />
      )}
    </svg>
  );
}

/* ── Floating particles ──────────────────────────────────────────────── */

function GhostParticles() {
  const particles = useMemo(
    () =>
      Array.from({ length: 20 }, (_, i) => {
        const angle = (i / 20) * Math.PI * 2 + Math.random() * 0.4;
        const dist = 85 + Math.random() * 55;
        return {
          id: i,
          px: Math.cos(angle) * dist,
          py: Math.sin(angle) * dist,
          delay: Math.random() * 150,
          size: 2 + Math.random() * 3,
          hue:
            i % 3 === 0
              ? 'var(--color-accent)'
              : i % 3 === 1
                ? 'var(--color-accent-2)'
                : 'var(--color-good)',
        };
      }),
    [],
  );

  return (
    <div className="ag-particles" aria-hidden="true">
      {particles.map((p) => (
        <span
          key={p.id}
          className="ag-particle"
          style={
            {
              '--px': `${p.px}px`,
              '--py': `${p.py}px`,
              width: p.size,
              height: p.size,
              background: p.hue,
              animationDelay: `${p.delay}ms`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

/* ── Live level meter, driven by the audio itself ────────────────────── */

function LevelBars({ level }: { level: number }) {
  const bars = 28;
  return (
    <div className="ag-levels" aria-hidden="true">
      {Array.from({ length: bars }, (_, i) => {
        // Centre bars react hardest, edges stay calmer — reads as a voice.
        const weight = 1 - Math.abs(i - (bars - 1) / 2) / ((bars - 1) / 2);
        const h = 3 + level * (6 + weight * 26);
        return <span key={i} className="ag-level" style={{ height: `${h}px` }} />;
      })}
    </div>
  );
}

/* ── Main component ──────────────────────────────────────────────────── */

export function AccessGranted({
  onDone,
  needsGesture = false,
}: {
  onDone: () => void;
  /**
   * Set for the ?key= link path. There was no click anywhere in that flow, so
   * every browser blocks audio outright — a one-tap prompt is the only way the
   * voice can be heard. It starts the sequence; it cannot skip it.
   */
  needsGesture?: boolean;
}) {
  const [armed, setArmed] = useState(!needsGesture);
  const [percent, setPercent] = useState(0);
  const [phase, setPhase] = useState<'verifying' | 'granted'>('verifying');
  const [eyeFlicker, setEyeFlicker] = useState(false);
  const [level, setLevel] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const doneRef = useRef(false);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  const tokens = useMemo(
    () => ({
      sig: hexBlock(12),
      clearance: hexBlock(8),
      session: hexBlock(16),
    }),
    [],
  );

  const STEPS = useMemo(
    () => [
      { at: 0, label: 'Waking the ghost…' },
      { at: 20, label: 'Channeling spirit…' },
      { at: 52, label: 'Binding soul to key…' },
      { at: 85, label: 'Opening the veil…' },
    ],
    [],
  );

  /** Ends the sequence exactly once, whichever timer gets there first. */
  const finish = useRef(() => {
    if (doneRef.current) return;
    doneRef.current = true;
    stopAccessSound();
    onDoneRef.current();
  }).current;

  useEffect(() => {
    if (!armed) return;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) {
      setPercent(100);
      setPhase('granted');
      const t = setTimeout(finish, 400);
      return () => clearTimeout(t);
    }

    const timers: ReturnType<typeof setTimeout>[] = [];

    // ---- audio -------------------------------------------------------
    // Plays straight to the default output. Nothing is routed through an
    // AudioContext: doing that pulled the element into a suspended graph and
    // silenced it outright, which is why the voice could not be heard.
    let audioEnded = false;
    const onEnded = () => {
      audioEnded = true;
      finish();
    };

    void playAccessSound().then((el) => {
      if (doneRef.current) {
        // Unmounted while the play promise was in flight.
        stopAccessSound();
        return;
      }
      if (el) {
        audioRef.current = el;
        el.addEventListener('ended', onEnded);
      }
    });

    /**
     * Level comes from the envelope baked off the real mix, indexed by the
     * element's own playback position so picture and sound cannot drift. With
     * no audio, elapsed time indexes the same curve, so the meter still moves
     * in the shape of the voice.
     */
    const readLevel = (elapsedMs: number) => {
      const el = audioRef.current;
      const positionMs =
        el && !el.paused && Number.isFinite(el.currentTime) ? el.currentTime * 1000 : elapsedMs;
      const index = Math.floor(positionMs / ENVELOPE_STEP_MS);
      const value = ACCESS_ENVELOPE[index] ?? 0;
      // Small floor so the meter idles rather than flatlining during silence.
      setLevel(Math.max(0.04, value));
    };

    // ---- flicker beats ----------------------------------------------
    timers.push(
      setTimeout(() => {
        setEyeFlicker(true);
        timers.push(setTimeout(() => setEyeFlicker(false), 120));
        timers.push(
          setTimeout(() => {
            setEyeFlicker(true);
            timers.push(setTimeout(() => setEyeFlicker(false), 80));
          }, 220),
        );
      }, VERIFY_MS * 0.6),
    );

    // ---- progress + level loop ---------------------------------------
    let raf = 0;
    const start = performance.now();

    const levelOnly = (now: number) => {
      readLevel(now - start);
      raf = requestAnimationFrame(levelOnly);
    };

    const tick = (now: number) => {
      const elapsed = now - start;
      const t = Math.min(1, elapsed / VERIFY_MS);
      setPercent(Math.round(easeOutCubic(t) * 100));
      readLevel(elapsed);

      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        setPhase('granted');
        raf = requestAnimationFrame(levelOnly);
      }
    };

    raf = requestAnimationFrame(tick);

    // ---- exit --------------------------------------------------------
    // The audio's own 'ended' event is preferred so the sequence lasts exactly
    // as long as the voice. The timers below only take over if it never
    // started, and both sit past the end of the file.
    timers.push(
      setTimeout(() => {
        if (!audioEnded) finish();
      }, FALLBACK_TOTAL_MS),
    );
    timers.push(setTimeout(finish, MAX_TOTAL_MS));

    return () => {
      cancelAnimationFrame(raf);
      timers.forEach(clearTimeout);
      audioRef.current?.removeEventListener('ended', onEnded);
      stopAccessSound();
    };
  }, [armed, finish]);

  const granted = phase === 'granted';
  const stepLabel = [...STEPS].reverse().find((s) => percent >= s.at)?.label ?? STEPS[0].label;
  const circumference = 2 * Math.PI * 100;
  const dashoffset = circumference * (1 - percent / 100);

  if (!armed) {
    return (
      <div className="ag-overlay">
        <div className="ag-panel ag-gate animate-rise">
          <GhostFace phase="verifying" />
          <p className="ag-gate-title">Key accepted</p>
          <p className="ag-gate-sub">Tap to open the veil</p>
          <button
            type="button"
            className="btn btn-primary ag-gate-btn"
            onClick={() => {
              unlockAccessSound();
              setArmed(true);
            }}
          >
            Enter
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="ag-overlay" role="status" aria-live="polite">
      <div className="ag-panel animate-rise">
        <div className="ag-stage">
          {granted && (
            <div className="ag-ripples" aria-hidden="true">
              {[0, 110, 220, 330].map((d) => (
                <span key={d} className="ag-ripple" style={{ animationDelay: `${d}ms` }} />
              ))}
            </div>
          )}

          <div className="ag-orbit ag-orbit--1"><span className="ag-orbit-dot" /></div>
          <div className="ag-orbit ag-orbit--2"><span className="ag-orbit-dot ag-orbit-dot--alt" /></div>
          <div className="ag-orbit ag-orbit--3"><span className="ag-orbit-dot" /></div>

          <svg className="ag-progress" viewBox="0 0 220 220" aria-hidden="true">
            <defs>
              <linearGradient id="ag-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="var(--color-accent)" />
                <stop offset="100%" stopColor="var(--color-accent-2)" />
              </linearGradient>
            </defs>
            <circle className="ag-progress-track" cx="110" cy="110" r="100" />
            <circle
              className="ag-progress-bar"
              cx="110"
              cy="110"
              r="100"
              strokeDasharray={circumference}
              strokeDashoffset={granted ? 0 : dashoffset}
            />
          </svg>

          <div
            className={`ag-core ${granted ? 'ag-core--granted' : ''} ${eyeFlicker ? 'ag-core--flicker' : ''}`}
            // The core breathes with the audio level.
            style={{ '--ag-level': level.toFixed(3) } as CSSProperties}
          >
            <div className="ag-core-glow" />
            {!granted && (
              <div className="ag-scan-mask">
                <span className="ag-scan-line" />
              </div>
            )}
            <div className="ag-icon" key={phase}>
              <GhostFace phase={granted ? 'granted' : 'verifying'} />
            </div>
          </div>

          {granted && <GhostParticles />}
        </div>

        <div className="ag-percent">{granted ? '100%' : `${percent}%`}</div>

        <LevelBars level={level} />

        <div className="ag-status">
          {granted ? (
            <div className="ag-granted-text" data-text="GHOST AWAKENED">
              GHOST AWAKENED
            </div>
          ) : (
            <div className="ag-step">{stepLabel}</div>
          )}
        </div>

        <div className="ag-rows">
          <ScrambleRow label="Ghost Signature" value={tokens.sig} delay={100} done={granted} />
          <ScrambleRow label="Soul Clearance" value={tokens.clearance} delay={380} done={granted} />
          <ScrambleRow label="Veil Token" value={tokens.session} delay={700} done={granted} />
        </div>
      </div>
    </div>
  );
}
