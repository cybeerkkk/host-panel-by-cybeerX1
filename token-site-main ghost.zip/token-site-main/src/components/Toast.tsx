import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { IconAlert, IconCheck } from './Icons';

type ToastKind = 'ok' | 'bad';

interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

interface ToastApi {
  ok: (message: string) => void;
  bad: (message: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

/** Replaces the blocking alert() calls the old build used for every result. */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((kind: ToastKind, message: string) => {
    const id = Date.now() + Math.random();
    setToasts((current) => [...current.slice(-3), { id, kind, message }]);
    setTimeout(() => {
      setToasts((current) => current.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const value = useMemo<ToastApi>(
    () => ({
      ok: (message) => push('ok', message),
      bad: (message) => push('bad', message),
    }),
    [push],
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        className="pointer-events-none fixed bottom-5 left-1/2 z-50 flex w-[min(92vw,26rem)] -translate-x-1/2 flex-col gap-2"
        role="status"
        aria-live="polite"
      >
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="animate-rise panel pointer-events-auto flex items-center gap-3 px-4 py-3 text-sm shadow-2xl"
            style={{
              borderColor:
                toast.kind === 'ok'
                  ? 'color-mix(in oklab, var(--color-good) 45%, transparent)'
                  : 'color-mix(in oklab, var(--color-bad) 45%, transparent)',
            }}
          >
            <span
              className="flex size-6 shrink-0 items-center justify-center rounded-full"
              style={{
                background:
                  toast.kind === 'ok'
                    ? 'color-mix(in oklab, var(--color-good) 18%, transparent)'
                    : 'color-mix(in oklab, var(--color-bad) 18%, transparent)',
                color: toast.kind === 'ok' ? 'var(--color-good)' : 'var(--color-bad)',
              }}
            >
              {toast.kind === 'ok' ? <IconCheck size={14} /> : <IconAlert size={14} />}
            </span>
            <span className="text-[var(--color-ink)]">{toast.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside ToastProvider');
  return ctx;
}
