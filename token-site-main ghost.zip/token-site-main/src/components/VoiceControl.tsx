import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { AppConfig, BotSession, KeyPermissions, UserRole } from '@shared/types';
import {
  IconExit,
  IconMic,
  IconMicOff,
  IconPulse,
  IconSave,
  IconSpeaker,
  IconSpeakerOff,
} from './Icons';

interface Props {
  config: AppConfig;
  sessions: BotSession[];
  selectedCount: number;
  totalOnline: number;
  busy: boolean;
  role?: UserRole;
  permissions?: KeyPermissions;
  staggerMs?: number;
  onJoin: (guildId: string, channelId: string, selfMute: boolean, selfDeaf: boolean, ids?: string[]) => void;
  onJoinOne?: (guildId: string, channelId: string, selfMute: boolean, selfDeaf: boolean, id: string) => Promise<void>;
  onLeave: (guildId?: string, ids?: string[]) => void;
  onSave: (patch: Partial<AppConfig>) => void;
}

function Toggle({ active, disabled, onClick, onIcon, offIcon, label }: {
  active: boolean; disabled?: boolean; onClick: () => void;
  onIcon: ReactNode; offIcon: ReactNode; label: string;
}) {
  return (
    <button type="button" onClick={onClick} disabled={disabled} aria-pressed={active}
      className="btn px-3 py-2 text-xs disabled:opacity-50"
      style={active ? {
        color: 'var(--color-warn)',
        borderColor: 'color-mix(in oklab, var(--color-warn) 38%, transparent)',
        background: 'color-mix(in oklab, var(--color-warn) 10%, transparent)',
      } : undefined}
    >
      {active ? onIcon : offIcon}{label}
    </button>
  );
}

/** Groups active voice slots by guildId across all sessions */
function groupByGuild(sessions: BotSession[]): Map<string, { guildId: string; guildName: string | null; count: number }> {
  const map = new Map<string, { guildId: string; guildName: string | null; count: number }>();
  for (const s of sessions) {
    for (const slot of s.voiceSlots ?? []) {
      const existing = map.get(slot.guildId);
      if (existing) existing.count++;
      else map.set(slot.guildId, { guildId: slot.guildId, guildName: slot.guildName, count: 1 });
    }
  }
  return map;
}

export function VoiceControl({
  config, sessions, selectedCount, totalOnline, busy, role = 'owner',
  permissions, staggerMs = 650, onJoin, onJoinOne, onLeave, onSave,
}: Props) {
  const [guildId, setGuildId] = useState(config.defaultGuildId ?? '');
  const [channelId, setChannelId] = useState(config.defaultChannelId ?? '');
  const [selfMute, setSelfMute] = useState(config.selfMute ?? false);
  const [selfDeaf, setSelfDeaf] = useState(config.selfDeaf ?? false);
  const [touched, setTouched] = useState(false);

  // 1-by-1 drip state
  const [dripActive, setDripActive] = useState(false);
  const [dripIdx, setDripIdx] = useState(0);
  const dripRef = useRef<NodeJS.Timeout | null>(null);
  const dripCancelRef = useRef(false);

  useEffect(() => {
    if (touched) return;
    setGuildId(config.defaultGuildId ?? '');
    setChannelId(config.defaultChannelId ?? '');
    setSelfMute(config.selfMute ?? false);
    setSelfDeaf(config.selfDeaf ?? false);
  }, [config, touched]);

  // Cleanup drip timer on unmount
  useEffect(() => () => {
    dripCancelRef.current = true;
    if (dripRef.current) clearTimeout(dripRef.current);
  }, []);

  const snowflake = (v: string) => /^\d{17,20}$/.test(v.trim());
  const guildOk = snowflake(guildId);
  const channelOk = snowflake(channelId);

  const canJoinPerm  = role === 'owner' || permissions?.canJoinVoice  !== false;
  const canLeavePerm = role === 'owner' || permissions?.canLeaveVoice !== false;
  const canMuteDeafPerm = role === 'owner' || permissions?.canMuteDeaf !== false;
  const canSend = !busy && !dripActive && guildOk && channelOk && totalOnline > 0 && canJoinPerm;

  const onlineSessions = sessions.filter((s) => s.status === 'online');

  const target = selectedCount > 0
    ? `${selectedCount} selected`
    : totalOnline > 0 ? `all ${totalOnline} online` : 'none online';

  const dirty =
    guildId !== (config.defaultGuildId ?? '') ||
    channelId !== (config.defaultChannelId ?? '') ||
    selfMute !== (config.selfMute ?? false) ||
    selfDeaf !== (config.selfDeaf ?? false);

  // Active guild groups
  const guildGroups = groupByGuild(sessions);

  /* ── 1-by-1 drip join ─────────────────────────────── */
  const startDrip = async () => {
    if (!canSend || onlineSessions.length === 0) return;
    const queue = selectedCount > 0
      ? sessions.filter((s) => s.status === 'online')
      : onlineSessions;
    if (queue.length === 0) return;

    setDripActive(true);

    for (let i = 0; i < queue.length; i++) {
      if (dripCancelRef.current) break;
      setDripIdx(i + 1);
      // await the actual join, then wait staggerMs before the next
      if (onJoinOne) {
        await onJoinOne(guildId, channelId, selfMute, selfDeaf, queue[i].id);
      } else {
        onJoin(guildId, channelId, selfMute, selfDeaf, [queue[i].id]);
      }
      await new Promise<void>((resolve) => {
        dripRef.current = setTimeout(resolve, staggerMs);
      });
    }

    setDripActive(false);
    setDripIdx(0);
    dripCancelRef.current = false;
  };

  const cancelDrip = () => {
    dripCancelRef.current = true;
    if (dripRef.current) { clearTimeout(dripRef.current); dripRef.current = null; }
    setDripActive(false);
    setDripIdx(0);
  };

  return (
    <section className="animate-rise panel flex flex-col gap-4 p-5 sm:p-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex size-7 items-center justify-center rounded-lg bg-[var(--color-accent)]/15 text-[var(--color-accent)]">
            <IconPulse size={15} />
          </span>
          <h2 className="text-sm font-bold tracking-tight">Voice Channel Dispatcher</h2>
        </div>
        {dirty && (
          <button onClick={() => { onSave({ defaultGuildId: guildId, defaultChannelId: channelId, selfMute, selfDeaf }); setTouched(false); }}
            className="btn text-xs font-semibold"
            style={{ color: 'var(--color-accent)', borderColor: 'var(--color-accent)' }}
          >
            <IconSave size={13} />Save as default
          </button>
        )}
      </div>

      {/* IDs */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="label" htmlFor="guild-id">Server ID</label>
          <input id="guild-id" className="field" type="text" inputMode="numeric"
            placeholder="000000000000000000" value={guildId}
            onChange={(e) => { setTouched(true); setGuildId(e.target.value.trim()); }}
            style={guildOk || !guildId ? undefined : { borderColor: 'color-mix(in oklab, var(--color-bad) 55%, transparent)' }}
          />
          {!guildOk && guildId && <span className="text-[0.6875rem] text-[var(--color-bad)]">A Discord ID is 17-20 digits</span>}
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="label" htmlFor="channel-id">Voice Channel ID</label>
          <input id="channel-id" className="field" type="text" inputMode="numeric"
            placeholder="000000000000000000" value={channelId}
            onChange={(e) => { setTouched(true); setChannelId(e.target.value.trim()); }}
            style={channelOk || !channelId ? undefined : { borderColor: 'color-mix(in oklab, var(--color-bad) 55%, transparent)' }}
          />
          {!channelOk && channelId && <span className="text-[0.6875rem] text-[var(--color-bad)]">A Discord ID is 17-20 digits</span>}
        </div>
      </div>

      {/* Mute/Deafen + Join/Leave actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--color-edge)] pt-4">
        <div className="flex items-center gap-2">
          <Toggle active={selfMute} disabled={!canMuteDeafPerm}
            onClick={() => { setTouched(true); setSelfMute((v) => !v); }}
            onIcon={<IconMicOff size={14} />} offIcon={<IconMic size={14} />} label="Mute"
          />
          <Toggle active={selfDeaf} disabled={!canMuteDeafPerm}
            onClick={() => { setTouched(true); setSelfDeaf((v) => !v); }}
            onIcon={<IconSpeakerOff size={14} />} offIcon={<IconSpeaker size={14} />} label="Deafen"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* All at once */}
          <button onClick={() => onJoin(guildId, channelId, selfMute, selfDeaf)}
            disabled={!canSend}
            className="btn btn-primary disabled:opacity-50"
            title={!canJoinPerm ? 'Your key does not permit joining voice' : `Send ${target} at once`}
          >
            <IconSpeaker size={15} />
            Join · {target}
          </button>

          {/* 1 by 1 drip */}
          {dripActive ? (
            <button onClick={cancelDrip}
              className="btn text-xs"
              style={{ color: 'var(--color-warn)', borderColor: 'color-mix(in oklab,var(--color-warn) 40%,transparent)', background: 'color-mix(in oklab,var(--color-warn) 8%,transparent)' }}
            >
              <span className="relative flex size-2 shrink-0">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-warn)] opacity-60" />
                <span className="relative inline-flex size-2 rounded-full bg-[var(--color-warn)]" />
              </span>
              {dripIdx}/{onlineSessions.length} · Cancel
            </button>
          ) : (
            <button onClick={startDrip}
              disabled={!canSend}
              className="btn disabled:opacity-50 text-xs"
              title="Send bots one-by-one with a stagger delay"
            >
              <span className="flex flex-col gap-[2px]">
                <span className="block h-[2px] w-3 rounded-full bg-current" />
                <span className="block h-[2px] w-2 rounded-full bg-current" />
                <span className="block h-[2px] w-1 rounded-full bg-current" />
              </span>
              1 by 1
            </button>
          )}

          {/* Leave all */}
          <button onClick={() => onLeave()}
            disabled={busy || !canLeavePerm}
            className="btn btn-danger disabled:opacity-50"
            title={!canLeavePerm ? 'Your key does not permit leaving voice' : 'Pull all out of every voice channel'}
          >
            <IconExit size={15} />Leave all
          </button>
        </div>
      </div>

      {/* Active Guild Strips — leave per-server */}
      {guildGroups.size > 0 && canLeavePerm && (
        <div className="flex flex-col gap-1.5 border-t border-[var(--color-edge)] pt-3">
          <p className="text-[0.6875rem] font-semibold uppercase tracking-widest text-[var(--color-ink-faint)]">
            Active Servers
          </p>
          <div className="flex flex-wrap gap-2">
            {[...guildGroups.values()].map((g) => (
              <button
                key={g.guildId}
                onClick={() => onLeave(g.guildId)}
                disabled={busy}
                className="flex items-center gap-2 rounded-lg border border-[var(--color-good)]/20 bg-[var(--color-good)]/8 px-3 py-1.5 text-xs font-medium text-[var(--color-good)] transition-colors hover:border-[var(--color-bad)]/40 hover:bg-[var(--color-bad)]/10 hover:text-[var(--color-bad)] disabled:opacity-50"
                title={`Pull all bots out of ${g.guildName ?? g.guildId}`}
              >
                <span className="relative flex size-1.5 shrink-0">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-[var(--color-good)] opacity-50" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-[var(--color-good)]" />
                </span>
                <span className="max-w-[120px] truncate">{g.guildName ?? g.guildId}</span>
                <span className="rounded bg-[var(--color-good)]/15 px-1 font-mono text-[0.625rem]">{g.count}</span>
                <svg width="8" height="8" viewBox="0 0 10 10" fill="none" className="shrink-0 opacity-60">
                  <path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
                </svg>
              </button>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
