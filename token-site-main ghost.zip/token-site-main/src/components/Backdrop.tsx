import { useEffect, useRef } from 'react';

interface Node {
  x: number;
  y: number;
  z: number;
}

const FOV = 2.4;
const rnd = (min: number, max: number) => min + Math.random() * (max - min);

/**
 * A slowly rotating 3D network of points that leans toward the pointer.
 * Plain canvas, no libraries. It stops while the page is hidden, caps its frame
 * rate on phones, and is not drawn at all with prefers-reduced-motion.
 */
export function Backdrop() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (reduce.matches) return;

    const small = window.innerWidth < 700;
    const nodes: Node[] = Array.from({ length: small ? 36 : 68 }, () => ({
      x: rnd(-1, 1),
      y: rnd(-1, 1),
      z: rnd(-1, 1),
    }));
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const minFrameMs = small ? 40 : 16;

    let w = 0;
    let h = 0;
    let raf = 0;
    let last = 0;
    let spin = 0;
    let aimX = 0;
    let aimY = 0;
    let lookX = 0;
    let lookY = 0;

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const onPointer = (e: PointerEvent) => {
      aimX = (e.clientX / w - 0.5) * 2;
      aimY = (e.clientY / h - 0.5) * 2;
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (now - last < minFrameMs) return;
      last = now;

      spin += 0.0016;
      lookX += (aimX - lookX) * 0.04;
      lookY += (aimY - lookY) * 0.04;

      const yaw = spin + lookX * 0.35;
      const pitch = lookY * 0.2;
      const cy = Math.cos(yaw);
      const sy = Math.sin(yaw);
      const cp = Math.cos(pitch);
      const sp = Math.sin(pitch);
      const spreadX = w * 0.62;
      const spreadY = h * 0.62;

      ctx.clearRect(0, 0, w, h);

      const pts = nodes.map((n) => {
        const x1 = n.x * cy - n.z * sy;
        const z1 = n.x * sy + n.z * cy;
        const y2 = n.y * cp - z1 * sp;
        const z2 = n.y * sp + z1 * cp;
        const k = FOV / (FOV + z2);
        return { sx: w / 2 + x1 * spreadX * k, sy: h / 2 + y2 * spreadY * k, k };
      });

      const reach = Math.min(w, h) * (small ? 0.22 : 0.17);
      for (let i = 0; i < pts.length; i += 1) {
        const a = pts[i];
        for (let j = i + 1; j < pts.length; j += 1) {
          const b = pts[j];
          const d = Math.hypot(a.sx - b.sx, a.sy - b.sy);
          if (d > reach) continue;
          const alpha = (1 - d / reach) * 0.22 * Math.min(a.k, b.k);
          ctx.strokeStyle = `rgba(34, 211, 238, ${alpha.toFixed(3)})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(a.sx, a.sy);
          ctx.lineTo(b.sx, b.sy);
          ctx.stroke();
        }
      }

      for (const p of pts) {
        const r = 1 + p.k * 1.3;
        ctx.fillStyle = p.k > 1 ? 'rgba(139, 92, 246, 0.75)' : 'rgba(34, 211, 238, 0.6)';
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, r, 0, Math.PI * 2);
        ctx.fill();
      }
    };

    const start = () => {
      if (!raf) raf = requestAnimationFrame(frame);
    };
    const stop = () => {
      cancelAnimationFrame(raf);
      raf = 0;
    };
    const onVisibility = () => (document.visibilityState === 'hidden' ? stop() : start());
    const onMotionChange = () => {
      if (reduce.matches) {
        stop();
        ctx.clearRect(0, 0, w, h);
      } else {
        start();
      }
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', onPointer, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    reduce.addEventListener('change', onMotionChange);
    start();

    return () => {
      stop();
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onPointer);
      document.removeEventListener('visibilitychange', onVisibility);
      reduce.removeEventListener('change', onMotionChange);
    };
  }, []);

  return <canvas ref={ref} className="backdrop-canvas" aria-hidden="true" />;
}
