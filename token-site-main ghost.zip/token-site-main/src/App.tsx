import { lazy, Suspense, useCallback, useEffect, useMemo, useState, type CSSProperties } from 'react';
import type { AppConfig, AuthSessionInfo, BotSession } from '@shared/types';
import { api, ApiError } from './lib/api';
import { useLiveData } from './lib/useLiveData';
import { clearSaved, usePersistedState, useScrollMemory } from './lib/usePersistedState';
import { Console } from './components/Console';
import { Header } from './components/Header';
import { ImportPanel } from './components/ImportPanel';
import { AccessGranted } from './components/AccessGranted';
import { Login } from './components/Login';
import { SessionCard } from './components/SessionCard';
import { VoiceControl } from './components/VoiceControl';
import { useToast } from './components/Toast';
import { ErrorBoundary } from './components/ErrorBoundary';

const AutoReact = lazy(() => import('./components/AutoReact').then((m) => ({ default: m.AutoReact })));
const MessageSpammer = lazy(() => import('./components/MessageSpammer').then((m) => ({ default: m.MessageSpammer })));
const GuildBlast = lazy(() => import('./components/GuildBlast').then((m) => ({ default: m.GuildBlast })));
const OwnerPanel = lazy(() => import('./components/OwnerPanel').then((m) => ({ default: m.OwnerPanel })));
const Radar = lazy(() => import('./components/Radar').then((m) => ({ default: m.Radar })));
const Monitor = lazy(() => import('./components/Monitor').then((m) => ({ default: m.Monitor })));

function PanelLoading() {
  return (
    <div className="flex items-center justify-center p-16">
      <IconRefresh size={20} className="animate-spin-slow text-[var(--color-ink-faint)]" />
    </div>
  );
}
import {
  IconCheckSquare,
  IconBomb,
  IconHome,
  IconLock,
  IconMessage,
  IconMonitor,
  IconRadar,
  IconRefresh,
  IconSquare,
  IconUsers,
  IconWave,
} from './components/Icons';

type Tab = 'voice' | 'radar' | 'auto-react' | 'spammer' | 'blast' | 'monitor';
/** 'granting' plays the access sequence after a URL key has been accepted. */
type AuthState = 'checking' | 'granting' | 'in' | 'out';

const DEFAULT_CONFIG: AppConfig = {
  defaultGuildId: '',
  defaultChannelId: '',
  autoFollowTargetId: '',
  autoFollowEnabled: false,
  globalAntiLeave: true,
  selfMute: false,
  selfDeaf: false,
  globalAntiMove: false,
  globalAntiHost: false,
};

function EmptySessions({ isRestricted }: { isRestricted?: boolean }) {
  return (
    <div className="panel flex flex-col items-center gap-3 p-12 text-center">
      <span className="text-[var(--color-edge-bright)]">
        <IconUsers size={44} />
      </span>
      <p className="text-sm font-semibold text-[var(--color-ink-dim)]">
        {isRestricted ? 'No assigned accounts available' : 'No accounts connected'}
      </p>
      <p className="max-w-xs text-xs text-[var(--color-ink-faint)]">
        {isRestricted
          ? 'Your access key has no online bots assigned currently. Contact the administrator to assign bots.'
          : 'Paste one or more tokens in the import panel to bring accounts online.'}
      </p>
    </div>
  );
}

export default function App() {
  const [auth, setAuth] = useState<AuthState>('checking');
  const [role, setRole] = useState<'owner' | 'user'>('user');
  const [keyInfo, setKeyInfo] = useState<AuthSessionInfo['keyInfo']>(undefined);
  const [showOwnerPanel, setShowOwnerPanel] = useState(false);
  // Remembered across refreshes, closed tabs and phone browsers discarding the page.
  const [tab, setTab] = usePersistedState<Tab>('tab', 'voice');
  const [selected, setSelected] = usePersistedState<string[]>('selected', []);
  const [busy, setBusy] = useState(false);

  const toast = useToast();
  const { snapshot, logs, connection, refresh } = useLiveData(auth === 'in');
  useScrollMemory(`tab:${tab}`, auth === 'in');

  const checkAuth = useCallback(async () => {
    // 1. Try existing session cookie
    try {
      const res = await api.session();
      if (res.authenticated) {
        setAuth('in');
        setRole(res.role ?? 'user');
        setKeyInfo(res.keyInfo);
        return;
      }
    } catch { /* fall through */ }

    // 2. Silent auto-login from ?key= / ?token= / ?k= in URL
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlKey = params.get('key') ?? params.get('token') ?? params.get('k');
      if (urlKey) {
        try {
          const res = await api.login({ key: urlKey.trim().toUpperCase() });
          if (res.ok) {
            // Strip key from URL so it doesn't stay visible in browser history
            const clean = new URL(window.location.href);
            ['key', 'token', 'k'].forEach((p) => clean.searchParams.delete(p));
            window.history.replaceState({}, '', clean.toString());
            setRole(res.role ?? 'user');
            setKeyInfo(res.keyInfo);
            // Show the same access sequence a typed key gets, then go in.
            setAuth('granting');
            return;
          }
        } catch { /* invalid key — fall through to login screen */ }
      }
    }

    setAuth('out');
  }, []);


  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  // Real-time server revocation listener
  useEffect(() => {
    const handleRevocation = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail;
      toast.bad(detail || 'Your session has been terminated by the administrator.');
      setAuth('out');
      setShowOwnerPanel(false);
    };

    window.addEventListener('gvc-auth-revoked', handleRevocation);
    return () => {
      window.removeEventListener('gvc-auth-revoked', handleRevocation);
    };
  }, [toast]);

  const sessions = useMemo(() => snapshot?.sessions ?? [], [snapshot]);
  const config = snapshot?.config ?? DEFAULT_CONFIG;

  const permissions = keyInfo?.permissions;

  // Drop selections whose session no longer exists (not before the first snapshot,
  // or a remembered selection would be wiped while the list is still empty)
  useEffect(() => {
    if (!snapshot) return;
    const live = new Set(sessions.map((s) => s.id));
    setSelected((current) => {
      const next = current.filter((id) => live.has(id));
      return next.length === current.length ? current : next;
    });
  }, [snapshot, sessions]);

  /** Any 401 means the session or key expired: fall back to login screen */
  const run = useCallback(
    async (action: () => Promise<void>) => {
      setBusy(true);
      try {
        await action();
      } catch (err) {
        if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
          toast.bad(err.message);
          if (err.status === 401) {
            setAuth('out');
            return;
          }
        } else {
          toast.bad(err instanceof Error ? err.message : 'Something went wrong');
        }
      } finally {
        setBusy(false);
        refresh();
      }
    },
    [refresh, toast],
  );

  const toggleSelect = useCallback((id: string) => {
    setSelected((current) =>
      current.includes(id) ? current.filter((x) => x !== id) : [...current, id],
    );
  }, []);

  const allSelected = sessions.length > 0 && selected.length === sessions.length;

  const handleImport = (tokens: string) =>
    run(async () => {
      const result = await api.addTokens(tokens);
      if (result.message) {
        toast.ok(result.message);
      } else if (result.added > 0) {
        toast.ok(
          `Connected ${result.added} account${result.added === 1 ? '' : 's'}` +
            (result.failed > 0 ? ` · ${result.failed} failed` : ''),
        );
      } else {
        toast.bad(
          `No account connected · ${result.failed} failed` +
            (result.reasons?.length ? ` - ${result.reasons[0]}` : ''),
        );
      }
    });

  const handleJoin = (guildId: string, channelId: string, selfMute: boolean, selfDeaf: boolean, ids?: string[]) =>
    void run(async () => {
      const effectiveIds = ids ?? (selected.length > 0 ? selected : undefined);
      const result = await api.join({ ids: effectiveIds, guildId, channelId, selfMute, selfDeaf });
      toast.ok(`Sent ${result.sent} account${result.sent === 1 ? '' : 's'} to voice`);
    });

  /** Lightweight single-bot join for 1-by-1 drip — no busy lock, returns a promise */
  const handleJoinOne = async (guildId: string, channelId: string, selfMute: boolean, selfDeaf: boolean, id: string): Promise<void> => {
    try {
      await api.join({ ids: [id], guildId, channelId, selfMute, selfDeaf });
    } catch (err) {
      toast.bad(err instanceof Error ? err.message : 'Join failed');
    }
  };

  const handleLeave = (guildId?: string, ids?: string[]) =>
    void run(async () => {
      const effectiveIds = ids ?? (selected.length > 0 ? selected : undefined);
      const result = guildId
        ? await api.leaveGuild(effectiveIds ?? sessions.filter(s => s.status === 'online').map(s => s.id), guildId)
        : await api.leave(effectiveIds);
      toast.ok(`Pulled ${result.sent} account${result.sent === 1 ? '' : 's'} out`);
    });

  const handleSaveConfig = (patch: Partial<AppConfig>) =>
    void run(async () => {
      await api.patchConfig(patch);
      toast.ok('Settings saved');
    });

  const handleRemove = (session: BotSession) =>
    void run(async () => {
      await api.removeSession(session.id);
      toast.ok(`Removed ${session.username}`);
    });

  const handleRemoveAll = () =>
    void run(async () => {
      const result = await api.removeAll();
      setSelected([]);
      toast.ok(`Removed ${result.removed} account${result.removed === 1 ? '' : 's'}`);
    });

  const handleReconnect = (session: BotSession) =>
    void run(async () => {
      await api.reconnect(session.id);
      toast.ok(`${session.username} reconnected`);
    });

  const handleReplaceToken = (session: BotSession, token: string) =>
    run(async () => {
      const updated = await api.replaceToken(session.id, token);
      toast.ok(`Token updated for ${updated.username}`);
    });

  const handleToggleFlag = (session: BotSession, flag: 'antiLeave' | 'autoFollow') =>
    void run(async () => {
      await api.patchSession(session.id, { [flag]: !session[flag] });
    });

  const handleSetVoiceState = (
    session: BotSession,
    patch: { selfMute?: boolean; selfDeaf?: boolean },
    guildId: string,
  ) => {
    void api.setVoiceState(session.id, patch, guildId).catch((err) => {
      toast.bad(err instanceof Error ? err.message : 'Could not update voice state');
    });
  };

  // Acts on the one card the button belongs to. It used to fall back to the
  // whole selection, so clicking "leave" on a single account yanked every
  // selected account out of that server too.
  const handleLeaveGuild = (session: BotSession, guildId: string) => {
    void api.leaveGuild([session.id], guildId).catch((err) => {
      toast.bad(err instanceof Error ? err.message : 'Could not leave guild');
    });
  };

  const handleLogout = () =>
    void run(async () => {
      await api.logout();
      clearSaved();
      setAuth('out');
      setRole('user');
      setKeyInfo(undefined);
    });

  if (auth === 'checking') {
    // Minimal spinner while silently attempting URL-key / cookie auth — no flash of login screen
    return (
      <main className="flex min-h-dvh items-center justify-center">
        <IconRefresh size={22} className="animate-spin-slow text-[var(--color-ink-faint)] opacity-30" />
      </main>
    );
  }

  if (auth === 'granting') {
    // Redeemed straight from a ?key= link, so nothing was ever clicked.
    return <AccessGranted needsGesture onDone={() => setAuth('in')} />;
  }

  if (auth === 'out') {
    return <Login onSuccess={checkAuth} />;
  }

  const followerCount = sessions.filter((s) => s.autoFollow).length;
  const onlineCount = sessions.filter((s) => s.status === 'online').length;

  const canViewRadar = role === 'owner' || permissions?.canViewRadar !== false;
  const canImportBots = role === 'owner' || permissions?.canImportBots === true;
  const canViewLogs = role === 'owner' || permissions?.canViewLogs !== false;

  const tabs: Array<{ id: Tab; label: string; icon: typeof IconHome; tone: string }> = [
    { id: 'voice', label: 'Home', icon: IconHome, tone: 'accent' },
    ...(canViewRadar ? [{ id: 'radar' as Tab, label: 'User Info', icon: IconRadar, tone: 'accent' }] : []),
    ...(role === 'owner' || permissions?.canUseAutoReact
      ? [{ id: 'auto-react' as Tab, label: 'Auto-React', icon: IconWave, tone: 'accent' }]
      : []),
    ...(role === 'owner' || permissions?.canUseSpammer
      ? [
          { id: 'spammer' as Tab, label: 'Spammer', icon: IconMessage, tone: 'accent-2' },
          { id: 'blast' as Tab, label: 'Blast', icon: IconBomb, tone: 'bad' },
        ]
      : []),
    { id: 'monitor', label: 'Monitor', icon: IconMonitor, tone: 'accent' },
  ];

  // A remembered tab this key can no longer see (permissions changed) falls back to Home.
  const activeTab: Tab = tabs.some((t) => t.id === tab) ? tab : 'voice';

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-7xl flex-col gap-5 p-4 sm:p-6 lg:p-8">
      <Header
        snapshot={snapshot}
        connection={connection}
        role={role}
        keyInfo={keyInfo}
        onToggleAntiLeave={() => handleSaveConfig({ globalAntiLeave: !config.globalAntiLeave })}
        onOpenOwnerPanel={() => setShowOwnerPanel(true)}
        onLogout={handleLogout}
      />

      {/* Owner Panel Modal Drawer */}
      {showOwnerPanel && role === 'owner' && (
        <Suspense fallback={null}><OwnerPanel
          availableBots={snapshot?.sessions ?? []}
          onClose={() => {
            setShowOwnerPanel(false);
            refresh();
          }}
        /></Suspense>
      )}

      <nav className="topnav" role="tablist" aria-label="Main navigation">
        {tabs.map(({ id, label, icon: TabIcon, tone }) => (
          <button
            key={id}
            role="tab"
            aria-selected={activeTab === id}
            onClick={(e) => {
              setTab(id);
              e.currentTarget.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
            }}
            className="topnav-tab"
            style={{ '--tab-tone': `var(--color-${tone})` } as CSSProperties}
          >
            <TabIcon size={16} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      {/* key=tab restarts the entrance animation on every switch */}
      <ErrorBoundary key={activeTab}>
      <Suspense fallback={<PanelLoading />}>
      {activeTab === 'voice' ? (
        <div key="voice" className="tab-panel grid grid-cols-1 gap-5 lg:grid-cols-3">
          <div className="flex flex-col gap-5 lg:col-span-2">
            <VoiceControl
              config={config}
              sessions={sessions}
              selectedCount={selected.length}
              totalOnline={onlineCount}
              busy={busy}
              role={role}
              permissions={permissions}
              staggerMs={650}
              onJoin={handleJoin}
              onJoinOne={handleJoinOne}
              onLeave={handleLeave}
              onSave={handleSaveConfig}
            />

            {sessions.length > 0 && (
              <div className="flex items-center justify-between px-1">
                <button
                  onClick={() => setSelected(allSelected ? [] : sessions.map((s) => s.id))}
                  className="flex items-center gap-2 text-xs font-semibold text-[var(--color-ink-dim)] transition-colors hover:text-[var(--color-accent)]"
                >
                  {allSelected ? (
                    <IconCheckSquare size={15} className="text-[var(--color-accent)]" />
                  ) : (
                    <IconSquare size={15} />
                  )}
                  Select all ({sessions.length})
                </button>

                {selected.length > 0 && (
                  <span className="chip border-[var(--color-accent)]/30 font-mono text-[var(--color-accent)]">
                    {selected.length} selected
                  </span>
                )}
              </div>
            )}

            {sessions.length === 0 ? (
              <EmptySessions isRestricted={role === 'user' && permissions?.botScope === 'specific'} />
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {sessions.map((session, index) => (
                  <SessionCard
                    key={session.id}
                    session={session}
                    index={index}
                    role={role}
                    permissions={permissions}
                    selected={selected.includes(session.id)}
                    onToggleSelect={toggleSelect}
                    onRemove={handleRemove}
                    onReconnect={handleReconnect}
                    onReplaceToken={handleReplaceToken}
                    onToggleFlag={handleToggleFlag}
                    onSetVoiceState={handleSetVoiceState}
                    onLeaveGuild={handleLeaveGuild}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-5 lg:col-span-1">
            {canImportBots ? (
              <ImportPanel
                busy={busy}
                hasSessions={sessions.length > 0}
                canRemoveAll={role === 'owner'}
                storage={snapshot?.storage}
                onImport={handleImport}
                onRemoveAll={handleRemoveAll}
              />
            ) : (
              <div className="panel flex flex-col items-center gap-2 p-6 text-center text-xs text-[var(--color-ink-faint)]">
                <span className="flex size-9 items-center justify-center rounded-xl bg-[var(--color-surface-dim)] text-[var(--color-ink-dim)]">
                  <IconLock size={18} />
                </span>
                <p className="font-semibold text-[var(--color-ink-dim)]">Token Import Locked</p>
                <p className="text-[0.6875rem]">
                  Your access key is configured for bot control only. Token imports are managed by the administrator.
                </p>
              </div>
            )}

            {canViewLogs && <Console logs={logs} />}
          </div>
        </div>
      ) : activeTab === 'radar' ? (
        <div key="radar" className="tab-panel">
        <Radar
          config={config}
          followerCount={followerCount}
          onSave={handleSaveConfig}
          allowServerDetails
          isOwner={role === 'owner'}
          onJoinVoice={(guildId, channelId) =>
            handleJoin(guildId, channelId, config.selfMute, config.selfDeaf)
          }
        />
        </div>
      ) : activeTab === 'auto-react' ? (
        <div key="auto-react" className="tab-panel">
        <AutoReact
          sessions={sessions}
          rules={snapshot?.autoReactRules || []}
          role={role}
          permissions={permissions}
          onRefreshRules={refresh}
        />
        </div>
      ) : activeTab === 'spammer' ? (
        <div key="spammer" className="tab-panel">
          <MessageSpammer
            sessions={sessions}
            role={role}
            permissions={permissions}
          />
        </div>
      ) : activeTab === 'blast' ? (
        <div key="blast" className="tab-panel">
          <GuildBlast
            sessions={sessions}
            role={role}
            permissions={permissions}
          />
        </div>
      ) : activeTab === 'monitor' ? (
        <div key="monitor" className="tab-panel">
          <Monitor
            sessions={sessions}
            role={role}
            permissions={permissions}
            onJoinVoice={(guildId, channelId) =>
              handleJoin(guildId, channelId, config.selfMute, config.selfDeaf)
            }
          />
        </div>
      ) : null}
      </Suspense>
      </ErrorBoundary>

      <footer className="mt-auto pt-2 text-center text-[0.6875rem] text-[var(--color-ink-faint)]">
        Ghost Voice Control · {sessions.length} account{sessions.length === 1 ? '' : 's'} ·{' '}
        {connection} {role === 'owner' ? '· Master Mode' : '· Client Mode'}
      </footer>
    </div>
  );
}
