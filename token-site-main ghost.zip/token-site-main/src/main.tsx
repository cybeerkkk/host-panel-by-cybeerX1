import { createRoot } from 'react-dom/client';
import App from './App';
import { Backdrop } from './components/Backdrop';
import { ToastProvider } from './components/Toast';
import './index.css';

const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('Could not find the #root element');
}

createRoot(rootElement).render(
  <ToastProvider>
    <Backdrop />
    <App />
  </ToastProvider>,
);
