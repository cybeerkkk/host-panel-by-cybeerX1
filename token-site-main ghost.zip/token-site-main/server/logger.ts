import crypto from 'node:crypto';
import type { LogType, SystemLog } from '../shared/types.ts';

const MAX_LOGS = 300;

type Listener = (log: SystemLog) => void;

/**
 * Ring buffer of recent activity, newest last.
 *
 * Kept append-only with a listener fan-out so the SSE stream can push single
 * entries instead of the client re-downloading the whole array every 3s.
 */
class LogBus {
  private buffer: SystemLog[] = [];
  private listeners = new Set<Listener>();

  push(message: string, type: LogType = 'info'): SystemLog {
    const entry: SystemLog = {
      id: crypto.randomUUID(),
      at: Date.now(),
      type,
      message,
    };

    this.buffer.push(entry);
    if (this.buffer.length > MAX_LOGS) {
      this.buffer.splice(0, this.buffer.length - MAX_LOGS);
    }

    const stamp = new Date(entry.at).toISOString();
    const stream = type === 'error' ? console.error : console.log;
    stream(`[${stamp}] [${type}] ${message}`);

    for (const listener of this.listeners) {
      try {
        listener(entry);
      } catch {
        // A broken SSE client must never take down the emitter.
      }
    }

    return entry;
  }

  recent(): SystemLog[] {
    return this.buffer.slice();
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}

export const logs = new LogBus();

/** Never let a token reach a log line, a response body, or an error report. */
export function redact(value: string): string {
  if (value.length <= 8) return '****';
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}

export function errorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  if (typeof err === 'string') return err;
  return 'Unknown error';
}
