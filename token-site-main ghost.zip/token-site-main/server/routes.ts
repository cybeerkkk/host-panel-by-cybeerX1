import crypto from 'node:crypto';
import { Router } from 'express';
import type { Request, Response } from 'express';
import { isSnowflake, manager, searchAllTokens } from './botManager.ts';
import { errorMessage, logs } from './logger.ts';
import {
  hashPassword,
  registerSseClient,
  requireAuth,
  requireOwner,
  revokeKeySessions,
  revokeUserSession,
} from './auth.ts';
import {
  deleteAutoReactRule,
  getAutoReactRules,
  upsertAutoReactRule,
  
  deleteKey,
  getKeys,
  getKeyById,
  kickKeySession,
  setOwnerPassword,
  updateKeyConfig,
  upsertKey,
} from './store.ts';
import {
  checkSupabaseStatus,
  deleteKeyFromSupabase,
  isSupabaseConfigured,
  SUPABASE_SQL_SCHEMA,
  syncKeyToSupabase,
} from './supabase.ts';
import type {
  AccessKey,
  KeyPermissions,
  Snapshot,
  StreamEvent,
  SystemLog,
} from '../shared/types.ts';

export const api = Router();

/** Wraps an async handler so a rejection becomes a 500 instead of a dead socket. */
function handle(fn: (req: Request, res: Response) => Promise<void>) {
  return (req: Request, res: Response) => {
    fn(req, res).catch((err: unknown) => {
      const message = errorMessage(err);
      logs.push(`${req.method} ${req.path} failed: ${message}`, 'error');
      if (!res.headersSent) res.status(500).json({ error: message });
    });
  };
}

api.use(requireAuth);

function filterSnapshotForAuth(snapshot: Snapshot, auth: Request['auth']): Snapshot {
  if (!auth || auth.role === 'owner') return snapshot;
  const key = auth.key;
  if (!key) return snapshot;

  const filteredRules = snapshot.autoReactRules
    ? snapshot.autoReactRules.filter((r) => r.createdByKeyId === auth.keyId)
    : undefined;

  const allowedGuilds = key.permissions.allowedGuildIds ?? [];

  // Helper: strip voice slots the key has no guild access to
  const stripVoiceSlots = (session: Snapshot['sessions'][number]): Snapshot['sessions'][number] => {
    if (allowedGuilds.length === 0) return session;
    const slots = (session.voiceSlots ?? []).filter((vs) => allowedGuilds.includes(vs.guildId));
    const first = slots[0] ?? null;
    return {
      ...session,
      voiceSlots: slots,
      inVoice: slots.length > 0,
      guildId: first?.guildId ?? null,
      guildName: first?.guildName ?? null,
      channelId: first?.channelId ?? null,
      channelName: first?.channelName ?? null,
    };
  };

  if (key.permissions.botScope === 'all') {
    return {
      ...snapshot,
      sessions: snapshot.sessions.map(stripVoiceSlots),
      autoReactRules: filteredRules,
    };
  }

  const allowedBotIds = new Set(key.permissions.assignedBotIds);
  const filteredSessions = snapshot.sessions
    .filter((s) => allowedBotIds.has(s.id))
    .map(stripVoiceSlots);

  return {
    ...snapshot,
    sessions: filteredSessions,
    autoReactRules: filteredRules,
    stats: {
      total: filteredSessions.length,
      online: filteredSessions.filter((s) => s.status === 'online').length,
      inVoice: filteredSessions.filter((s) => s.inVoice).length,
      uptimeSeconds: snapshot.stats.uptimeSeconds,
    },
  };
}

function checkBotAllowed(botId: string, auth: Request['auth']): boolean {
  if (!auth || auth.role === 'owner') return true;
  if (auth.key?.permissions.botScope === 'all') return true;
  return Boolean(auth.key?.permissions.assignedBotIds.includes(botId));
}

function checkGuildAllowed(guildId: string, auth: Request['auth']): boolean {
  if (!auth || auth.role === 'owner') return true;
  const allowed = auth.key?.permissions.allowedGuildIds ?? [];
  return allowed.length === 0 || allowed.includes(guildId);
}

/** Radar-level access: owner, or a key that has the radar permission. */
function canUseRadarDetails(auth: Request['auth']): boolean {
  return auth?.role === 'owner' || Boolean(auth?.key?.permissions.canViewRadar);
}

// ------------------------------------------------------------------ snapshot & logs

api.get('/snapshot', (req, res) => {
  res.json(filterSnapshotForAuth(manager.snapshot(), req.auth));
});

api.get('/logs', (req, res) => {
  if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canViewLogs) {
    res.json([]);
    return;
  }
  res.json(logs.recent());
});

// -------------------------------------------------------------------- stream (SSE)

api.get('/stream', (req: Request, res: Response) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders?.();

  const auth = req.auth;

  const send = (event: StreamEvent) => {
    if (res.writableEnded) return;
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  // Register this SSE connection in our live revocation registry
  const unregisterSse = auth
    ? registerSseClient(
        auth.sessionId,
        auth.role,
        auth.keyId,
        send,
        () => {
          try {
            res.end();
          } catch {
            // Ignored
          }
        },
      )
    : () => {};

  send({ kind: 'snapshot', data: filterSnapshotForAuth(manager.snapshot(), auth) });

  if (auth?.role === 'owner' || auth?.key?.permissions.canViewLogs) {
    send({ kind: 'logs', data: logs.recent() });
  }

  // Batch bursty log lines into one frame per tick.
  let pendingLogs: SystemLog[] = [];
  let flushTimer: NodeJS.Timeout | null = null;

  const unsubscribeLogs = logs.subscribe((entry) => {
    if (auth?.role !== 'owner' && !auth?.key?.permissions.canViewLogs) return;
    pendingLogs.push(entry);
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      const batch = pendingLogs;
      pendingLogs = [];
      send({ kind: 'logs', data: batch });
    }, 200);
  });

  let snapshotDue = false;
  let snapshotTimer: NodeJS.Timeout | null = null;

  const unsubscribeChanges = manager.onChange(() => {
    snapshotDue = true;
    if (snapshotTimer) return;
    snapshotTimer = setTimeout(() => {
      snapshotTimer = null;
      if (!snapshotDue) return;
      snapshotDue = false;
      send({ kind: 'snapshot', data: filterSnapshotForAuth(manager.snapshot(), auth) });
    }, 150);
  });

  // Heartbeat: every 30 s as a fallback if the change-listener misses something.
  // The onChange listener already sends a debounced snapshot on every state change.
  const heartbeatTimer = setInterval(() => {
    send({ kind: 'snapshot', data: filterSnapshotForAuth(manager.snapshot(), auth) });
  }, 30_000);

  const pingTimer = setInterval(() => send({ kind: 'ping', data: Date.now() }), 25_000);

  const close = () => {
    unregisterSse();
    unsubscribeLogs();
    unsubscribeChanges();
    if (flushTimer) clearTimeout(flushTimer);
    if (snapshotTimer) clearTimeout(snapshotTimer);
    clearInterval(heartbeatTimer);
    clearInterval(pingTimer);
    res.end();
  };

  req.on('close', close);
  req.on('error', close);
});

// ------------------------------------------------------------------ sessions

api.post(
  '/sessions',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canImportBots) {
      res.status(403).json({ error: 'Your access key does not have permission to import bots' });
      return;
    }

    const raw = typeof req.body?.tokens === 'string' ? req.body.tokens : '';
    if (!raw.trim()) {
      res.status(400).json({ error: 'Paste at least one token' });
      return;
    }

    const result = await manager.addTokens(raw);
    
    // Automatically assign newly imported bots to the user who imported them
    if (result.addedIds && result.addedIds.length > 0 && req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const key = getKeyById(req.auth.keyId!);
      if (key) {
        // Clone to avoid mutating the cached store object directly
        const updatedKey = {
          ...key,
          permissions: {
            ...key.permissions,
            assignedBotIds: [...new Set([...key.permissions.assignedBotIds, ...result.addedIds])],
          },
        };
        upsertKey(updatedKey);
      }
    }

    if (result.added === 0 && result.failed === 0 && result.skipped > 0) {
      res.json({ ...result, message: 'Those accounts are already loaded' });
      return;
    }
    res.json(result);
  }),
);

api.delete(
  '/sessions/:id',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canDeleteBots) {
      res.status(403).json({ error: 'Your access key does not have permission to delete bots' });
      return;
    }

    if (!checkBotAllowed(req.params.id, req.auth)) {
      res.status(403).json({ error: 'You are not assigned to this bot' });
      return;
    }

    const removed = await manager.remove(req.params.id);
    if (!removed) {
      res.status(404).json({ error: 'Session not found' });
      return;
    }
    res.json({ ok: true });
  }),
);

api.delete(
  '/sessions',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can purge all sessions' });
      return;
    }
    const count = await manager.removeAll();
    res.json({ ok: true, removed: count });
  }),
);

api.post(
  '/sessions/:id/reconnect',
  handle(async (req, res) => {
    if (!checkBotAllowed(req.params.id, req.auth)) {
      res.status(403).json({ error: 'You are not assigned to this bot' });
      return;
    }
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canReconnectBots) {
      res.status(403).json({ error: 'Your access key does not have permission to reconnect bots' });
      return;
    }
    await manager.reconnect(req.params.id);
    res.json({ ok: true });
  }),
);

/**
 * Replace the token of an existing account from the website.
 * Owner, or a key that may both import AND delete bots (replacing = remove old + add new),
 * and only for bots that key is assigned to.
 */
api.put(
  '/sessions/:id/token',
  handle(async (req, res) => {
    const perms = req.auth?.key?.permissions;
    if (req.auth?.role !== 'owner' && !(perms?.canImportBots && perms?.canDeleteBots)) {
      res.status(403).json({ error: 'Your access key does not have permission to edit bot tokens' });
      return;
    }
    if (!checkBotAllowed(req.params.id, req.auth)) {
      res.status(403).json({ error: 'You are not assigned to this bot' });
      return;
    }

    const token = typeof req.body?.token === 'string' ? req.body.token : '';
    if (!token.trim()) {
      res.status(400).json({ error: 'Paste the new token' });
      return;
    }

    try {
      res.json(await manager.replaceToken(req.params.id, token));
    } catch (err) {
      const message = errorMessage(err);
      res.status(message === 'Session not found' ? 404 : 400).json({ error: message });
    }
  }),
);

api.patch('/sessions/:id', (req, res) => {
  if (!checkBotAllowed(req.params.id, req.auth)) {
    res.status(403).json({ error: 'You are not assigned to this bot' });
    return;
  }

  const { antiLeave, autoFollow } = req.body ?? {};

  if (typeof antiLeave === 'boolean') {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAntiLeave) {
      res.status(403).json({ error: 'Your key does not permit modifying anti-leave' });
      return;
    }
    manager.setSessionFlag(req.params.id, 'antiLeave', antiLeave);
  }

  if (typeof autoFollow === 'boolean') {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoFollow) {
      res.status(403).json({ error: 'Your key does not permit modifying auto-follow' });
      return;
    }
    manager.setSessionFlag(req.params.id, 'autoFollow', autoFollow);
  }

  const session = manager.get(req.params.id);
  if (!session) {
    res.status(404).json({ error: 'Session not found' });
    return;
  }
  res.json(session.toPublic());
});

// --------------------------------------------------------------------- voice

api.post(
  '/voice/join',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canJoinVoice) {
      res.status(403).json({ error: 'Your access key does not have permission to join voice' });
      return;
    }

    const cfg = manager.appConfig;
    const guildId = String(req.body?.guildId ?? cfg.defaultGuildId ?? '').trim();
    const channelId = String(req.body?.channelId ?? cfg.defaultChannelId ?? '').trim();

    if (!isSnowflake(guildId)) {
      res.status(400).json({ error: 'Server ID must be 17-20 digits' });
      return;
    }
    if (!isSnowflake(channelId)) {
      res.status(400).json({ error: 'Voice channel ID must be 17-20 digits' });
      return;
    }

    // Check if this key is allowed to operate in the requested guild
    if (!checkGuildAllowed(guildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to join voice in that server' });
      return;
    }

    let targetIds: string[] | undefined = Array.isArray(req.body?.ids) ? req.body.ids : undefined;

    // Filter requested IDs against key's assigned bot IDs
    if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const allowed = new Set(req.auth.key.permissions.assignedBotIds);
      if (targetIds) {
        targetIds = targetIds.filter((id) => allowed.has(id));
      } else {
        targetIds = req.auth.key.permissions.assignedBotIds;
      }
    }

    const result = await manager.joinVoice({
      ids: targetIds,
      guildId,
      channelId,
      selfMute: Boolean(req.body?.selfMute ?? cfg.selfMute),
      selfDeaf: Boolean(req.body?.selfDeaf ?? cfg.selfDeaf),
    });

    if (result.sent === 0) {
      res.status(409).json({ error: 'No online accounts available to send' });
      return;
    }
    res.json(result);
  }),
);

api.post(
  '/voice/leave',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canLeaveVoice) {
      res.status(403).json({ error: 'Your access key does not have permission to leave voice' });
      return;
    }

    // Optional: leave a specific guild only
    const leaveGuildId = req.body?.guildId ? String(req.body.guildId).trim() : undefined;
    if (leaveGuildId && !isSnowflake(leaveGuildId)) {
      res.status(400).json({ error: 'guildId must be a valid snowflake' });
      return;
    }
    if (leaveGuildId && !checkGuildAllowed(leaveGuildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to control that server' });
      return;
    }

    let targetIds: string[] | undefined = Array.isArray(req.body?.ids) ? req.body.ids : undefined;

    if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const allowed = new Set(req.auth.key.permissions.assignedBotIds);
      if (targetIds) {
        targetIds = targetIds.filter((id) => allowed.has(id));
      } else {
        targetIds = req.auth.key.permissions.assignedBotIds;
      }
    }

    const sent = await manager.leaveVoice(targetIds, leaveGuildId);
    res.json({ sent });
  }),
);

api.patch(
  '/voice/:id/state',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canMuteDeaf) {
      res.status(403).json({ error: 'Your access key does not have permission to toggle mute/deafen' });
      return;
    }

    if (!checkBotAllowed(req.params.id, req.auth)) {
      res.status(403).json({ error: 'You are not assigned to this bot' });
      return;
    }

    const { selfMute, selfDeaf } = req.body ?? {};
    if (typeof selfMute !== 'boolean' && typeof selfDeaf !== 'boolean') {
      res.status(400).json({ error: 'Provide selfMute and/or selfDeaf as booleans' });
      return;
    }

    const stateGuildId = req.body?.guildId ? String(req.body.guildId).trim() : undefined;
    if (!stateGuildId || !isSnowflake(stateGuildId)) {
      res.status(400).json({ error: 'Provide guildId (the server the bot is in) as a snowflake' });
      return;
    }
    if (!checkGuildAllowed(stateGuildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to control that server' });
      return;
    }
    const result = await manager.setVoiceFlags([req.params.id], stateGuildId, {
      selfMute: typeof selfMute === 'boolean' ? selfMute : undefined,
      selfDeaf: typeof selfDeaf === 'boolean' ? selfDeaf : undefined,
    });

    if (result.sent === 0) {
      res.status(409).json({ error: 'That account is not in voice right now' });
      return;
    }
    res.json({ ok: true });
  }),
);

// -------------------------------------------------------------------- config

api.get('/config', (req, res) => {
  if (req.auth?.role === 'user' && req.auth.key?.config) {
    res.json({
      ...manager.appConfig,
      ...req.auth.key.config,
    });
    return;
  }
  res.json(manager.appConfig);
});

api.patch('/config', (req, res) => {
  const body = req.body ?? {};

  // Strict allowlist — reject any keys not in the AppConfig shape so that
  // a crafted payload cannot smuggle unexpected properties into the config object.
  const ALLOWED_KEYS: ReadonlySet<string> = new Set([
    'defaultGuildId', 'defaultChannelId', 'autoFollowTargetId',
    'autoFollowEnabled', 'globalAntiLeave', 'selfMute', 'selfDeaf',
  ]);
  const unknownKeys = Object.keys(body).filter((k) => !ALLOWED_KEYS.has(k));
  if (unknownKeys.length > 0) {
    res.status(400).json({ error: `Unknown config fields: ${unknownKeys.join(', ')}` });
    return;
  }

  for (const field of ['defaultGuildId', 'defaultChannelId', 'autoFollowTargetId'] as const) {
    const value = body[field];
    if (typeof value === 'string' && value.trim() !== '' && !isSnowflake(value.trim())) {
      res.status(400).json({ error: `${field} must be a Discord ID (17-20 digits)` });
      return;
    }
  }

  for (const field of ['autoFollowEnabled', 'globalAntiLeave', 'selfMute', 'selfDeaf'] as const) {
    if (field in body && typeof body[field] !== 'boolean') {
      res.status(400).json({ error: `${field} must be a boolean` });
      return;
    }
  }

  if (req.auth?.role === 'owner') {
    res.json(manager.updateConfig(body));
    return;
  }

  // If user has a key, update their personal key configuration without affecting other keys
  if (req.auth?.key?.id) {
    const updated = updateKeyConfig(req.auth.key.id, body);
    res.json({
      ...manager.appConfig,
      ...(updated?.config ?? body),
    });
    return;
  }

  res.json(manager.appConfig);
});

// --------------------------------------------------------------------- radar

// Radar lookups are expensive (one Discord REST call each) — limit to 12/min per session.
const radarBuckets = new Map<string, { tokens: number; updated: number }>();
function radarRateLimit(req: Request, res: Response): boolean {
  const key = req.auth?.sessionId ?? req.ip ?? 'unknown';
  const now = Date.now();
  const bucket = radarBuckets.get(key) ?? { tokens: 40, updated: now };
  bucket.tokens = Math.min(40, bucket.tokens + ((now - bucket.updated) / 60_000) * 40);
  bucket.updated = now;
  if (bucket.tokens < 1) {
    radarBuckets.set(key, bucket);
    res.status(429).json({ error: 'Radar: too many lookups. Wait a moment before searching again.' });
    return false;
  }
  bucket.tokens -= 1;
  radarBuckets.set(key, bucket);
  return true;
}
setInterval(() => {
  const cutoff = Date.now() - 10 * 60_000;
  for (const [k, b] of radarBuckets) if (b.updated < cutoff) radarBuckets.delete(k);
}, 5 * 60_000).unref();

api.get(
  '/radar/:userId/ranks',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canViewRadar) {
      res.status(403).json({ error: 'Your access key does not have permission to access the radar' });
      return;
    }
    const { userId } = req.params;
    if (!isSnowflake(userId)) {
      res.status(400).json({ error: 'That is not a valid Discord user ID' });
      return;
    }
    try {
      res.json(await manager.lookupRanks(userId));
    } catch {
      res.json({});
    }
  }),
);

api.get(
  '/radar/:userId',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canViewRadar) {
      res.status(403).json({ error: 'Your access key does not have permission to access the radar' });
      return;
    }

    if (!radarRateLimit(req, res)) return;

    const { userId } = req.params;
    if (!isSnowflake(userId)) {
      res.status(400).json({ error: 'That is not a valid Discord user ID' });
      return;
    }

    try {
      res.json(await manager.lookupProfile(userId));
    } catch (err) {
      const message = errorMessage(err);
      const status = /add at least one/i.test(message) ? 409 : 404;
      res.status(status).json({ error: status === 404 ? 'User not found' : message });
    }
  }),
);

api.post(
  '/radar/join-target',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canJoinVoice) {
      res.status(403).json({ error: 'Your access key does not have permission to join voice' });
      return;
    }

    const { guildId, channelId, ids } = req.body ?? {};
    if (!isSnowflake(String(guildId ?? '')) || !isSnowflake(String(channelId ?? '')) ) {
      res.status(400).json({ error: 'Target voice channel or server ID is invalid' });
      return;
    }

    // Same guild restriction /voice/join enforces. Without it a key locked to
    // one server could dispatch its bots anywhere just by going through the
    // radar instead of the voice panel.
    if (!checkGuildAllowed(String(guildId), req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to join voice in that server' });
      return;
    }

    let targetIds: string[] | undefined = Array.isArray(ids) && ids.length > 0 ? ids : undefined;
    if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const allowed = new Set(req.auth.key.permissions.assignedBotIds);
      if (targetIds) {
        targetIds = targetIds.filter((id) => allowed.has(id));
      } else {
        targetIds = req.auth.key.permissions.assignedBotIds;
      }
    }

    const result = await manager.joinVoice({
      ids: targetIds,
      guildId: String(guildId),
      channelId: String(channelId),
      selfMute: manager.appConfig.selfMute,
      selfDeaf: manager.appConfig.selfDeaf,
    });

    if (result.sent === 0) {
      res.status(409).json({ error: 'No online accounts available to dispatch' });
      return;
    }
    res.json(result);
  }),
);

// --------------------------------------------------------------------- auto-react

api.get('/auto-react', (req, res) => {
  if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoReact) {
    res.status(403).json({ error: 'Your access key does not have permission to use auto-react' });
    return;
  }
  const rules = getAutoReactRules();
  // Owners see every rule; a key only ever sees the rules it created.
  if (req.auth?.role === 'owner') {
    res.json(rules);
  } else {
    res.json(rules.filter(r => r.createdByKeyId === req.auth?.keyId));
  }
});

api.post(
  '/auto-react',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoReact) {
      res.status(403).json({ error: 'Your access key does not have permission to use auto-react' });
      return;
    }

    const { name, targetUserId, emoji, botScope, botIds } = req.body ?? {};

    if (!isSnowflake(targetUserId)) {
      res.status(400).json({ error: 'Target Discord user ID is invalid' });
      return;
    }
    if (!emoji || typeof emoji !== 'string' || !emoji.trim()) {
      res.status(400).json({ error: 'Emoji is required' });
      return;
    }

    let allowedBotIds = botIds || [];
    if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const allowed = new Set(req.auth.key.permissions.assignedBotIds);
      allowedBotIds = allowedBotIds.filter((id: string) => allowed.has(id));
      if (botScope === 'all') {
        allowedBotIds = req.auth.key.permissions.assignedBotIds;
      }
    }

    const canUseAllScope = req.auth?.role === 'owner' || req.auth?.key?.permissions.botScope === 'all';

    const rule: any = {
      id: crypto.randomUUID(),
      name: String(name || 'Unnamed Rule').trim(),
      targetUserId: String(targetUserId).trim(),
      emoji: String(emoji).trim(),
      enabled: true,
      botScope: botScope === 'all' && canUseAllScope ? 'all' : 'specific',
      botIds: allowedBotIds,
      createdAt: Date.now(),
      triggerCount: 0,
      lastTriggeredAt: null,
      createdByRole: req.auth?.role,
      createdByKeyId: req.auth?.keyId,
    };

    upsertAutoReactRule(rule);
    logs.push(`Auto-react rule "${rule.name}" created`, 'info');
    manager.notifyChange(); // To let UI know if they rely on snapshot, though this is rest api
    res.json(rule);
  }),
);

api.patch(
  '/auto-react/:id',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoReact) {
      res.status(403).json({ error: 'Your access key does not have permission to use auto-react' });
      return;
    }

    const rules = getAutoReactRules();
    const rule = rules.find((r) => r.id === req.params.id);
    if (!rule) {
      res.status(404).json({ error: 'Rule not found' });
      return;
    }

    if (req.auth?.role !== 'owner' && rule.createdByKeyId !== req.auth?.keyId) {
      res.status(403).json({ error: 'You can only edit your own rules' });
      return;
    }

    const patch = req.body ?? {};
    const updated = { ...rule };

    if (typeof patch.name === 'string') updated.name = patch.name.trim();
    if (typeof patch.targetUserId === 'string' && isSnowflake(patch.targetUserId)) {
      updated.targetUserId = patch.targetUserId.trim();
    }
    if (typeof patch.emoji === 'string') updated.emoji = patch.emoji.trim();
    if (typeof patch.enabled === 'boolean') updated.enabled = patch.enabled;
    if (typeof patch.botScope === 'string') {
      const canUseAllScope = req.auth?.role === 'owner' || req.auth?.key?.permissions.botScope === 'all';
      updated.botScope = patch.botScope === 'all' && canUseAllScope ? 'all' : 'specific';
    }
    if (Array.isArray(patch.botIds)) {
      let allowedBotIds = patch.botIds;
      if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
        const allowed = new Set(req.auth.key.permissions.assignedBotIds);
        allowedBotIds = allowedBotIds.filter((id: string) => allowed.has(id));
      }
      updated.botIds = allowedBotIds;
    }

    upsertAutoReactRule(updated);
    logs.push(`Auto-react rule "${updated.name}" updated`, 'info');
    manager.notifyChange();
    res.json(updated);
  }),
);

api.delete(
  '/auto-react/:id',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoReact) {
      res.status(403).json({ error: 'Your access key does not have permission to use auto-react' });
      return;
    }

    const rules = getAutoReactRules();
    const rule = rules.find((r) => r.id === req.params.id);
    if (!rule) {
      res.status(404).json({ error: 'Rule not found' });
      return;
    }

    if (req.auth?.role !== 'owner' && rule.createdByKeyId !== req.auth?.keyId) {
      res.status(403).json({ error: 'You can only delete your own rules' });
      return;
    }

    deleteAutoReactRule(req.params.id);
    logs.push(`Auto-react rule deleted`, 'info');
    res.json({ ok: true });
  }),
);

// ===================================================================== OWNER PANEL API
// All routes below strictly enforce requireOwner

function generateRandomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const chunk = () => {
    let s = '';
    for (let i = 0; i < 4; i++) {
      s += chars[crypto.randomInt(0, chars.length)];
    }
    return s;
  };
  return `GVC-${chunk()}-${chunk()}-${chunk()}`;
}

const defaultPermissions: KeyPermissions = {
  botScope: 'all',
  assignedBotIds: [],
  allowedGuildIds: [],
  canJoinVoice: true,
  canLeaveVoice: true,
  canMuteDeaf: true,
  canUseAntiLeave: true,
  canUseAutoFollow: false,
  canViewRadar: true,
  canUseAutoReact: false,
  canUseSpammer: false,
  canReconnectBots: true,
  canLeaveGuild: false,
  canImportBots: false,
  canDeleteBots: false,
  canViewLogs: true,
};

api.get('/owner/keys', requireOwner, (_req, res) => {
  res.json(getKeys());
});

api.post(
  '/owner/keys',
  requireOwner,
  handle(async (req, res) => {
    const body = req.body ?? {};
    const count = Math.max(1, Math.min(50, Number.parseInt(body.count ?? '1', 10) || 1));
    const rawCode = typeof body.key === 'string' ? body.key.trim().toUpperCase() : '';
    const note = typeof body.note === 'string' ? body.note.trim() : '';

    const expiresAt = typeof body.expiresAt === 'number' ? body.expiresAt : null;
    const durationMs = typeof body.durationMs === 'number' ? body.durationMs : null;
    // Number('abc') is NaN, and `redeemedUsers.length >= NaN` is always false,
    // so a malformed maxUses used to mint an unlimited key. Unlimited is a
    // deliberate choice (explicit null), never the result of a typo — bad
    // input is rejected rather than quietly widened.
    let maxUses: number | null = null;
    if (body.maxUses !== null && body.maxUses !== undefined) {
      const parsed = Number(body.maxUses);
      if (!Number.isFinite(parsed) || parsed < 1) {
        res.status(400).json({ error: 'maxUses must be a whole number of 1 or more, or null for unlimited' });
        return;
      }
      maxUses = Math.floor(parsed);
    }

    const permissions: KeyPermissions = {
      ...defaultPermissions,
      ...(body.permissions ?? {}),
      assignedBotIds: Array.isArray(body.permissions?.assignedBotIds)
        ? body.permissions.assignedBotIds.filter((id: unknown) => typeof id === 'string')
        : [],
      allowedGuildIds: Array.isArray(body.permissions?.allowedGuildIds)
        ? body.permissions.allowedGuildIds.filter((id: unknown) => typeof id === 'string' && /^\d{17,20}$/.test(id as string))
        : [],
    };

    const createdKeys: AccessKey[] = [];
    const now = Date.now();

    for (let i = 0; i < count; i++) {
      const code = count === 1 && rawCode ? rawCode : generateRandomCode();
      const accessKey: AccessKey = {
        id: crypto.randomUUID(),
        key: code,
        note: count > 1 && note ? `${note} #${i + 1}` : note,
        role: 'user',
        createdAt: now,
        expiresAt,
        durationMs,
        firstUsedAt: null,
        maxUses,
        usedCount: 0,
        status: 'active',
        permissions,
        redeemedUsers: [],
      };

      upsertKey(accessKey);
      createdKeys.push(accessKey);
      void syncKeyToSupabase(accessKey);
    }

    logs.push(`Owner generated ${createdKeys.length} access key(s)`, 'info');
    res.json({ ok: true, keys: createdKeys });
  }),
);

api.patch(
  '/owner/keys/:id',
  requireOwner,
  handle(async (req, res) => {
    const target = getKeyById(req.params.id);
    if (!target) {
      res.status(404).json({ error: 'Access key not found' });
      return;
    }

    const body = req.body ?? {};
    const previousStatus = target.status;
    const newStatus = body.status === 'disabled' ? 'disabled' : body.status === 'active' ? 'active' : target.status;

    // Same rule as creation: an unparseable maxUses is an error, not unlimited.
    let nextMaxUses: number | null = target.maxUses;
    if (body.maxUses !== undefined) {
      if (body.maxUses === null) {
        nextMaxUses = null;
      } else {
        const parsed = Number(body.maxUses);
        if (!Number.isFinite(parsed) || parsed < 1) {
          res.status(400).json({ error: 'maxUses must be a whole number of 1 or more, or null for unlimited' });
          return;
        }
        nextMaxUses = Math.floor(parsed);
      }
    }

    const updated: AccessKey = {
      ...target,
      note: typeof body.note === 'string' ? body.note.trim() : target.note,
      status: newStatus,
      expiresAt: body.expiresAt !== undefined ? body.expiresAt : target.expiresAt,
      maxUses: nextMaxUses,
      permissions: body.permissions
        ? {
            ...target.permissions,
            ...body.permissions,
            // Validate botScope to only allow known values
            botScope: body.permissions.botScope === 'specific' ? 'specific' : body.permissions.botScope === 'all' ? 'all' : target.permissions.botScope,
            assignedBotIds: Array.isArray(body.permissions.assignedBotIds)
              ? body.permissions.assignedBotIds.filter((id: unknown) => typeof id === 'string')
              : target.permissions.assignedBotIds,
            allowedGuildIds: Array.isArray(body.permissions.allowedGuildIds)
              ? body.permissions.allowedGuildIds.filter((id: unknown) => typeof id === 'string' && /^\d{17,20}$/.test(id as string))
              : (target.permissions.allowedGuildIds ?? []),
          }
        : target.permissions,
    };

    upsertKey(updated);
    void syncKeyToSupabase(updated);

    // If owner disabled the key, terminate all active SSE connections instantly
    if (previousStatus === 'active' && newStatus === 'disabled') {
      revokeKeySessions(target.id, 'This access key was paused by the owner.');
      logs.push(`Owner disabled key ${target.key}`, 'warn');
    }

    res.json(updated);
  }),
);

api.delete(
  '/owner/keys/:id',
  requireOwner,
  handle(async (req, res) => {
    const target = getKeyById(req.params.id);
    if (!target) {
      res.status(404).json({ error: 'Access key not found' });
      return;
    }

    deleteKey(target.id);
    void deleteKeyFromSupabase(target.id);

    // Live kick everyone using this key
    revokeKeySessions(target.id, 'This access key has been permanently revoked.');
    logs.push(`Owner deleted and revoked key ${target.key}`, 'warn');

    res.json({ ok: true, deletedId: target.id });
  }),
);

api.post(
  '/owner/keys/:id/kick/:sessionId',
  requireOwner,
  handle(async (req, res) => {
    const { id, sessionId } = req.params;
    const kicked = kickKeySession(id, sessionId);
    if (!kicked) {
      res.status(404).json({ error: 'User session not found on this key' });
      return;
    }

    revokeUserSession(sessionId, 'Your session was terminated by the administrator.');
    logs.push(`Owner kicked session ${sessionId.slice(0, 8)} from key`, 'warn');

    res.json({ ok: true });
  }),
);

api.post(
  '/owner/password',
  requireOwner,
  handle(async (req, res) => {
    const newPassword = typeof req.body?.password === 'string' ? req.body.password.trim() : '';
    if (newPassword.length < 10) {
      res.status(400).json({ error: 'Owner password must be at least 10 characters' });
      return;
    }
    if (!/[a-zA-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
      res.status(400).json({ error: 'Owner password must contain both letters and numbers' });
      return;
    }

    // Stored as a scrypt hash, never in the clear.
    setOwnerPassword(hashPassword(newPassword));
    logs.push('Owner access password updated', 'info');
    res.json({ ok: true, message: 'Password updated successfully' });
  }),
);

api.get('/owner/stats', requireOwner, (_req, res) => {
  const keys = getKeys();
  const now = Date.now();
  let totalRedeemed = 0;
  let activeUsersCount = 0;

  for (const k of keys) {
    totalRedeemed += k.usedCount;
    // count users active in the last 10 minutes
    const recent = k.redeemedUsers.filter((u) => now - u.lastActiveAt < 10 * 60_000);
    activeUsersCount += recent.length;
  }

  res.json({
    totalKeys: keys.length,
    activeKeys: keys.filter((k) => k.status === 'active' && (!k.expiresAt || k.expiresAt > now)).length,
    disabledKeys: keys.filter((k) => k.status === 'disabled').length,
    expiredKeys: keys.filter((k) => k.status === 'active' && Boolean(k.expiresAt && k.expiresAt <= now)).length,
    totalRedeemed,
    activeUsersCount,
    isSupabaseConfigured,
  });
});

api.get(
  '/owner/supabase-status',
  requireOwner,
  handle(async (_req, res) => {
    const status = await checkSupabaseStatus();
    res.json({
      ...status,
      schemaSql: SUPABASE_SQL_SCHEMA,
    });
  }),
);

api.post(
  '/owner/supabase-sync',
  requireOwner,
  handle(async (_req, res) => {
    const keys = getKeys();
    let synced = 0;
    for (const key of keys) {
      await syncKeyToSupabase(key);
      synced++;
    }
    res.json({ ok: true, synced });
  }),
);

// --------------------------------------------------------------------- spammer
// Routes are intentionally thin — they resolve the bot by id, grab its token
// from the server-side Session object, then make a single Discord REST call.
// The token never crosses the API boundary to the browser.

api.post(
  '/spammer/send',
  handle(async (req, res) => {
    // Permission gate: only owner or keys with canUseSpammer can use spammer
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseSpammer) {
      res.status(403).json({ error: 'Your access key does not have permission to use the spammer' });
      return;
    }

    const { botId, channelId, content } = req.body ?? {};

    if (typeof botId !== 'string' || typeof channelId !== 'string' || typeof content !== 'string') {
      res.status(400).json({ error: 'botId, channelId and content are required' });
      return;
    }
    if (!/^\d{17,20}$/.test(channelId)) {
      res.status(400).json({ error: 'channelId must be a valid Discord snowflake' });
      return;
    }
    if (content.trim().length === 0 || content.length > 2000) {
      res.status(400).json({ error: 'content must be 1-2000 characters' });
      return;
    }

    const session = manager.get(botId);
    if (!session) {
      res.status(404).json({ error: 'Bot not found' });
      return;
    }
    if (session.status !== 'online') {
      res.status(409).json({ error: 'Bot is not online' });
      return;
    }

    // Scope check for user keys
    const auth = req.auth;
    if (auth?.role !== 'owner' && auth?.key) {
      const scope = auth.key.permissions.botScope;
      const assigned = auth.key.permissions.assignedBotIds ?? [];
      if (scope === 'specific' && !assigned.includes(botId)) {
        res.status(403).json({ error: 'This bot is not assigned to your access key' });
        return;
      }
    }

    // Per-request unique fingerprint — build number varies slightly per session
    // so every bot looks like it's running a slightly different client version.
    const buildOffset = Math.floor(parseInt(session.id.replace(/-/g, '').slice(0, 8), 16) % 500);
    const buildNumber = 309800 + buildOffset;

    const chromeMajor = 124 + (buildOffset % 4); // 124-127
    const ua = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Safari/537.36`;

    const locales = ['en-US', 'en-GB', 'en-CA', 'en-AU'];
    const locale = locales[buildOffset % locales.length];

    const tzList = ['America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris'];
    const tz = tzList[buildOffset % tzList.length];

    const nonce = String((BigInt(Date.now() - 1420070400000) << 22n) + BigInt(Math.floor(Math.random() * 4194304)));

    const superProps = Buffer.from(JSON.stringify({
      os: 'Windows',
      browser: 'Chrome',
      device: '',
      system_locale: locale,
      browser_user_agent: ua,
      browser_version: `${chromeMajor}.0.0.0`,
      os_version: '10',
      referrer: '',
      referring_domain: '',
      referrer_current: '',
      referring_domain_current: '',
      release_channel: 'stable',
      client_build_number: buildNumber,
      client_event_source: null,
    })).toString('base64');

    const discordRes = await fetch(`https://discord.com/api/v9/channels/${channelId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: session.token,
        'Content-Type': 'application/json',
        'User-Agent': ua,
        'X-Discord-Locale': locale,
        'X-Discord-Timezone': tz,
        'X-Debug-Options': 'bugReporterEnabled',
        'X-Super-Properties': superProps,
        'Accept': '*/*',
        'Accept-Language': `${locale},en;q=0.9`,
        'Origin': 'https://discord.com',
        'Referer': `https://discord.com/channels/@me`,
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Connection': 'keep-alive',
      },
      body: JSON.stringify({
        content: content.trim(),
        nonce,
        tts: false,
        flags: 0,
      }),
    });

    if (!discordRes.ok) {
      const err = await discordRes.json().catch(() => ({})) as { message?: string };
      const msg = err?.message ?? `Discord API returned ${discordRes.status}`;
      logs.push(`Spammer: ${session.toPublic().username} send failed — ${msg}`, 'error');
      res.status(discordRes.status >= 500 ? 502 : discordRes.status).json({ error: msg });
      return;
    }

    logs.push(`Spammer: ${session.toPublic().username} → #${channelId.slice(-4)} ✓`, 'info');
    res.json({ ok: true });
  }),
);

api.post(
  '/spammer/dm-channel',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseSpammer) {
      res.status(403).json({ error: 'Your access key does not have permission to use the spammer' });
      return;
    }

    const { botId, userId } = req.body ?? {};

    if (typeof botId !== 'string' || typeof userId !== 'string') {
      res.status(400).json({ error: 'botId and userId are required' });
      return;
    }
    if (!/^\d{17,20}$/.test(userId)) {
      res.status(400).json({ error: 'userId must be a valid Discord snowflake' });
      return;
    }

    const session = manager.get(botId);
    if (!session) {
      res.status(404).json({ error: 'Bot not found' });
      return;
    }
    if (session.status !== 'online') {
      res.status(409).json({ error: 'Bot is not online' });
      return;
    }

    const auth = req.auth;
    if (auth?.role !== 'owner' && auth?.key) {
      const scope = auth.key.permissions.botScope;
      const assigned = auth.key.permissions.assignedBotIds ?? [];
      if (scope === 'specific' && !assigned.includes(botId)) {
        res.status(403).json({ error: 'This bot is not assigned to your access key' });
        return;
      }
    }

    const discordRes = await fetch('https://discord.com/api/v9/users/@me/channels', {
      method: 'POST',
      headers: {
        Authorization: session.token,
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        'X-Discord-Locale': 'en-US',
        'X-Discord-Timezone': 'America/New_York',
        'X-Debug-Options': 'bugReporterEnabled',
        'X-Super-Properties': Buffer.from(JSON.stringify({
          os: 'Windows',
          browser: 'Chrome',
          device: '',
          system_locale: 'en-US',
          browser_user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          browser_version: '126.0.0.0',
          os_version: '10',
          referrer: '',
          referring_domain: '',
          referrer_current: '',
          referring_domain_current: '',
          release_channel: 'stable',
          client_build_number: 310000,
          client_event_source: null,
        })).toString('base64'),
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://discord.com',
        'Referer': 'https://discord.com/channels/@me',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
      },
      body: JSON.stringify({ recipient_id: userId }),
    });

    if (!discordRes.ok) {
      const err = await discordRes.json().catch(() => ({})) as { message?: string };
      const msg = err?.message ?? `Discord API returned ${discordRes.status}`;
      res.status(discordRes.status >= 500 ? 502 : discordRes.status).json({ error: msg });
      return;
    }

    const data = await discordRes.json() as { id: string };
    res.json({ channelId: data.id });
  }),
);

// ─────────────────────────────────────────────────────────────────────────────
// GUILD BLAST — scan a server's channels then spray all of them
// ─────────────────────────────────────────────────────────────────────────────

/** Build a per-session Discord REST fingerprint (same logic as /spammer/send). */
function buildFingerprint(sessionId: string) {
  const buildOffset = Math.floor(parseInt(sessionId.replace(/-/g, '').slice(0, 8), 16) % 500);
  const buildNumber = 309800 + buildOffset;
  const chromeMajor = 124 + (buildOffset % 4);
  const ua = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Safari/537.36`;
  const locales = ['en-US', 'en-GB', 'en-CA', 'en-AU'];
  const locale = locales[buildOffset % locales.length];
  const tzList = ['America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris'];
  const tz = tzList[buildOffset % tzList.length];
  const superProps = Buffer.from(JSON.stringify({
    os: 'Windows', browser: 'Chrome', device: '',
    system_locale: locale, browser_user_agent: ua,
    browser_version: `${chromeMajor}.0.0.0`, os_version: '10',
    referrer: '', referring_domain: '', referrer_current: '',
    referring_domain_current: '', release_channel: 'stable',
    client_build_number: buildNumber, client_event_source: null,
  })).toString('base64');
  return { ua, locale, tz, superProps };
}

/** Fetch all accessible text + voice channels for a guild via Discord REST. */
type GuildChannelRow = { id: string; name: string; type: number; position: number; parent_id: string | null };

const channelListCache = new Map<string, { at: number; data: GuildChannelRow[] }>();
const channelListInflight = new Map<string, Promise<GuildChannelRow[]>>();
const CHANNEL_LIST_TTL_MS = 30_000;
/** A stale list is still better than an empty monitor when Discord rate-limits or times out. */
const CHANNEL_LIST_STALE_OK_MS = 10 * 60_000;

/**
 * The monitor polls a server every few seconds, and each poll used to hit Discord's REST API
 * with an account token. Voice members come from the live gateway cache, so the channel
 * list itself only needs refreshing every so often; concurrent callers share one request.
 */
async function fetchGuildChannels(
  token: string,
  guildId: string,
  sessionId: string,
  maxAgeMs = CHANNEL_LIST_TTL_MS,
): Promise<GuildChannelRow[]> {
  const cached = channelListCache.get(guildId);
  if (cached && Date.now() - cached.at < maxAgeMs) return cached.data;

  const running = channelListInflight.get(guildId);
  if (running) return running;

  const request = fetchGuildChannelsRaw(token, guildId, sessionId)
    .then((data) => {
      channelListCache.set(guildId, { at: Date.now(), data });
      return data;
    })
    .catch((err) => {
      if (cached && Date.now() - cached.at < CHANNEL_LIST_STALE_OK_MS) return cached.data;
      throw err;
    })
    .finally(() => {
      channelListInflight.delete(guildId);
    });
  channelListInflight.set(guildId, request);
  return request;
}

async function fetchGuildChannelsRaw(token: string, guildId: string, sessionId: string): Promise<GuildChannelRow[]> {
  const fp = buildFingerprint(sessionId);
  const res = await fetch(`https://discord.com/api/v9/guilds/${guildId}/channels`, {
    signal: AbortSignal.timeout(10_000),
    headers: {
      Authorization: token,
      'User-Agent': fp.ua,
      'X-Discord-Locale': fp.locale,
      'X-Discord-Timezone': fp.tz,
      'X-Super-Properties': fp.superProps,
      'X-Debug-Options': 'bugReporterEnabled',
      Accept: '*/*',
      'Accept-Language': `${fp.locale},en;q=0.9`,
      Origin: 'https://discord.com',
      Referer: `https://discord.com/channels/${guildId}`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
    },
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({})) as { message?: string };
    throw new Error(e.message ?? `Discord ${res.status}`);
  }
  return res.json() as Promise<GuildChannelRow[]>;
}

async function fetchGuildMember(token: string, guildId: string, userId: string, sessionId: string): Promise<{
  user?: { id?: string; username?: string; global_name?: string | null; avatar?: string | null };
  nick?: string | null;
  avatar?: string | null;
  joined_at?: string | null;
  roles?: string[];
}> {
  const fp = buildFingerprint(sessionId);
  const response = await fetch(
    `https://discord.com/api/v9/guilds/${guildId}/members/${userId}`,
    {
      headers: {
        Authorization: token,
        'User-Agent': fp.ua,
        'X-Discord-Locale': fp.locale,
        'X-Discord-Timezone': fp.tz,
        'X-Super-Properties': fp.superProps,
        Accept: '*/*',
        'Accept-Language': `${fp.locale},en;q=0.9`,
        Origin: 'https://discord.com',
        Referer: `https://discord.com/channels/${guildId}`,
      },
    },
  );
  if (!response.ok) {
    const body = await response.json().catch(() => ({})) as { message?: string };
    throw Object.assign(new Error(body.message ?? `Discord ${response.status}`), {
      status: response.status,
    });
  }
  return response.json() as Promise<{
    user?: { id?: string; username?: string; global_name?: string | null; avatar?: string | null };
    nick?: string | null;
    avatar?: string | null;
    joined_at?: string | null;
    roles?: string[];
  }>;
}

/**
 * GET /api/spammer/scan-guild?botId=X&guildId=Y
 * Returns text channels (type 0) + voice channels (type 2) the bot can see.
 */
api.get(
  '/spammer/scan-guild',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseSpammer) {
      res.status(403).json({ error: 'Your access key does not have permission to use the spammer' });
      return;
    }

    const botId   = String(req.query.botId ?? '').trim();
    const guildId = String(req.query.guildId ?? '').trim();

    if (!botId || !guildId) {
      res.status(400).json({ error: 'botId and guildId are required' });
      return;
    }
    if (!/^\d{17,20}$/.test(guildId)) {
      res.status(400).json({ error: 'guildId must be a valid Discord snowflake' });
      return;
    }
    // Guild scope check - same restriction as voice join
    if (!checkGuildAllowed(String(guildId), req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to scan that server' });
      return;
    }
    // Bot scope check
    if (!checkBotAllowed(botId, req.auth)) {
      res.status(403).json({ error: 'This bot is not assigned to your access key' });
      return;
    }

    const session = manager.get(botId);
    if (!session) { res.status(404).json({ error: 'Bot not found' }); return; }
    if (session.status !== 'online') { res.status(409).json({ error: 'Bot is offline' }); return; }

    const raw = await fetchGuildChannels(session.token, guildId, session.id, 0);

    // Type 0 = text, type 2 = voice, type 13 = stage — filter others out
    const channels = raw
      .filter(c => c.type === 0 || c.type === 2 || c.type === 13)
      .sort((a, b) => a.position - b.position)
      .map(c => ({
        id: c.id,
        name: c.name,
        type: c.type === 0 ? 'text' : c.type === 2 ? 'voice' : 'stage',
        parentId: c.parent_id,
      }));

    res.json({ guildId, channels });
  }),
);

// Active blast jobs — keyed by jobId, so KILL can cancel them
const blastJobs = new Map<string, { cancel: boolean }>();

/**
 * POST /api/spammer/blast
 * Body: { jobId, botIds[], guildId, channelIds[], message, delayMs, msgsPerChannel, smartMode }
 *
 * smartMode = true → jitter timing + randomise message per send to reduce detection.
 * Returns SSE stream: data: { type: 'sent'|'error'|'done', ... }
 */
api.post(
  '/spammer/blast',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseSpammer) {
      res.status(403).json({ error: 'Your access key does not have permission to use the spammer' });
      return;
    }

    const {
      jobId,
      botIds,
      guildId,
      channelIds,
      message,
      delayMs     = 0,
      msgsPerChannel = 1,
      smartMode   = true,
    } = req.body ?? {};

    if (!jobId || !Array.isArray(botIds) || botIds.length === 0 || !guildId || !Array.isArray(channelIds) || channelIds.length === 0) {
      res.status(400).json({ error: 'jobId, botIds[], guildId, channelIds[] are required' });
      return;
    }
    if (typeof message !== 'string' || message.trim().length === 0 || message.length > 2000) {
      res.status(400).json({ error: 'message must be 1-2000 chars' });
      return;
    }
    // Hard caps to prevent runaway blast jobs
    if (channelIds.length > 500) {
      res.status(400).json({ error: 'channelIds must not exceed 500 entries' });
      return;
    }
    if (botIds.length > 200) {
      res.status(400).json({ error: 'botIds must not exceed 200 entries' });
      return;
    }
    const safeDelay = typeof delayMs === 'number' ? Math.max(0, Math.min(delayMs, 60_000)) : 0;
    const safeMsgsPerChannel = typeof msgsPerChannel === 'number' ? Math.max(1, Math.min(msgsPerChannel, 20)) : 1;

    // Resolve sessions
    const sessions = (botIds as string[]).map(id => manager.get(id)).filter(Boolean) as ReturnType<typeof manager.get>[];
    const onlineSessions = sessions.filter(s => s && s.status === 'online') as NonNullable<ReturnType<typeof manager.get>>[];
    if (onlineSessions.length === 0) {
      res.status(409).json({ error: 'No online bots in selection' });
      return;
    }

    // Register job
    const job = { cancel: false };
    blastJobs.set(jobId, job);

    // SSE stream
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const send = (payload: object) => {
      if (!res.writableEnded) res.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    let totalSent = 0;
    let totalErrors = 0;
    const totalTarget = channelIds.length * safeMsgsPerChannel;

    // Spinner: cycles bots round-robin per channel
    let botIdx = 0;
    const nextBot = () => {
      const b = onlineSessions[botIdx % onlineSessions.length];
      botIdx++;
      return b;
    };

    // Smart message spinner
    function buildContent(tpl: string): string {
      let result = tpl.replace(/\{([^}]+)\}/g, (_: string, inner: string) => {
        const c = inner.split('|');
        return c[Math.floor(Math.random() * c.length)];
      });
      if (smartMode) {
        const zw = ['\u200b', '\u200c', '\u200d', '\u2060'];
        for (let i = 0; i < 2; i++) {
          const pos = Math.floor(Math.random() * (result.length + 1));
          result = result.slice(0, pos) + zw[Math.floor(Math.random() * zw.length)] + result.slice(pos);
        }
      }
      return result;
    }

    // Rate-limit state per bot token — tracks 429 cooldowns
    const rateLimitUntil = new Map<string, number>();

    async function sendToChannel(session: NonNullable<ReturnType<typeof manager.get>>, channelId: string): Promise<boolean> {
      if (job.cancel) return false;

      // Honour rate-limit cooldown for this bot
      const rlUntil = rateLimitUntil.get(session.id) ?? 0;
      if (Date.now() < rlUntil) {
        const wait = rlUntil - Date.now();
        send({ type: 'ratelimit', botId: session.id, wait });
        await new Promise<void>(r => setTimeout(r, wait));
        if (job.cancel) return false;
      }

      const fp = buildFingerprint(session.id);
      const nonce = String((BigInt(Date.now() - 1420070400000) << 22n) + BigInt(Math.floor(Math.random() * 4194304)));
      const content = buildContent(message.trim());

      // Smart jitter — randomise timing slightly so sends don't cluster
      if (smartMode && safeDelay > 0) {
        const jitter = Math.floor(Math.random() * Math.min(safeDelay * 0.3, 200));
        await new Promise<void>(r => setTimeout(r, jitter));
      }

      const discordRes = await fetch(`https://discord.com/api/v9/channels/${channelId}/messages`, {
        method: 'POST',
        headers: {
          Authorization: session.token,
          'Content-Type': 'application/json',
          'User-Agent': fp.ua,
          'X-Discord-Locale': fp.locale,
          'X-Discord-Timezone': fp.tz,
          'X-Super-Properties': fp.superProps,
          'X-Debug-Options': 'bugReporterEnabled',
          Accept: '*/*',
          'Accept-Language': `${fp.locale},en;q=0.9`,
          Origin: 'https://discord.com',
          Referer: `https://discord.com/channels/${guildId}/${channelId}`,
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-origin',
          Connection: 'keep-alive',
        },
        body: JSON.stringify({ content, nonce, tts: false, flags: 0 }),
      });

      if (discordRes.status === 429) {
        const body = await discordRes.json().catch(() => ({})) as { retry_after?: number; global?: boolean };
        const retryAfterMs = Math.ceil((body.retry_after ?? 1) * 1000) + 200;
        rateLimitUntil.set(session.id, Date.now() + retryAfterMs);
        send({ type: 'ratelimit', botId: session.id, channelId, wait: retryAfterMs, global: body.global });
        // Retry once after cooldown
        await new Promise<void>(r => setTimeout(r, retryAfterMs));
        if (job.cancel) return false;
        return sendToChannel(session, channelId);
      }

      if (!discordRes.ok) {
        const err = await discordRes.json().catch(() => ({})) as { message?: string };
        const errMsg = err?.message ?? `HTTP ${discordRes.status}`;
        totalErrors++;
        send({ type: 'error', botId: session.id, botName: session.toPublic().username, channelId, error: errMsg });
        return false;
      }

      totalSent++;
      send({
        type: 'sent',
        botId: session.id,
        botName: session.toPublic().username,
        channelId,
        totalSent,
        totalTarget,
      });
      return true;
    }

    try {
      // HIGH-PERFORMANCE MODE: fire ALL (channel × msgIdx) combos in parallel.
      // Each combo gets its own bot via round-robin so every concurrent send
      // uses a different token — maximum throughput, minimal rate-limit collisions.
      const allTasks: Promise<void>[] = [];
      for (let msgIdx = 0; msgIdx < safeMsgsPerChannel; msgIdx++) {
        for (const channelId of channelIds as string[]) {
          const bot = nextBot();
          // Micro-stagger within each message round only when smartMode + delay
          // to avoid every request hitting Discord at the exact same millisecond.
          const stagger = smartMode && safeDelay > 0
            ? Math.floor(Math.random() * Math.min(safeDelay * 0.15, 150))
            : 0;
          allTasks.push(
            (async () => {
              if (job.cancel) return;
              if (stagger > 0) await new Promise<void>(r => setTimeout(r, stagger));
              await sendToChannel(bot, channelId);
            })()
          );
        }
      }
      await Promise.all(allTasks);
    } finally {
      blastJobs.delete(jobId);
      send({ type: 'done', totalSent, totalErrors, cancelled: job.cancel });
      res.end();
    }
  }),
);

/**
 * POST /api/spammer/blast-kill
 * Body: { jobId }
 * Cancels a running blast job.
 */
api.post(
  '/spammer/blast-kill',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseSpammer) {
      res.status(403).json({ error: 'Your access key does not have permission to use the spammer' });
      return;
    }
    const { jobId } = req.body ?? {};
    if (!jobId) { res.status(400).json({ error: 'jobId required' }); return; }
    const job = blastJobs.get(String(jobId));
    if (!job) { res.json({ ok: false, reason: 'job not found or already done' }); return; }
    job.cancel = true;
    res.json({ ok: true });
  }),
);

// ------------------------------------------------------------------ monitor

function avatarUrlLocal(userId: string | null, hash: string | null | undefined, size = 128): string | null {
  if (!userId || !hash) return null;
  const ext = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/avatars/${userId}/${hash}.${ext}?size=${size}`;
}
function guildMemberAvatarUrlLocal(guildId: string, userId: string, hash: string | null | undefined, size = 128): string | null {
  if (!hash) return null;
  const ext = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/guilds/${guildId}/users/${userId}/avatars/${hash}.${ext}?size=${size}`;
}
function iconUrlLocal(guildId: string, hash: string | null | undefined): string | null {
  if (!hash) return null;
  const ext = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/icons/${guildId}/${hash}.${ext}?size=64`;
}

/**
 * GET /api/monitor/user-search?q=...
 * Searches members cached by ALL connected bot sessions across every guild.
 */
api.get(
  '/monitor/user-search',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can search server members' });
      return;
    }
    if (!radarRateLimit(req, res)) return;

    const query = String(req.query.q ?? '').trim().toLocaleLowerCase();
    if (query.length < 2 || query.length > 32) {
      res.status(400).json({ error: 'Search must be between 2 and 32 characters' });
      return;
    }

    const matches = new Map<string, {
      userId: string;
      username: string;
      globalName: string | null;
      nickname: string | null;
      avatarUrl: string | null;
      guildId: string;
      guildName: string;
      guildIconUrl: string | null;
    }>();

    // Scan ALL online sessions (all bots) — no early break across sessions so every
    // bot's guild cache is fully searched. Dedup key = userId:guildId so the same
    // member in the same server never appears twice even when multiple bots share it.
    for (const session of manager.list()) {
      if (session.status !== 'online' || !(session as any).client) continue;
      const client = (session as any).client;
      for (const guild of client.guilds?.cache?.values?.() ?? []) {
        for (const member of guild.members?.cache?.values?.() ?? []) {
          const user = member.user;
          if (!user?.id) continue;

          const username = String(user.username ?? '');
          const globalName = user.globalName ?? user.global_name ?? null;
          const nickname = member.nickname ?? null;
          const matchesQuery = [username, globalName, nickname]
            .some((name) => typeof name === 'string' && name.toLocaleLowerCase().includes(query));
          if (!matchesQuery) continue;

          const key = `${user.id}:${guild.id}`;
          if (matches.has(key)) continue;
          matches.set(key, {
            userId: user.id,
            username,
            globalName,
            nickname,
            avatarUrl:
              guildMemberAvatarUrlLocal(guild.id, user.id, member.avatar, 64) ??
              avatarUrlLocal(user.id, user.avatar, 64),
            guildId: guild.id,
            guildName: guild.name ?? 'Unknown server',
            guildIconUrl: iconUrlLocal(guild.id, guild.icon),
          });
        }
      }
    }

    // Caches only hold a fraction of each server: ALL tokens also search their own
    // servers in parallel (max 1.5s); late results fill the cache for the next search.
    await searchAllTokens(
      manager.list().filter((s) => s.status === 'online' && (s as any).client) as any[],
      query,
      1_500,
      (guild: any, member: any) => {
        const user = member?.user;
        if (!user?.id) return;
        const key = `${user.id}:${guild.id}`;
        if (matches.has(key)) return;
        matches.set(key, {
          userId: user.id,
          username: String(user.username ?? ''),
          globalName: user.globalName ?? user.global_name ?? null,
          nickname: member.nickname ?? null,
          avatarUrl:
            guildMemberAvatarUrlLocal(guild.id, user.id, member.avatar, 64) ??
            avatarUrlLocal(user.id, user.avatar, 64),
          guildId: guild.id,
          guildName: guild.name ?? 'Unknown server',
          guildIconUrl: iconUrlLocal(guild.id, guild.icon),
        });
      },
    );

    const results = [...matches.values()]
      .sort((a, b) => {
        const aExact = [a.username, a.globalName, a.nickname]
          .some((name) => name?.toLocaleLowerCase() === query);
        const bExact = [b.username, b.globalName, b.nickname]
          .some((name) => name?.toLocaleLowerCase() === query);
        // Exact match first, then starts-with, then alphabetical
        const aStarts = !aExact && [a.username, a.globalName, a.nickname]
          .some((name) => name?.toLocaleLowerCase().startsWith(query));
        const bStarts = !bExact && [b.username, b.globalName, b.nickname]
          .some((name) => name?.toLocaleLowerCase().startsWith(query));
        return Number(bExact) - Number(aExact) ||
          Number(bStarts) - Number(aStarts) ||
          (a.globalName ?? a.username).localeCompare(b.globalName ?? b.username);
      })
      .slice(0, 50);

    res.json(results);
  }),
);

/**
 * GET /api/monitor/guilds
 * Returns all guilds visible to any online session.
 */
api.get(
  '/monitor/guilds',
  handle(async (req, res) => {
    // Monitor is owner-only — it exposes full guild/member/message data
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can access the server monitor' });
      return;
    }
    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
    if (online.length === 0) {
      res.json([]);
      return;
    }
    const seen = new Map<string, { id: string; name: string; iconUrl: string | null }>();
    for (const session of online) {
      const client = (session as any).client;
      if (!client?.guilds?.cache) continue;
      for (const guild of client.guilds.cache.values()) {
        const g = guild as any;
        if (!seen.has(g.id)) {
          seen.set(g.id, {
            id: g.id,
            name: g.name ?? 'Unknown',
            iconUrl: iconUrlLocal(g.id, g.icon),
            memberCount: (g.memberCount ?? g.approximateMemberCount ?? null) as number | null,
          } as { id: string; name: string; iconUrl: string | null; memberCount: number | null });
        }
      }
    }
    res.json([...seen.values()].sort((a, b) => a.name.localeCompare(b.name)));
  }),
);

/**
 * GET /api/monitor/guilds/:guildId
 * Returns guild info + all channels (text + voice) with voice member lists.
 * Falls back to REST API when the Discord.js channel cache is empty/partial.
 */
api.get(
  '/monitor/guilds/:guildId',
  handle(async (req, res) => {
    if (!canUseRadarDetails(req.auth)) {
      res.status(403).json({ error: 'Your access key does not have permission to view server details' });
      return;
    }
    const { guildId } = req.params;
    if (!checkGuildAllowed(guildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to view that server' });
      return;
    }
    if (!isSnowflake(guildId)) {
      res.status(400).json({ error: 'guildId must be a valid snowflake' });
      return;
    }

    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
    let targetGuild: any = null;
    let usedSession: typeof online[number] | null = null;
    const visibleGuildSessions: typeof online = [];

    for (const session of online) {
      const client = (session as any).client;
      const g = client?.guilds?.cache?.get(guildId);
      if (!g) continue;
      visibleGuildSessions.push(session);
      const currentChannelCount = targetGuild?.channels?.cache?.size ?? 0;
      const channelCount = g.channels?.cache?.size ?? 0;
      if (!targetGuild || channelCount > currentChannelCount) {
        targetGuild = g;
        usedSession = session;
      }
    }

    if (!targetGuild) {
      res.status(404).json({ error: 'Server not found or not visible to any bot' });
      return;
    }

    // Build a channel-id → parent-name map from the cache (categories are type 4)
    const parentNames = new Map<string, string>();
    for (const ch of targetGuild.channels.cache.values()) {
      const c = ch as any;
      if (c.type === 4) parentNames.set(c.id, c.name ?? '');
    }

    // Helper: resolve voice members for a channel from the guild voiceStates cache
    const voiceMembersForChannel = (channelId: string): any[] => {
      const members = new Map<string, any>();
      for (const session of visibleGuildSessions) {
        const guild = (session as any).client.guilds.cache.get(guildId);
        if (!guild?.voiceStates?.cache) continue;
        for (const vs of guild.voiceStates.cache.values()) {
          const state = vs as any;
          const stateChannelId: string | null = state.channelId ?? state.channel?.id ?? null;
          if (stateChannelId !== channelId) continue;
          const user = state.member?.user ?? state.user ?? {};
          const m = state.member ?? {};
          const userId = user.id ?? state.id ?? state.userId ?? '';
          if (!userId) continue;
          members.set(userId, {
            userId,
            username: user.username ?? m.displayName ?? 'Unknown',
            globalName: user.globalName ?? user.global_name ?? m.nickname ?? null,
            avatarUrl: avatarUrlLocal(userId, user.avatar ?? m.avatar, 64),
            selfMute: Boolean(state.selfMute ?? state.self_mute),
            selfDeaf: Boolean(state.selfDeaf ?? state.self_deaf),
            serverMute: Boolean(state.serverMute ?? state.server_mute),
            serverDeaf: Boolean(state.serverDeaf ?? state.server_deaf),
          });
        }
      }
      return [...members.values()];
    };

    const channels: any[] = [];
    let channelsComplete = false;
    let channelsWarning: string | null = null;
    const fetchCompleteChannels = async () => {
      let lastError: unknown;
      for (const session of visibleGuildSessions) {
        try {
          return await fetchGuildChannels(session.token, guildId, session.id);
        } catch (error) {
          lastError = error;
          logs.push(`Monitor: REST channel fetch failed for guild ${guildId}: ${errorMessage(error)}`, 'error');
        }
      }
      if (lastError) throw lastError;
      throw new Error('No connected account is available to refresh this server channel list.');
    };

    // Check if the cache has useful channel data (text + voice channels)
    const cachedChannels = [...targetGuild.channels.cache.values()] as any[];
    const cachedUsable = cachedChannels.filter((c: any) =>
      [0, 2, 5, 13, 15, 16].includes(c.type),
    );

    if (cachedUsable.length > 0) {
      // Use cache — it has real channel data
      for (const channel of cachedUsable) {
        const ch = channel as any;
        const channelType = [0, 5, 15, 16].includes(ch.type) ? 'text' : ch.type === 13 ? 'stage' : 'voice';
        const parentName = ch.parent?.name ?? parentNames.get(ch.parentId ?? '') ?? null;

        const entry: any = {
          id: ch.id,
          name: ch.name ?? 'unknown',
          type: channelType,
          parentName,
        };

        if (channelType !== 'text') {
          let members: any[] = [];

          // Try VoiceChannel.members (populated when GuildMembers intent active)
          if (ch.members && typeof ch.members.values === 'function' && ch.members.size > 0) {
            for (const member of ch.members.values()) {
              const m = member as any;
              const user = m.user ?? {};
              const vs = m.voice ?? {};
              members.push({
                userId: user.id ?? m.id ?? '',
                username: user.username ?? m.displayName ?? 'Unknown',
                globalName: user.globalName ?? user.global_name ?? m.nickname ?? null,
                avatarUrl: avatarUrlLocal(user.id ?? m.id, user.avatar ?? m.avatar, 64),
                selfMute: Boolean(vs.selfMute ?? vs.self_mute),
                selfDeaf: Boolean(vs.selfDeaf ?? vs.self_deaf),
                serverMute: Boolean(vs.serverMute ?? vs.server_mute),
                serverDeaf: Boolean(vs.serverDeaf ?? vs.server_deaf),
              });
            }
          }

          // Always also check voiceStates cache — it's more reliably populated
          // for selfbots and merge any entries not already found via .members
          const fromStates = voiceMembersForChannel(ch.id);
          const seen = new Set(members.map((m: any) => m.userId));
          for (const m of fromStates) {
            if (!seen.has(m.userId)) { members.push(m); seen.add(m.userId); }
          }

          entry.memberCount = members.length;
          entry.members = members;
        }

        channels.push(entry);
      }
    } else {
      // Cache is empty — fall back to REST API to get channel list
      if (usedSession) {
        try {
          const raw = await fetchCompleteChannels();
          channelsComplete = true;
          const usable = raw.filter((c) => [0, 2, 5, 13, 15, 16].includes(c.type));

          // Build parent name map from REST response
          const restParentNames = new Map<string, string>();
          for (const c of raw) {
            if ((c as any).type === 4) restParentNames.set(c.id, c.name ?? '');
          }

          for (const ch of usable) {
            const channelType = [0, 5, 15, 16].includes(ch.type) ? 'text' : ch.type === 13 ? 'stage' : 'voice';
            const parentName = ch.parent_id ? (restParentNames.get(ch.parent_id) ?? null) : null;

            const entry: any = {
              id: ch.id,
              name: ch.name ?? 'unknown',
              type: channelType,
              parentName,
            };

            if (channelType !== 'text') {
              // For voice channels from REST, check voiceStates cache for members
              const members = voiceMembersForChannel(ch.id);
              entry.memberCount = members.length;
              entry.members = members;
            }

            channels.push(entry);
          }
        } catch (err) {
          channelsWarning = 'Some channel information could not be refreshed from Discord.';
        }
      }
    }

    // A non-empty local cache can still be partial. Refresh the channel list and
    // merge it with cached voice states instead of treating cache presence as completeness.
    if (cachedUsable.length > 0 && usedSession) {
      try {
        const raw = await fetchCompleteChannels();
        const parentNamesFromRest = new Map(
          raw.filter((channel) => channel.type === 4).map((channel) => [channel.id, channel.name]),
        );
        const merged = new Map<string, any>(channels.map((channel) => [channel.id, channel]));
        for (const channel of raw) {
          if (![0, 2, 5, 13, 15, 16].includes(channel.type)) continue;
          const type = [0, 5, 15, 16].includes(channel.type) ? 'text' : channel.type === 13 ? 'stage' : 'voice';
          const existing = merged.get(channel.id);
          const members = type === 'text'
            ? undefined
            : existing?.members ?? voiceMembersForChannel(channel.id);
          merged.set(channel.id, {
            id: channel.id,
            name: channel.name || existing?.name || 'unknown',
            type,
            parentName: channel.parent_id
              ? parentNamesFromRest.get(channel.parent_id) ?? existing?.parentName ?? null
              : existing?.parentName ?? null,
            ...(type !== 'text' ? { members, memberCount: members.length } : {}),
          });
        }
        channels.splice(0, channels.length, ...merged.values());
        channelsComplete = true;
        channelsWarning = null;
      } catch (err) {
        channelsWarning = 'Showing cached channels; Discord could not refresh the complete channel list.';
      }
    }

    // Sort: by parent name then channel name
    channels.sort((a, b) => {
      const pa = a.parentName ?? '';
      const pb = b.parentName ?? '';
      if (pa !== pb) return pa.localeCompare(pb);
      return a.name.localeCompare(b.name);
    });

    res.json({
      id: targetGuild.id,
      name: targetGuild.name,
      iconUrl: iconUrlLocal(targetGuild.id, targetGuild.icon),
      memberCount: targetGuild.memberCount ?? targetGuild.approximateMemberCount ?? null,
      channels,
      channelsComplete,
      channelsWarning,
    });
  }),
);

/**
 * GET /api/monitor/guilds/:guildId/member-roles?userId=X
 * Returns the roles of a member in a guild.
 */
api.get(
  '/monitor/guilds/:guildId/member-roles',
  handle(async (req, res) => {
    if (!canUseRadarDetails(req.auth)) {
      res.status(403).json({ error: 'Your access key does not have permission to view server details' });
      return;
    }
    const { guildId } = req.params;
    if (!checkGuildAllowed(guildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to view that server' });
      return;
    }
    const userId = String(req.query.userId ?? '').trim();

    if (!isSnowflake(guildId) || !isSnowflake(userId)) {
      res.status(400).json({ error: 'guildId and userId must be valid snowflakes' });
      return;
    }

    const guildSessions = manager.list().filter((session) => {
      if (session.status !== 'online' || !(session as any).client) return false;
      return Boolean((session as any).client.guilds?.cache?.get(guildId));
    });
    if (guildSessions.length === 0) {
      res.status(404).json({ error: 'Server not found or not visible to any bot' });
      return;
    }

    const targetGuild = (guildSessions[0] as any).client.guilds.cache.get(guildId);
    let member: any = null;
    for (const session of guildSessions) {
      const cachedMember = (session as any).client.guilds.cache.get(guildId).members?.cache?.get(userId);
      if (cachedMember) {
        member = cachedMember;
        break;
      }
    }

    if (!member) {
      const lookupErrors: string[] = [];
      let confirmedNotFound = false;
      for (const session of guildSessions) {
        try {
          member = await fetchGuildMember(session.token, guildId, userId, session.id);
          break;
        } catch (error) {
          const status = typeof error === 'object' && error !== null && 'status' in error
            ? Number((error as { status: unknown }).status)
            : 0;
          if (status === 404) {
            confirmedNotFound = true;
            continue;
          }
          lookupErrors.push(errorMessage(error));
          logs.push(`Radar: member refresh failed for guild ${guildId}: ${errorMessage(error)}`, 'error');
        }
      }
      if (!member && lookupErrors.length > 0) {
        res.status(502).json({ error: 'Discord could not refresh this member. Try again or check the connected account access.' });
        return;
      }
      if (!member) {
        res.status(404).json({
          error: confirmedNotFound
            ? 'This user is not a member of the selected server.'
            : 'Member details are unavailable from the connected accounts.',
        });
        return;
      }
    }

    const m = member as any;
    const memberRoleIds: string[] = m.roles?.cache
      ? [...m.roles.cache.keys()]
      : Array.isArray(m.roles)
        ? m.roles
        : [];
    const roles: Array<{
      id: string; name: string; color: string | null; position: number; hoist: boolean;
      administrator: boolean; elevated: boolean;
    }> = [];
    const roleCache = targetGuild.roles?.cache;
    const ADMIN_BIT = BigInt(1) << BigInt(3);
    // Kick, Ban, Manage Channels, Manage Guild, Manage Messages, Manage Roles, Moderate Members
    const ELEVATED_BITS = [1, 2, 4, 5, 13, 28, 40].reduce((acc, n) => acc | (BigInt(1) << BigInt(n)), BigInt(0));
    for (const roleId of memberRoleIds) {
      const role = roleCache?.get(roleId);
      if (!role || role.name === '@everyone') continue;
      const r = role as any;
      const bits = r.permissions?.bitfield !== undefined ? BigInt(r.permissions.bitfield.toString()) : BigInt(0);
      roles.push({
        id: r.id,
        name: r.name ?? 'Unknown Role',
        color: r.color ? `#${r.color.toString(16).padStart(6, '0')}` : null,
        position: r.position ?? 0,
        hoist: Boolean(r.hoist),
        administrator: (bits & ADMIN_BIT) === ADMIN_BIT,
        elevated: (bits & ELEVATED_BITS) !== BigInt(0),
      });
    }
    roles.sort((a, b) => b.position - a.position);

    const user = m.user ?? {};
    const joinedAt = m.joinedAt ? new Date(m.joinedAt).getTime()
      : m.joined_at ? new Date(m.joined_at).getTime()
        : null;
    res.json({
      userId,
      guildId,
      guildName: targetGuild.name,
      nickname: m.nickname ?? m.nick ?? null,
      avatarUrl:
        guildMemberAvatarUrlLocal(guildId, userId, m.avatar, 128) ??
        avatarUrlLocal(userId, user.avatar, 128),
      joinedAt,
      isOwner: String(targetGuild.ownerId ?? '') === userId,
      roles,
    });
  }),
);

/**
 * GET /api/monitor/messages?channelId=X&botId=Y&limit=30
 * Fetches recent messages from a text channel via Discord REST.
 */
api.get(
  '/monitor/messages',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can access the server monitor' });
      return;
    }
    const channelId = String(req.query.channelId ?? '').trim();
    const botId = String(req.query.botId ?? '').trim();
    const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit ?? '30'), 10) || 30));

    if (!isSnowflake(channelId)) {
      res.status(400).json({ error: 'channelId must be a valid snowflake' });
      return;
    }

    const online = manager.list().filter((s) => s.status === 'online');
    if (online.length === 0) {
      res.status(503).json({ error: 'No online bots' });
      return;
    }

    // Pick the requested bot or the first online one
    let session = botId ? online.find((s) => s.id === botId) : null;
    if (!session) session = online[0];
    if (!session) {
      res.status(503).json({ error: 'No suitable bot available' });
      return;
    }

    const discordRes = await fetch(
      `https://discord.com/api/v9/channels/${channelId}/messages?limit=${limit}`,
      {
        headers: {
          Authorization: session.token,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'X-Super-Properties': Buffer.from(
            JSON.stringify({ os: 'Windows', browser: 'Discord', release_channel: 'stable' }),
          ).toString('base64'),
        },
      },
    );

    if (!discordRes.ok) {
      const text = await discordRes.text().catch(() => '');
      res.status(discordRes.status).json({ error: `Discord API error: ${text || discordRes.status}` });
      return;
    }

    const raw: any[] = await discordRes.json();

    const messages = raw.map((m: any) => ({
      id: m.id,
      channelId,
      authorId: m.author?.id ?? '',
      authorName: m.author?.global_name ?? m.author?.username ?? 'Unknown',
      authorAvatar: m.author?.id && m.author?.avatar
        ? avatarUrlLocal(m.author.id, m.author.avatar, 64)
        : null,
      content: m.content ?? '',
      timestamp: new Date(m.timestamp).getTime(),
      reactions: Array.isArray(m.reactions)
        ? m.reactions.map((r: any) => ({
            emoji: r.emoji?.id
              ? `<:${r.emoji.name}:${r.emoji.id}>`
              : (r.emoji?.name ?? '?'),
            count: r.count ?? 0,
            me: Boolean(r.me),
          }))
        : [],
    }));

    res.json(messages);
  }),
);

/**
 * GET /api/monitor/channel-lookup?channelId=X
 * Looks up a channel by ID across all online bots — returns type, name, guild,
 * voice members (if voice) or recent messages (if text).
 */
api.get(
  '/monitor/channel-lookup',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can access the server monitor' });
      return;
    }
    const channelId = String(req.query.channelId ?? '').trim();
    const botId = String(req.query.botId ?? '').trim();

    if (!isSnowflake(channelId)) {
      res.status(400).json({ error: 'channelId must be a valid Discord snowflake' });
      return;
    }

    // Try to find the channel in any online bot's guild cache first
    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);

    let foundChannel: any = null;
    let foundGuild: any = null;

    for (const session of online) {
      const client = (session as any).client;
      if (!client?.guilds?.cache) continue;
      for (const guild of client.guilds.cache.values()) {
        const g = guild as any;
        const ch = g.channels?.cache?.get(channelId);
        if (ch) {
          foundChannel = ch;
          foundGuild = g;
          break;
        }
      }
      if (foundChannel) break;
    }

    if (!foundChannel) {
      // Channel not in cache — try REST to discover it
      const onlineSessions = manager.list().filter((s) => s.status === 'online');
      if (onlineSessions.length === 0) {
        res.status(503).json({ error: 'No online bots to look up channel' });
        return;
      }
      let session = botId ? onlineSessions.find((s) => s.id === botId) : null;
      if (!session) session = onlineSessions[0];

      const discordRes = await fetch(`https://discord.com/api/v9/channels/${channelId}`, {
        headers: {
          Authorization: session!.token,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'X-Super-Properties': Buffer.from(
            JSON.stringify({ os: 'Windows', browser: 'Discord', release_channel: 'stable' }),
          ).toString('base64'),
        },
      });

      if (!discordRes.ok) {
        res.status(404).json({ error: 'Channel not found or bot has no access' });
        return;
      }

      const ch: any = await discordRes.json();
      // type 0 = text, 2 = voice, 13 = stage
      const channelType = ch.type === 0 ? 'text' : ch.type === 2 ? 'voice' : ch.type === 13 ? 'stage' : 'unknown';

      if (channelType === 'unknown') {
        res.status(400).json({ error: 'Unsupported channel type' });
        return;
      }

      // For text channels fetch messages via REST
      if (channelType === 'text') {
        const msgRes = await fetch(
          `https://discord.com/api/v9/channels/${channelId}/messages?limit=30`,
          {
            headers: {
              Authorization: session!.token,
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'X-Super-Properties': Buffer.from(
                JSON.stringify({ os: 'Windows', browser: 'Discord', release_channel: 'stable' }),
              ).toString('base64'),
            },
          },
        );
        const messages = msgRes.ok
          ? ((await msgRes.json()) as any[]).map((m: any) => ({
              id: m.id,
              channelId,
              authorId: m.author?.id ?? '',
              authorName: m.author?.global_name ?? m.author?.username ?? 'Unknown',
              authorAvatar:
                m.author?.id && m.author?.avatar
                  ? avatarUrlLocal(m.author.id, m.author.avatar, 64)
                  : null,
              content: m.content ?? '',
              timestamp: new Date(m.timestamp).getTime(),
              reactions: Array.isArray(m.reactions)
                ? m.reactions.map((r: any) => ({
                    emoji: r.emoji?.id ? `<:${r.emoji.name}:${r.emoji.id}>` : (r.emoji?.name ?? '?'),
                    count: r.count ?? 0,
                    me: Boolean(r.me),
                  }))
                : [],
            }))
          : [];
        res.json({
          id: channelId,
          name: ch.name ?? 'Unknown',
          type: channelType,
          guildId: ch.guild_id ?? null,
          guildName: null,
          messages,
          members: [],
        });
        return;
      }

      // voice/stage via REST — try voiceStates cache for member list
      const voiceGuildId: string | null = ch.guild_id ?? null;
      const voiceMembers: any[] = [];

      if (voiceGuildId) {
        // Find the guild in any online bot's cache and pull voiceStates
        for (const sess of online) {
          const client = (sess as any).client;
          const g = client?.guilds?.cache?.get(voiceGuildId) as any;
          if (!g?.voiceStates?.cache) continue;
          for (const vs of g.voiceStates.cache.values()) {
            const state = vs as any;
            const stCh: string | null = state.channelId ?? state.channel?.id ?? null;
            if (stCh !== channelId) continue;
            const user = state.member?.user ?? state.user ?? {};
            const m = state.member ?? {};
            voiceMembers.push({
              userId: user.id ?? state.id ?? state.userId ?? '',
              username: user.username ?? m.displayName ?? 'Unknown',
              globalName: user.globalName ?? user.global_name ?? m.nickname ?? null,
              avatarUrl: avatarUrlLocal(user.id ?? state.id ?? state.userId, user.avatar ?? m.avatar, 64),
              selfMute: Boolean(state.selfMute ?? state.self_mute),
              selfDeaf: Boolean(state.selfDeaf ?? state.self_deaf),
              serverMute: Boolean(state.serverMute ?? state.server_mute),
              serverDeaf: Boolean(state.serverDeaf ?? state.server_deaf),
            });
          }
          if (voiceMembers.length > 0) break;
        }
      }

      res.json({
        id: channelId,
        name: ch.name ?? 'Unknown',
        type: channelType,
        guildId: voiceGuildId,
        guildName: null,
        messages: [],
        members: voiceMembers,
      });
      return;
    }

    // Found in cache — rich data available
    const channelType = foundChannel.type === 0 ? 'text' : foundChannel.type === 13 ? 'stage' : 'voice';

    const result: any = {
      id: channelId,
      name: foundChannel.name ?? 'Unknown',
      type: channelType,
      guildId: foundGuild?.id ?? null,
      guildName: foundGuild?.name ?? null,
      messages: [],
      members: [],
    };

    if (channelType !== 'text') {
      // Voice/stage: pull members from cache
      const members: any[] = [];
      const seenUserIds = new Set<string>();

      // Try VoiceChannel.members first (may be empty if GuildMembers intent not active)
      if (foundChannel.members && typeof foundChannel.members.values === 'function') {
        for (const member of foundChannel.members.values()) {
          const m = member as any;
          const user = m.user ?? m;
          const voiceState = m.voice ?? {};
          const uid = user.id ?? '';
          if (uid) seenUserIds.add(uid);
          members.push({
            userId: uid,
            username: user.username ?? 'Unknown',
            globalName: user.globalName ?? user.global_name ?? null,
            avatarUrl: avatarUrlLocal(uid, user.avatar, 64),
            selfMute: Boolean(voiceState.selfMute),
            selfDeaf: Boolean(voiceState.selfDeaf),
            serverMute: Boolean(voiceState.serverMute),
            serverDeaf: Boolean(voiceState.serverDeaf),
          });
        }
      }

      // Also check voiceStates cache on the guild — more reliably populated for selfbots
      if (foundGuild?.voiceStates?.cache) {
        for (const vs of foundGuild.voiceStates.cache.values()) {
          const state = vs as any;
          const stCh: string | null = state.channelId ?? state.channel?.id ?? null;
          if (stCh !== channelId) continue;
          const user = state.member?.user ?? state.user ?? {};
          const m = state.member ?? {};
          const uid: string = user.id ?? state.id ?? state.userId ?? '';
          if (!uid || seenUserIds.has(uid)) continue;
          seenUserIds.add(uid);
          members.push({
            userId: uid,
            username: user.username ?? m.displayName ?? 'Unknown',
            globalName: user.globalName ?? user.global_name ?? m.nickname ?? null,
            avatarUrl: avatarUrlLocal(uid, user.avatar ?? m.avatar, 64),
            selfMute: Boolean(state.selfMute ?? state.self_mute),
            selfDeaf: Boolean(state.selfDeaf ?? state.self_deaf),
            serverMute: Boolean(state.serverMute ?? state.server_mute),
            serverDeaf: Boolean(state.serverDeaf ?? state.server_deaf),
          });
        }
      }

      result.members = members;
    } else {
      // Text: fetch messages via REST using the first available bot in that guild
      const onlineSessions = manager.list().filter((s) => s.status === 'online');
      let session = botId ? onlineSessions.find((s) => s.id === botId) : null;
      if (!session) session = onlineSessions[0];
      if (session) {
        const msgRes = await fetch(
          `https://discord.com/api/v9/channels/${channelId}/messages?limit=30`,
          {
            headers: {
              Authorization: session.token,
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
              'X-Super-Properties': Buffer.from(
                JSON.stringify({ os: 'Windows', browser: 'Discord', release_channel: 'stable' }),
              ).toString('base64'),
            },
          },
        );
        if (msgRes.ok) {
          result.messages = ((await msgRes.json()) as any[]).map((m: any) => ({
            id: m.id,
            channelId,
            authorId: m.author?.id ?? '',
            authorName: m.author?.global_name ?? m.author?.username ?? 'Unknown',
            authorAvatar:
              m.author?.id && m.author?.avatar
                ? avatarUrlLocal(m.author.id, m.author.avatar, 64)
                : null,
            content: m.content ?? '',
            timestamp: new Date(m.timestamp).getTime(),
            reactions: Array.isArray(m.reactions)
              ? m.reactions.map((r: any) => ({
                  emoji: r.emoji?.id ? `<:${r.emoji.name}:${r.emoji.id}>` : (r.emoji?.name ?? '?'),
                  count: r.count ?? 0,
                  me: Boolean(r.me),
                }))
              : [],
          }));
        }
      }
    }

    res.json(result);
  }),
);


/**
 * GET /api/monitor/guilds/:guildId/roles/:roleId/members
 * Returns all cached members that have a specific role.
 */
api.get(
  '/monitor/guilds/:guildId/roles/:roleId/members',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can access the server monitor' });
      return;
    }
    const { guildId, roleId } = req.params;
    if (!isSnowflake(guildId) || !isSnowflake(roleId)) {
      res.status(400).json({ error: 'guildId and roleId must be valid snowflakes' });
      return;
    }

    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
    let targetGuild: any = null;

    for (const session of online) {
      const client = (session as any).client;
      const g = client?.guilds?.cache?.get(guildId);
      if (g) { targetGuild = g; break; }
    }

    if (!targetGuild) {
      res.status(404).json({ error: 'Server not found or not visible to any bot' });
      return;
    }

    const role = targetGuild.roles?.cache?.get(roleId);
    if (!role) {
      res.status(404).json({ error: 'Role not found' });
      return;
    }

    const members: any[] = [];
    const r = role as any;

    // Prefer role.members Collection — populated from the full guild member list
    // when GUILD_MEMBERS intent is active. Falls back to scanning the local cache.
    const memberSource: Iterable<any> =
      (r.members && typeof r.members.values === 'function' && r.members.size > 0)
        ? r.members.values()
        : (targetGuild.members?.cache
            ? ([...targetGuild.members.cache.values()].filter((m: any) =>
                m.roles?.cache?.has(roleId)
              ) as any[])
            : []);

    for (const member of memberSource) {
      const m = member as any;
      // When iterating role.members, each item IS a GuildMember.
      // When iterating filtered cache, same thing.
      const user = m.user ?? {};
      const vs = m.voice ?? {};
      members.push({
        userId: user.id ?? m.id ?? '',
        username: user.username ?? m.displayName ?? 'Unknown',
        globalName: user.globalName ?? user.global_name ?? m.nickname ?? null,
        avatarUrl: avatarUrlLocal(user.id ?? m.id, user.avatar, 64),
        nickname: m.nickname ?? null,
        joinedAt: m.joinedAt ? new Date(m.joinedAt).getTime() : null,
        inVoice: Boolean(vs.channelId),
        voiceChannelName: vs.channel?.name ?? null,
      });
    }

    members.sort((a, b) => (a.username ?? '').localeCompare(b.username ?? ''));

    // Real total: from role.members.size (accurate) or Discord REST API count
    const realTotal: number = (r.members?.size != null) ? r.members.size : members.length;

    res.json({
      roleId,
      roleName: r.name,
      roleColor: r.color ? '#' + r.color.toString(16).padStart(6, '0') : null,
      guildId,
      guildName: targetGuild.name,
      total: realTotal,
      members,
    });
  }),
);
/**
 * POST /api/monitor/react
 * Body: { channelId, messageId, emoji, botIds }
 * Adds a reaction to a message using the specified bots.
 */
api.post(
  '/monitor/react',
  handle(async (req, res) => {
    // Only owner or keys with canUseAutoReact may trigger reactions
    if (req.auth?.role !== 'owner' && !req.auth?.key?.permissions.canUseAutoReact) {
      res.status(403).json({ error: 'Your access key does not have permission to add reactions' });
      return;
    }
    const { channelId, messageId, emoji, botIds } = req.body ?? {};

    if (typeof channelId !== 'string' || !isSnowflake(channelId)) {
      res.status(400).json({ error: 'channelId must be a valid snowflake' });
      return;
    }
    if (typeof messageId !== 'string' || !isSnowflake(messageId)) {
      res.status(400).json({ error: 'messageId must be a valid snowflake' });
      return;
    }
    if (typeof emoji !== 'string' || !emoji.trim()) {
      res.status(400).json({ error: 'emoji is required' });
      return;
    }
    if (!Array.isArray(botIds) || botIds.length === 0) {
      res.status(400).json({ error: 'botIds must be a non-empty array' });
      return;
    }

    // URL-encode emoji for Discord API
    const encodedEmoji = encodeURIComponent(emoji.trim());

    let sent = 0;
    const errors: string[] = [];

    // Filter botIds by key scope for user keys
    let allowedBotIds: string[] = Array.isArray(botIds) ? botIds : [];
    if (req.auth?.role === 'user' && req.auth.key?.permissions.botScope === 'specific') {
      const allowed = new Set(req.auth.key.permissions.assignedBotIds);
      allowedBotIds = allowedBotIds.filter((id) => allowed.has(id));
    }

    await Promise.all(
      allowedBotIds.map(async (id) => {
        const session = manager.get(id);
        if (!session || session.status !== 'online') {
          errors.push(`Bot ${id} not online`);
          return;
        }
        try {
          const r = await fetch(
            `https://discord.com/api/v9/channels/${channelId}/messages/${messageId}/reactions/${encodedEmoji}/@me`,
            {
              method: 'PUT',
              headers: {
                Authorization: session.token,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'X-Super-Properties': Buffer.from(
                  JSON.stringify({ os: 'Windows', browser: 'Discord', release_channel: 'stable' }),
                ).toString('base64'),
              },
            },
          );
          if (r.ok || r.status === 204) {
            sent++;
          } else {
            const txt = await r.text().catch(() => '');
            errors.push(`Bot ${session.username}: ${r.status} ${txt}`);
          }
        } catch (err) {
          errors.push(`Bot ${id}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }),
    );

    res.json({ sent, errors: errors.length > 0 ? errors : undefined });
  }),
);

/**
 * GET /api/monitor/guilds/:guildId/roles
 * Returns all roles in a guild with their permissions.
 */
api.get(
  '/monitor/guilds/:guildId/roles',
  handle(async (req, res) => {
    if (!canUseRadarDetails(req.auth)) {
      res.status(403).json({ error: 'Your access key does not have permission to view server details' });
      return;
    }
    const { guildId } = req.params;
    if (!checkGuildAllowed(guildId, req.auth)) {
      res.status(403).json({ error: 'Your access key is not permitted to view that server' });
      return;
    }
    if (!isSnowflake(guildId)) {
      res.status(400).json({ error: 'guildId must be a valid snowflake' });
      return;
    }

    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
    let targetGuild: any = null;

    for (const session of online) {
      const client = (session as any).client;
      const g = client?.guilds?.cache?.get(guildId);
      if (g) { targetGuild = g; break; }
    }

    if (!targetGuild) {
      res.status(404).json({ error: 'Server not found or not visible to any bot' });
      return;
    }

    const roles: any[] = [];
    if (targetGuild.roles?.cache) {
      for (const role of targetGuild.roles.cache.values()) {
        const r = role as any;

        // Use role.members (Discord.js Collection) if available — it has the real count
        // from the guild's member list, not just the local cache subset.
        let memberCount: number | null = null;
        if (typeof r.members?.size === 'number') {
          // role.members is populated from the full guild member list when
          // GUILD_MEMBERS intent is active (selfbots typically have this)
          memberCount = r.members.size;
        } else if (targetGuild.members?.cache) {
          // fallback: count from local cache (may be partial)
          memberCount = [...targetGuild.members.cache.values()].filter((m: any) =>
            m.roles?.cache?.has(r.id)
          ).length;
        }

        roles.push({
          id: r.id,
          name: r.name ?? 'Unknown Role',
          color: r.color ? `#${r.color.toString(16).padStart(6, '0')}` : null,
          position: r.position ?? 0,
          hoist: Boolean(r.hoist),
          mentionable: Boolean(r.mentionable),
          managed: Boolean(r.managed),
          permissions: r.permissions?.bitfield ? r.permissions.bitfield.toString() : '0',
          permissionNames: r.permissions?.toArray?.() ?? [],
          memberCount,
        });
      }
    }

    roles.sort((a, b) => b.position - a.position);
    res.json({ guildId, guildName: targetGuild.name, roles });
  }),
);

/**
 * GET /api/monitor/guilds/:guildId/member-permissions?userId=X
 * Returns effective permissions of a member in a guild.
 */
api.get(
  '/monitor/guilds/:guildId/member-permissions',
  handle(async (req, res) => {
    if (req.auth?.role !== 'owner') {
      res.status(403).json({ error: 'Only the owner can access the server monitor' });
      return;
    }
    const { guildId } = req.params;
    const userId = String(req.query.userId ?? '').trim();

    if (!isSnowflake(guildId) || !isSnowflake(userId)) {
      res.status(400).json({ error: 'guildId and userId must be valid snowflakes' });
      return;
    }

    const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
    let targetGuild: any = null;

    for (const session of online) {
      const client = (session as any).client;
      const g = client?.guilds?.cache?.get(guildId);
      if (g) { targetGuild = g; break; }
    }

    if (!targetGuild) {
      res.status(404).json({ error: 'Server not found or not visible to any bot' });
      return;
    }

    const member = targetGuild.members?.cache?.get(userId);
    if (!member) {
      res.status(404).json({ error: 'Member not found in this server' });
      return;
    }

    const m = member as any;

    // Compute effective permissions from all roles
    let permBits = BigInt(0);
    const isOwner = targetGuild.ownerId === userId;

    if (isOwner) {
      // Owner has all permissions
      permBits = BigInt('0xFFFFFFFFFFFFFFFF');
    } else if (m.roles?.cache) {
      for (const role of m.roles.cache.values()) {
        const r = role as any;
        const bits = r.permissions?.bitfield;
        if (bits) {
          permBits |= BigInt(bits.toString());
        }
      }
      // Check for administrator
      const ADMINISTRATOR = BigInt(0x8);
      if ((permBits & ADMINISTRATOR) === ADMINISTRATOR) {
        permBits = BigInt('0xFFFFFFFFFFFFFFFF');
      }
    }

    // Decode permission bits
    const PERMISSION_FLAGS: Record<string, bigint> = {
      'Create Instant Invite': BigInt(1) << BigInt(0),
      'Kick Members': BigInt(1) << BigInt(1),
      'Ban Members': BigInt(1) << BigInt(2),
      'Administrator': BigInt(1) << BigInt(3),
      'Manage Channels': BigInt(1) << BigInt(4),
      'Manage Guild': BigInt(1) << BigInt(5),
      'Add Reactions': BigInt(1) << BigInt(6),
      'View Audit Log': BigInt(1) << BigInt(7),
      'Priority Speaker': BigInt(1) << BigInt(8),
      'Stream': BigInt(1) << BigInt(9),
      'View Channel': BigInt(1) << BigInt(10),
      'Send Messages': BigInt(1) << BigInt(11),
      'Send TTS Messages': BigInt(1) << BigInt(12),
      'Manage Messages': BigInt(1) << BigInt(13),
      'Embed Links': BigInt(1) << BigInt(14),
      'Attach Files': BigInt(1) << BigInt(15),
      'Read Message History': BigInt(1) << BigInt(16),
      'Mention Everyone': BigInt(1) << BigInt(17),
      'Use External Emojis': BigInt(1) << BigInt(18),
      'View Guild Insights': BigInt(1) << BigInt(19),
      'Connect': BigInt(1) << BigInt(20),
      'Speak': BigInt(1) << BigInt(21),
      'Mute Members': BigInt(1) << BigInt(22),
      'Deafen Members': BigInt(1) << BigInt(23),
      'Move Members': BigInt(1) << BigInt(24),
      'Use VAD': BigInt(1) << BigInt(25),
      'Change Nickname': BigInt(1) << BigInt(26),
      'Manage Nicknames': BigInt(1) << BigInt(27),
      'Manage Roles': BigInt(1) << BigInt(28),
      'Manage Webhooks': BigInt(1) << BigInt(29),
      'Manage Emojis': BigInt(1) << BigInt(30),
      'Use Application Commands': BigInt(1) << BigInt(31),
      'Request to Speak': BigInt(1) << BigInt(32),
      'Manage Events': BigInt(1) << BigInt(33),
      'Manage Threads': BigInt(1) << BigInt(34),
      'Create Public Threads': BigInt(1) << BigInt(35),
      'Create Private Threads': BigInt(1) << BigInt(36),
      'Use External Stickers': BigInt(1) << BigInt(37),
      'Send Messages in Threads': BigInt(1) << BigInt(38),
      'Use Embedded Activities': BigInt(1) << BigInt(39),
      'Moderate Members': BigInt(1) << BigInt(40),
    };

    const permissions: { name: string; granted: boolean }[] = Object.entries(PERMISSION_FLAGS).map(
      ([name, bit]) => ({ name, granted: (permBits & bit) === bit })
    );

    res.json({
      userId,
      guildId,
      guildName: targetGuild.name,
      nickname: m.nickname ?? null,
      isOwner,
      permissionBits: permBits.toString(),
      permissions,
    });
  }),
);
