/**
 * Optional Supabase persistence and sync adapter for Ghost Voice Control.
 * If SUPABASE_URL and SUPABASE_KEY (or SUPABASE_SERVICE_ROLE_KEY) are configured,
 * access keys and audit logs can be mirrored to Supabase Postgres.
 * If unset, the system uses AES-256-GCM local encrypted storage seamlessly.
 */

import { logs } from './logger.ts';
import type { AccessKey } from '../shared/types.ts';

const SUPABASE_URL = (process.env.SUPABASE_URL ?? '').trim().replace(/\/+$/, '');
const SUPABASE_KEY = (process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_KEY ?? '').trim();

export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_KEY);

export const SUPABASE_SQL_SCHEMA = `-- Ghost Voice Control - Supabase PostgreSQL Schema
-- Run this in your Supabase SQL Editor to enable cloud key syncing:

create table if not exists public.gvc_access_keys (
  id text primary key,
  key text unique not null,
  note text not null default '',
  role text not null default 'user',
  status text not null default 'active',
  created_at bigint not null,
  expires_at bigint,
  duration_ms bigint,
  first_used_at bigint,
  max_uses int,
  used_count int not null default 0,
  permissions jsonb not null default '{}'::jsonb,
  redeemed_users jsonb not null default '[]'::jsonb,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

create index if not exists gvc_access_keys_key_idx on public.gvc_access_keys (key);
create index if not exists gvc_access_keys_status_idx on public.gvc_access_keys (status);

-- Optional Audit Log table
create table if not exists public.gvc_audit_logs (
  id uuid default gen_random_uuid() primary key,
  at timestamp with time zone default timezone('utc'::text, now()),
  event_type text not null,
  details jsonb not null default '{}'::jsonb
);

-- Durable app state (imported accounts, config, keys). The payload column only
-- ever holds AES-256-GCM ciphertext (base64) - tokens are never stored in clear.
create table if not exists public.gvc_state (
  id text primary key default 'main',
  rev bigint not null default 0,
  payload text not null,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Lock every table down: only the service_role key (used by the server) can
-- read/write. With RLS on and no policies, the public anon key gets nothing.
alter table public.gvc_state enable row level security;
alter table public.gvc_access_keys enable row level security;
alter table public.gvc_audit_logs enable row level security;

-- Only the service_role key (used by the server) may touch these tables.
revoke all on table public.gvc_state, public.gvc_access_keys, public.gvc_audit_logs from anon, authenticated, public;
grant all on table public.gvc_state, public.gvc_access_keys, public.gvc_audit_logs to service_role;

-- Rolling backup: the previous encrypted payload is archived on every update
-- (last 30 kept), so a bad write can never destroy the saved accounts.
create table if not exists public.gvc_state_history (
  hid bigserial primary key,
  state_id text not null,
  rev bigint not null,
  payload text not null,
  archived_at timestamptz not null default timezone('utc'::text, now())
);
alter table public.gvc_state_history enable row level security;
revoke all on table public.gvc_state_history from anon, authenticated, public;
grant all on table public.gvc_state_history to service_role;
grant usage, select on sequence public.gvc_state_history_hid_seq to service_role;

create or replace function public.gvc_state_archive() returns trigger
language plpgsql security invoker set search_path = public as $$
begin
  if old.payload is distinct from new.payload then
    insert into public.gvc_state_history (state_id, rev, payload) values (old.id, old.rev, old.payload);
    delete from public.gvc_state_history
      where state_id = old.id
        and hid not in (select hid from public.gvc_state_history where state_id = old.id order by hid desc limit 30);
  end if;
  return new;
end $$;
revoke execute on function public.gvc_state_archive() from anon, authenticated, public;

drop trigger if exists gvc_state_archive_trg on public.gvc_state;
create trigger gvc_state_archive_trg before update on public.gvc_state
  for each row execute function public.gvc_state_archive();
`;

export interface SupabaseStatus {
  configured: boolean;
  url: string | null;
  tableReady: boolean;
  message: string;
}

export async function checkSupabaseStatus(): Promise<SupabaseStatus> {
  if (!isSupabaseConfigured) {
    return {
      configured: false,
      url: null,
      tableReady: false,
      message: 'Supabase environment variables not set. Using local AES-256-GCM encrypted storage.',
    };
  }

  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/gvc_access_keys?select=id&limit=1`, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    });

    if (res.status === 200) {
      return {
        configured: true,
        url: SUPABASE_URL,
        tableReady: true,
        message: 'Connected to Supabase. Table gvc_access_keys is active.',
      };
    }

    if (res.status === 404 || res.status === 400) {
      return {
        configured: true,
        url: SUPABASE_URL,
        tableReady: false,
        message: 'Connected to Supabase endpoint, but table gvc_access_keys was not found. Please run the SQL schema.',
      };
    }

    return {
      configured: true,
      url: SUPABASE_URL,
      tableReady: false,
      message: `Supabase returned HTTP ${res.status}: ${await res.text()}`,
    };
  } catch (err) {
    return {
      configured: true,
      url: SUPABASE_URL,
      tableReady: false,
      message: err instanceof Error ? err.message : 'Failed to reach Supabase',
    };
  }
}

export async function syncKeyToSupabase(key: AccessKey): Promise<void> {
  if (!isSupabaseConfigured) return;
  try {
    const body = {
      id: key.id,
      key: key.key,
      note: key.note,
      role: key.role,
      status: key.status,
      created_at: key.createdAt,
      expires_at: key.expiresAt,
      duration_ms: key.durationMs,
      first_used_at: key.firstUsedAt,
      max_uses: key.maxUses,
      used_count: key.usedCount,
      permissions: key.permissions,
      redeemed_users: key.redeemedUsers,
    };

    const res = await fetch(`${SUPABASE_URL}/rest/v1/gvc_access_keys`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      logs.push(`Supabase sync failed for key ${key.key}: ${res.statusText}`, 'warn');
    }
  } catch (err) {
    logs.push(`Supabase error: ${err instanceof Error ? err.message : 'Network error'}`, 'warn');
  }
}

export async function deleteKeyFromSupabase(keyId: string): Promise<void> {
  if (!isSupabaseConfigured) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/gvc_access_keys?id=eq.${encodeURIComponent(keyId)}`, {
      method: 'DELETE',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
      },
    });
  } catch {
    // Non-blocking
  }
}


// ------------------------------------------------------------ durable app state
// The whole app state (accounts, config, keys...) is encrypted by store.ts and
// kept here as one opaque row, so a redeploy / new container never loses it.

const STATE_TIMEOUT_MS = 8_000;

function stateHeaders(extra: Record<string, string> = {}): Record<string, string> {
  return { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}`, ...extra };
}

export interface RemoteStateRow {
  rev: number;
  /** base64 of the AES-256-GCM blob (iv | tag | ciphertext). */
  payload: string;
}

export type FetchStateResult =
  | { ok: true; row: RemoteStateRow | null }
  | { ok: false; error: string; tableMissing: boolean };

export async function fetchRemoteState(): Promise<FetchStateResult> {
  if (!isSupabaseConfigured) return { ok: false, error: 'Supabase is not configured', tableMissing: false };
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/gvc_state?id=eq.main&select=rev,payload&limit=1`, {
      headers: stateHeaders(),
      signal: AbortSignal.timeout(STATE_TIMEOUT_MS),
    });
    if (res.ok) {
      const rows = (await res.json()) as Array<{ rev: number | string; payload: string }>;
      const row = rows[0];
      return { ok: true, row: row ? { rev: Number(row.rev), payload: String(row.payload) } : null };
    }
    const text = await res.text();
    const tableMissing = res.status === 404 || /PGRST205|does not exist|schema cache/i.test(text);
    return { ok: false, error: `HTTP ${res.status}: ${text.slice(0, 200)}`, tableMissing };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Network error', tableMissing: false };
  }
}

export type PushStateResult =
  | { ok: true }
  | { ok: false; conflict: boolean; error?: string; tableMissing?: boolean };

/**
 * Optimistic write: only succeeds if the row is still at `expectedRev`
 * (null = row must not exist yet). A second instance that saved in the
 * meantime makes this a conflict instead of silently overwriting its data.
 */
export async function pushRemoteState(
  payload: string,
  newRev: number,
  expectedRev: number | null,
): Promise<PushStateResult> {
  if (!isSupabaseConfigured) return { ok: false, conflict: false, error: 'Supabase is not configured' };
  try {
    const body = JSON.stringify({ rev: newRev, payload, updated_at: new Date().toISOString() });
    const res =
      expectedRev === null
        ? await fetch(`${SUPABASE_URL}/rest/v1/gvc_state`, {
            method: 'POST',
            headers: stateHeaders({
              'Content-Type': 'application/json',
              Prefer: 'return=representation,resolution=ignore-duplicates',
            }),
            body: JSON.stringify({ id: 'main', ...JSON.parse(body) }),
            signal: AbortSignal.timeout(STATE_TIMEOUT_MS),
          })
        : await fetch(`${SUPABASE_URL}/rest/v1/gvc_state?id=eq.main&rev=eq.${expectedRev}`, {
            method: 'PATCH',
            headers: stateHeaders({ 'Content-Type': 'application/json', Prefer: 'return=representation' }),
            body,
            signal: AbortSignal.timeout(STATE_TIMEOUT_MS),
          });

    if (!res.ok) {
      const text = await res.text();
      const tableMissing = res.status === 404 || /PGRST205|does not exist|schema cache/i.test(text);
      return { ok: false, conflict: false, error: `HTTP ${res.status}: ${text.slice(0, 200)}`, tableMissing };
    }
    const rows = (await res.json()) as unknown[];
    if (!Array.isArray(rows) || rows.length === 0) return { ok: false, conflict: true };
    return { ok: true };
  } catch (err) {
    return { ok: false, conflict: false, error: err instanceof Error ? err.message : 'Network error' };
  }
}
