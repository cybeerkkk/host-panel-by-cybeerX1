import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import type { Request, Response, NextFunction } from 'express';
import { bootBanner, config } from './config.ts';
import { hydrateState } from './store.ts';
import { errorMessage, logs } from './logger.ts';
import { isSnowflake, manager, searchAllTokens } from './botManager.ts';
import { api } from './routes.ts';
import { loginHandler, logoutHandler, sessionHandler } from './auth.ts';

// A rejected promise anywhere in the Discord client used to take the process
// down, which on Railway means a restart loop. Log and keep serving instead.
process.on('unhandledRejection', (reason) => {
  logs.push(`Unhandled rejection: ${errorMessage(reason)}`, 'error');
});
process.on('uncaughtException', (err) => {
  logs.push(`Uncaught exception: ${errorMessage(err)}`, 'error');
});

const app = express();

// Railway terminates TLS at its edge; without this req.ip is the proxy address
// and every visitor shares one rate-limit bucket.
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(
  compression({
    filter: (req, res) => {
      // Compressing SSE buffers it and the client sees nothing.
      if (res.getHeader('Content-Type')?.toString().includes('text/event-stream')) return false;
      return compression.filter(req, res);
    },
  }) as unknown as express.RequestHandler,
);
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());

const isProd = process.env.NODE_ENV === 'production';

app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.setHeader('X-Frame-Options', 'DENY');
  if (isProd) {
    // Railway serves over TLS; tell browsers never to try plain HTTP again.
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      // Vite's dev server injects inline module scripts; the production bundle
      // does not, so the escape hatch is dropped once NODE_ENV=production.
      isProd ? "script-src 'self'" : "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https://cdn.discordapp.com",
      "media-src 'self'",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ].join('; '),
  );
  next();
});

/**
 * CSRF guard for state-changing requests.
 *
 * The session cookie is sameSite=lax, which already blocks cross-site POSTs in
 * current browsers. This is the second layer for older clients and for any
 * request that arrives with a foreign Origin: the front-end and the API share
 * one origin, so a write from anywhere else is never legitimate.
 */
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    next();
    return;
  }

  const origin = req.get('origin');
  if (!origin) {
    // Non-browser clients (curl, a health probe) send no Origin at all.
    next();
    return;
  }

  const host = req.get('host');
  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    res.status(403).json({ error: 'Blocked: malformed origin' });
    return;
  }

  if (host && originHost === host) {
    next();
    return;
  }

  res.status(403).json({ error: 'Blocked: cross-origin request' });
});

// ------------------------------------------------------------- rate limiting

interface Bucket {
  tokens: number;
  updated: number;
}
const buckets = new Map<string, Bucket>();

/** Token bucket: `rate` requests per minute, burst of `rate`. */
function rateLimit(rate: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${req.ip ?? 'unknown'}:${rate}`;
    const now = Date.now();
    const bucket = buckets.get(key) ?? { tokens: rate, updated: now };

    bucket.tokens = Math.min(rate, bucket.tokens + ((now - bucket.updated) / 60_000) * rate);
    bucket.updated = now;

    if (bucket.tokens < 1) {
      buckets.set(key, bucket);
      res.status(429).json({ error: 'Slow down and try again in a moment' });
      return;
    }

    bucket.tokens -= 1;
    buckets.set(key, bucket);
    next();
  };
}

setInterval(() => {
  const cutoff = Date.now() - 10 * 60_000;
  for (const [key, bucket] of buckets) {
    if (bucket.updated < cutoff) buckets.delete(key);
  }
}, 5 * 60_000).unref();

// --------------------------------------------------------------------- routes

app.get('/api/health', (_req, res) => {
  const snapshot = manager.snapshot();
  res.json({
    ok: true,
    uptime: snapshot.stats.uptimeSeconds,
    sessions: snapshot.stats.total,
    online: snapshot.stats.online,
  });
});

app.post('/api/auth/login', rateLimit(20), loginHandler);
app.post('/api/auth/logout', logoutHandler);
app.get('/api/auth/session', sessionHandler);

// Free, keyless lookup — public Discord profile + mutual servers + live voice presence.
app.get('/api/public/user/:userId', rateLimit(8), async (req, res) => {
  const { userId } = req.params;
  if (!isSnowflake(userId)) {
    res.status(400).json({ error: 'That is not a valid Discord user ID' });
    return;
  }
  try {
    const p = await manager.lookupProfile(userId);
    res.json({
      userId: p.userId,
      username: p.username,
      globalName: p.globalName,
      avatarUrl: p.avatarUrl,
      bannerUrl: p.bannerUrl,
      accentColor: p.accentColor,
      bio: p.bio,
      createdAt: p.createdAt,
      badges: p.badges,
      isBot: p.isBot,
      isVerifiedBot: p.isVerifiedBot,
      // Live presence — always included; callers should handle inVoice=false gracefully.
      // Bots: no live voice info in the public User info.
      inVoice: p.isBot ? false : p.inVoice,
      voiceGuildId: p.isBot ? null : p.voiceGuildId,
      voiceGuildName: p.isBot ? null : p.voiceGuildName,
      voiceChannelId: p.isBot ? null : p.voiceChannelId,
      voiceChannelName: p.isBot ? null : p.voiceChannelName,
      voiceMemberCount: p.isBot ? 0 : p.voiceMemberCount,
      voiceSelfMute: p.isBot ? false : p.voiceSelfMute,
      voiceSelfDeaf: p.isBot ? false : p.voiceSelfDeaf,
      // Mutual servers visible to connected accounts.
      mutualGuilds: p.mutualGuilds,
    });
  } catch (err) {
    const message = errorMessage(err);
    if (/add at least one/i.test(message)) {
      res.status(503).json({ error: 'Lookup is unavailable right now. Try again later.' });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  }
});

// Public: highest rank (owner / administrator / admin) per mutual server. Loaded after the
// profile so the page never waits for it.
app.get('/api/public/user/:userId/ranks', rateLimit(12), async (req, res) => {
  const { userId } = req.params;
  if (!isSnowflake(userId)) {
    res.status(400).json({ error: 'That is not a valid Discord user ID' });
    return;
  }
  try {
    res.json(await manager.lookupRanks(userId));
  } catch {
    res.json({});
  }
});

// Public: member roles in a mutual guild. No key needed — data is limited to what
// connected accounts can already see (same guild, same cache as the profile lookup).
app.get('/api/public/guilds/:guildId/member-roles', rateLimit(12), async (req, res) => {
  const { guildId } = req.params;
  const userId = String(req.query.userId ?? '').trim();
  if (!isSnowflake(guildId) || !isSnowflake(userId)) {
    res.status(400).json({ error: 'guildId and userId must be valid snowflakes' });
    return;
  }
  // Delegate to the same logic used by the authenticated monitor endpoint.
  // We do it inline here to avoid importing requireAuth from routes.ts.
  const guildSessions = manager.list().filter((s) => {
    if (s.status !== 'online' || !(s as any).client) return false;
    return Boolean((s as any).client.guilds?.cache?.get(guildId));
  });
  if (guildSessions.length === 0) {
    res.status(404).json({ error: 'Server not found or not visible to any account' });
    return;
  }
  const targetGuild = (guildSessions[0] as any).client.guilds.cache.get(guildId);
  let member: any = null;
  for (const session of guildSessions) {
    const cached = (session as any).client.guilds.cache.get(guildId)?.members?.cache?.get(userId);
    if (cached) { member = cached; break; }
  }
  if (!member) {
    // Try REST
    for (const session of guildSessions) {
      try {
        const fp = (() => {
          const off = Math.floor(parseInt(session.id.replace(/-/g, '').slice(0, 8), 16) % 500);
          const chromeMajor = 124 + (off % 4);
          const ua = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Safari/537.36`;
          const locale = ['en-US', 'en-GB', 'en-CA', 'en-AU'][off % 4];
          const tz = ['America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris'][off % 5];
          const superProps = Buffer.from(JSON.stringify({ os: 'Windows', browser: 'Chrome', device: '', system_locale: locale, browser_user_agent: ua, browser_version: `${chromeMajor}.0.0.0`, os_version: '10', referrer: '', referring_domain: '', referrer_current: '', referring_domain_current: '', release_channel: 'stable', client_build_number: 309800 + off, client_event_source: null })).toString('base64');
          return { ua, locale, tz, superProps };
        })();
        const r = await fetch(`https://discord.com/api/v9/guilds/${guildId}/members/${userId}`, {
          headers: { Authorization: (session as any).token, 'User-Agent': fp.ua, 'X-Discord-Locale': fp.locale, 'X-Discord-Timezone': fp.tz, 'X-Super-Properties': fp.superProps, Accept: '*/*', 'Accept-Language': `${fp.locale},en;q=0.9`, Origin: 'https://discord.com', Referer: `https://discord.com/channels/${guildId}` },
        });
        if (r.ok) { member = await r.json(); break; }
        if (r.status === 404) { res.status(404).json({ error: 'This user is not a member of that server.' }); return; }
      } catch { /* try next session */ }
    }
  }
  if (!member) { res.status(404).json({ error: 'Member details unavailable.' }); return; }

  const m = member as any;
  const memberRoleIds: string[] = m.roles?.cache ? [...m.roles.cache.keys()] : Array.isArray(m.roles) ? m.roles : [];
  const roleCache = targetGuild.roles?.cache;
  const ADMIN_BIT = BigInt(1) << BigInt(3);
  const ELEVATED_BITS = [1, 2, 4, 5, 13, 28, 40].reduce((acc, n) => acc | (BigInt(1) << BigInt(n)), BigInt(0));
  const roles: any[] = [];
  for (const roleId of memberRoleIds) {
    const role = roleCache?.get(roleId);
    if (!role || (role as any).name === '@everyone') continue;
    const r = role as any;
    const bits = r.permissions?.bitfield !== undefined ? BigInt(r.permissions.bitfield.toString()) : BigInt(0);
    roles.push({ id: r.id, name: r.name ?? 'Unknown Role', color: r.color ? `#${r.color.toString(16).padStart(6, '0')}` : null, position: r.position ?? 0, hoist: Boolean(r.hoist), administrator: (bits & ADMIN_BIT) === ADMIN_BIT, elevated: (bits & ELEVATED_BITS) !== BigInt(0) });
  }
  roles.sort((a, b) => b.position - a.position);
  const user = m.user ?? {};
  const avatarHash = m.avatar ?? user.avatar ?? null;
  const guildAvatarHash = m.avatar ?? null;
  const avatarUrl = guildAvatarHash
    ? `https://cdn.discordapp.com/guilds/${guildId}/users/${userId}/avatars/${guildAvatarHash}.${guildAvatarHash.startsWith('a_') ? 'gif' : 'png'}?size=128`
    : avatarHash ? `https://cdn.discordapp.com/avatars/${userId}/${avatarHash}.${avatarHash.startsWith('a_') ? 'gif' : 'png'}?size=128` : null;
  const joinedAt = m.joinedAt ? new Date(m.joinedAt).getTime() : m.joined_at ? new Date(m.joined_at).getTime() : null;
  res.json({ userId, guildId, guildName: targetGuild.name, nickname: m.nickname ?? m.nick ?? null, avatarUrl, joinedAt, isOwner: String(targetGuild.ownerId ?? '') === userId, roles });
});

// Public: all roles in a guild (for permission display in the role modal).
app.get('/api/public/guilds/:guildId/roles', rateLimit(12), async (req, res) => {
  const { guildId } = req.params;
  if (!isSnowflake(guildId)) {
    res.status(400).json({ error: 'guildId must be a valid snowflake' });
    return;
  }
  const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);
  let targetGuild: any = null;
  for (const session of online) {
    const g = (session as any).client.guilds?.cache?.get(guildId);
    if (g) { targetGuild = g; break; }
  }
  if (!targetGuild) { res.status(404).json({ error: 'Server not found or not visible to any account' }); return; }

  const roles: any[] = [];
  if (targetGuild.roles?.cache) {
    for (const role of targetGuild.roles.cache.values()) {
      const r = role as any;
      roles.push({ id: r.id, name: r.name ?? 'Unknown Role', color: r.color ? `#${r.color.toString(16).padStart(6, '0')}` : null, position: r.position ?? 0, hoist: Boolean(r.hoist), mentionable: Boolean(r.mentionable), managed: Boolean(r.managed), permissions: r.permissions?.bitfield ? r.permissions.bitfield.toString() : '0', permissionNames: r.permissions?.toArray?.() ?? [], memberCount: null });
    }
  }
  roles.sort((a, b) => b.position - a.position);
  res.json({ guildId, guildName: targetGuild.name, roles });
});
// Public: username/display-name search across all connected bot caches. No key needed.
// Returns up to 20 unique (userId, guildId) matches so callers can pick and then
// call /api/public/user/:userId for the full profile.
app.get('/api/public/search', rateLimit(6), async (req, res) => {
  const q = String(req.query.q ?? '').trim();
  if (q.length < 2 || q.length > 32) {
    res.status(400).json({ error: 'Search must be between 2 and 32 characters' });
    return;
  }
  const query = q.toLocaleLowerCase();

  type SearchHit = {
    userId: string;
    username: string;
    globalName: string | null;
    nickname: string | null;
    avatarUrl: string | null;
    guildId: string;
    guildName: string;
    guildIconUrl: string | null;
  };

  function avatarUrl(userId: string, hash: string | null | undefined, size = 64): string | null {
    if (!hash) return null;
    const ext = hash.startsWith('a_') ? 'gif' : 'png';
    return `https://cdn.discordapp.com/avatars/${userId}/${hash}.${ext}?size=${size}`;
  }
  function guildAvatarUrl(guildId: string, userId: string, hash: string | null | undefined, size = 64): string | null {
    if (!hash) return null;
    const ext = hash.startsWith('a_') ? 'gif' : 'png';
    return `https://cdn.discordapp.com/guilds/${guildId}/users/${userId}/avatars/${hash}.${ext}?size=${size}`;
  }
  function iconUrl(guildId: string, hash: string | null | undefined): string | null {
    if (!hash) return null;
    const ext = hash.startsWith('a_') ? 'gif' : 'png';
    return `https://cdn.discordapp.com/icons/${guildId}/${hash}.${ext}?size=64`;
  }

  const matches = new Map<string, SearchHit>();
  const online = manager.list().filter((s) => s.status === 'online' && (s as any).client);

  const addMember = (guild: any, member: any) => {
    const user = member?.user;
    if (!user?.id) return;
    const username = String(user.username ?? '');
    const globalName = (user.globalName ?? user.global_name ?? null) as string | null;
    const nickname = (member.nickname ?? null) as string | null;
    const hit = [username, globalName, nickname]
      .some((n) => typeof n === 'string' && n.toLocaleLowerCase().includes(query));
    if (!hit) return;
    const key = `${user.id}:${guild.id}`;
    if (matches.has(key)) return;
    matches.set(key, {
      userId: user.id,
      username,
      globalName,
      nickname,
      avatarUrl: guildAvatarUrl(guild.id, user.id, member.avatar) ?? avatarUrl(user.id, user.avatar),
      guildId: guild.id,
      guildName: guild.name ?? 'Unknown server',
      guildIconUrl: iconUrl(guild.id, guild.icon),
    });
  };

  // 1) Instant: every member already cached by every token.
  for (const session of online) {
    const client = (session as any).client;
    for (const guild of client.guilds?.cache?.values?.() ?? []) {
      for (const member of guild.members?.cache?.values?.() ?? []) addMember(guild, member);
    }
  }

  // 2) Complete: ALL tokens search their own servers in parallel (max 1.5s).
  await searchAllTokens(online as any[], query, 1_500, addMember);

  const results = [...matches.values()]
    .sort((a, b) => {
      const aExact = [a.username, a.globalName, a.nickname].some((n) => n?.toLocaleLowerCase() === query);
      const bExact = [b.username, b.globalName, b.nickname].some((n) => n?.toLocaleLowerCase() === query);
      const aStarts = !aExact && [a.username, a.globalName, a.nickname].some((n) => n?.toLocaleLowerCase().startsWith(query));
      const bStarts = !bExact && [b.username, b.globalName, b.nickname].some((n) => n?.toLocaleLowerCase().startsWith(query));
      return Number(bExact) - Number(aExact) ||
        Number(bStarts) - Number(aStarts) ||
        (a.globalName ?? a.username).localeCompare(b.globalName ?? b.username);
    })
    .slice(0, 20);

  res.json(results);
});

app.use('/api', rateLimit(900), api);

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'Unknown endpoint' });
});

// ---------------------------------------------------------------- frontend setup

async function setupFrontend(): Promise<void> {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const publicDir = [
      process.env.PUBLIC_DIR,
      // production: dist/server.cjs sits next to dist/public
      typeof __dirname !== 'undefined' ? path.join(__dirname, 'public') : undefined,
      path.resolve(process.cwd(), 'dist/public'),
    ]
      .filter((dir): dir is string => Boolean(dir))
      .find((dir) => fs.existsSync(path.join(dir, 'index.html')));

    if (publicDir) {
      const root = publicDir;
      app.use((req, res, next) => {
        if (req.path.endsWith('.map')) {
          res.status(404).end();
          return;
        }
        next();
      });
      app.use(
        express.static(root, {
          // Hashed asset filenames are safe to cache hard; index.html is not.
          setHeaders: (res, filePath) => {
            if (filePath.endsWith('index.html')) {
              res.setHeader('Cache-Control', 'no-cache');
            } else if (/-[A-Za-z0-9_-]{8,}\.[a-z0-9]+$/.test(path.basename(filePath))) {
              res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
            } else {
              res.setHeader('Cache-Control', 'public, max-age=3600');
            }
          },
        }),
      );

      // SPA fallback so a refresh on any path still boots the app.
      app.get('*', (_req, res) => {
        res.sendFile(path.join(root, 'index.html'));
      });
    } else {
      app.get('*', (_req, res) => {
        res
          .status(503)
          .type('text/plain')
          .send('Frontend build missing. Run "npm run build" before "npm start".');
      });
    }
  }
}

// ---------------------------------------------------------------------- boot

async function main(): Promise<void> {
  console.log('');
  console.log('  Ghost Voice Control');
  for (const line of bootBanner()) console.log(`  ${line}`);
  console.log('');

  // Load the saved accounts/config (from Supabase if configured) BEFORE serving
  // requests or reconnecting anything, so a redeploy never starts from empty.
  await hydrateState().catch((err) => {
    logs.push(`Could not load saved state: ${errorMessage(err)}`, 'error');
  });

  await setupFrontend();

  // Final error handler: without it Express prints a stack trace to the response.
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    logs.push(`Request error: ${errorMessage(err)}`, 'error');
    if (!res.headersSent) res.status(500).json({ error: 'Internal error' });
  });

  // Bind 0.0.0.0 so the container is reachable from outside.
  const server = app.listen(config.port, '0.0.0.0', () => {
    logs.push(`Listening on port ${config.port}`, 'info');
  });

  // Long-lived SSE connections need a headers timeout above the ping interval.
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 70_000;

  await manager.restore();

  let closing = false;
  const shutdown = async (signal: string) => {
    if (closing) return;
    closing = true;
    logs.push(`${signal} received, shutting down`, 'info');

    server.close();
    // Railway sends SIGTERM and kills after ~30s; save and disconnect first.
    const timeout = setTimeout(() => process.exit(0), 10_000);
    try {
      await manager.shutdown();
    } finally {
      clearTimeout(timeout);
      process.exit(0);
    }
  };

  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

void main();
