import crypto from 'node:crypto';
import path from 'node:path';
import 'dotenv/config';

function envInt(name: string, fallback: number, min: number, max: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

const isProduction = process.env.NODE_ENV === 'production';

/**
 * Generated secrets are fine for a local run but must not be silently accepted
 * in production: a regenerated SESSION_SECRET logs everyone out on each deploy,
 * and a regenerated ENCRYPTION_KEY makes the saved token file unreadable. Both
 * cases warn loudly on boot instead of failing quietly later.
 */
const generatedNotes: string[] = [];

let accessPassword = (process.env.ACCESS_PASSWORD ?? '').trim();
let passwordWasGenerated = false;
if (!accessPassword) {
  // Generate a random password per boot so there is no static default that
  // an attacker could exploit. The operator must set ACCESS_PASSWORD to keep
  // a stable credential across restarts.
  // Math.random() is not a CSPRNG — its output is predictable from a few
  // samples, so a boot password built from it is guessable.
  accessPassword = 'GVC-' + crypto.randomBytes(12).toString('base64url');
  passwordWasGenerated = true;
}

function secret(name: string, fallbackFrom?: string): string {
  const raw = process.env[name];
  if (raw && raw.trim().length >= 16) return raw.trim();
  if (fallbackFrom) return crypto.createHash('sha256').update(fallbackFrom).digest('hex');
  // Use a stable derivation based on accessPassword so restarts don't invalidate data/state.enc
  return crypto
    .createHash('sha256')
    .update(`${name}:${accessPassword}:gvc-salt-2026`)
    .digest('hex');
}

const sessionSecret = secret('SESSION_SECRET');
const encryptionKey = secret('ENCRYPTION_KEY', sessionSecret);

export const config = {
  isProduction,
  port: envInt('PORT', 3000, 1, 65535),
  accessPassword,
  passwordWasGenerated,
  sessionSecret,
  encryptionKey,
  dataDir: path.resolve(process.env.DATA_DIR ?? './data'),
  joinStaggerMs: envInt('JOIN_STAGGER_MS', 650, 0, 10_000),
  sessionTtlMs: envInt('SESSION_TTL_HOURS', 168, 1, 8760) * 60 * 60 * 1000,
  /** Hard ceiling so one request cannot spawn thousands of gateway sockets. */
  maxSessions: envInt('MAX_SESSIONS', 1000, 1, 1000),
  loginTimeoutMs: envInt('LOGIN_TIMEOUT_MS', 30_000, 5_000, 120_000),
  generatedSecrets: generatedNotes,
} as const;

export function bootBanner(): string[] {
  const lines: string[] = [];
  lines.push(`env            ${isProduction ? 'production' : 'development'}`);
  lines.push(`port           ${config.port}`);
  lines.push(`data dir       ${config.dataDir}`);
  lines.push(`max sessions   ${config.maxSessions}`);
  lines.push(`join stagger   ${config.joinStaggerMs}ms`);

  if (passwordWasGenerated) {
    lines.push('');
    lines.push('  ACCESS_PASSWORD was not set. Temporary password for this boot:');
    lines.push(`      ${accessPassword}`);
    lines.push('  It changes on every restart. Set ACCESS_PASSWORD to keep one.');
  }

  if ((process.env.ENCRYPTION_KEY ?? '').trim().length < 16) {
    lines.push('');
    lines.push('  !! ENCRYPTION_KEY is not set: the key is derived from ACCESS_PASSWORD / SESSION_SECRET.');
    lines.push('  !! Changing either one later makes the saved accounts unreadable.');
    lines.push('  !! Set a fixed ENCRYPTION_KEY in Railway once and never change it.');
  }

  if (generatedNotes.length > 0) {
    lines.push('');
    lines.push(`  Generated at boot: ${generatedNotes.join(', ')}.`);
    lines.push('  Set them as variables or sessions and saved tokens reset on redeploy.');
  }

  return lines;
}
