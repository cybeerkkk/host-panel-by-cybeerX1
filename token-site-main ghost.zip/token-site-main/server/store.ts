import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.ts';
import { errorMessage, logs } from './logger.ts';
import { fetchRemoteState, isSupabaseConfigured, pushRemoteState } from './supabase.ts';
import type { AccessKey, AppConfig, AutoReactRule, KeyUsageRecord, StorageStatus } from '../shared/types.ts';

export interface PersistedDesiredVoice {
  guildId: string;
  channelId: string;
  selfMute: boolean;
  selfDeaf: boolean;
}

export interface PersistedSession {
  id: string;
  token: string;
  antiLeave: boolean;
  autoFollow: boolean;
  /** Voice slots to restore on restart, keyed by guildId. */
  desiredVoice?: Record<string, PersistedDesiredVoice>;
}

export interface PersistedState {
  version: 1;
  /** Revision counter shared with the cloud copy; bumped on every save. */
  rev?: number;
  sessions: PersistedSession[];
  config: AppConfig;
  keys: AccessKey[];
  autoReactRules?: AutoReactRule[];
  ownerPassword?: string;
}

export const defaultConfig: AppConfig = {
  defaultGuildId: '',
  defaultChannelId: '',
  autoFollowTargetId: '',
  autoFollowEnabled: false,
  globalAntiLeave: true,
  selfMute: false,
  selfDeaf: false,
  globalAntiMove: false,
  globalAntiHost: false,
};

const FILE = path.join(config.dataDir, 'state.enc');
const TMP = `${FILE}.tmp`;

// AES-256-GCM. The key is a 32-byte digest of ENCRYPTION_KEY so any length of
// user-supplied secret is accepted.
const key = crypto.createHash('sha256').update(config.encryptionKey).digest();

function encrypt(plaintext: string): Buffer {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), body]);
}

function decrypt(payload: Buffer): string {
  const iv = payload.subarray(0, 12);
  const tag = payload.subarray(12, 28);
  const body = payload.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(body), decipher.final()]).toString('utf8');
}

function emptyState(): PersistedState {
  return { version: 1, rev: 0, sessions: [], config: { ...defaultConfig }, keys: [], ownerPassword: undefined };
}

/** Validates a decrypted blob so a damaged/foreign file can never crash the app. */
function normalizeState(parsed: Partial<PersistedState>): PersistedState {
  return {
    version: 1,
    rev: typeof parsed.rev === 'number' && Number.isFinite(parsed.rev) ? parsed.rev : undefined,
    sessions: Array.isArray(parsed.sessions)
      ? parsed.sessions.filter(
          (s): s is PersistedSession => typeof s?.id === 'string' && typeof s?.token === 'string',
        )
      : [],
    config: { ...defaultConfig, ...(parsed.config ?? {}) },
    keys: Array.isArray(parsed.keys)
      ? parsed.keys.filter(
          (k): k is AccessKey =>
            typeof k?.id === 'string' && typeof k?.key === 'string' && typeof k?.status === 'string',
        )
      : [],
    autoReactRules: Array.isArray(parsed.autoReactRules)
      ? parsed.autoReactRules.filter(
          (r): r is AutoReactRule =>
            typeof r?.id === 'string' && typeof r?.targetUserId === 'string' && typeof r?.emoji === 'string',
        )
      : [],
    ownerPassword:
      typeof parsed.ownerPassword === 'string' && parsed.ownerPassword.trim()
        ? parsed.ownerPassword.trim()
        : undefined,
  };
}

/**
 * Union of two states. `over` wins on conflicts. Accounts are matched by token,
 * keys / rules by id. Used when two instances saved at the same time (e.g. the
 * old container during a redeploy) so neither side loses an imported account.
 */
function mergeStates(base: PersistedState, over: PersistedState): PersistedState {
  const sessions = new Map(base.sessions.map((s) => [s.token, s] as const));
  for (const s of over.sessions) sessions.set(s.token, { ...sessions.get(s.token), ...s });

  const keys = new Map(base.keys.map((k) => [k.id, k] as const));
  for (const k of over.keys) keys.set(k.id, k);

  const rules = new Map((base.autoReactRules ?? []).map((r) => [r.id, r] as const));
  for (const r of over.autoReactRules ?? []) rules.set(r.id, r);

  return {
    version: 1,
    rev: Math.max(base.rev ?? 0, over.rev ?? 0),
    sessions: [...sessions.values()],
    config: over.config,
    keys: [...keys.values()],
    autoReactRules: [...rules.values()],
    ownerPassword: over.ownerPassword ?? base.ownerPassword,
  };
}

function hasData(state: PersistedState): boolean {
  return state.sessions.length > 0 || state.keys.length > 0 || (state.autoReactRules?.length ?? 0) > 0;
}

let inMemoryState: PersistedState | null = null;

export function loadState(): PersistedState {
  if (inMemoryState) return inMemoryState;

  try {
    if (!fs.existsSync(FILE)) {
      inMemoryState = emptyState();
      return inMemoryState;
    }
    const parsed = JSON.parse(decrypt(fs.readFileSync(FILE))) as Partial<PersistedState>;
    inMemoryState = normalizeState(parsed);
    return inMemoryState;
  } catch (err) {
    // Never let the next save silently destroy a file we merely failed to read
    // (wrong ENCRYPTION_KEY is the usual cause): keep it aside as a backup.
    let kept = '';
    try {
      kept = `${FILE}.unreadable-${Date.now()}`;
      fs.renameSync(FILE, kept);
    } catch {
      kept = '';
    }
    logs.push(
      `Could not read the saved state (${errorMessage(err)}). Starting empty` +
        (kept ? ` - the old file was kept as ${path.basename(kept)}.` : '.') +
        ' This usually means ENCRYPTION_KEY changed: restore the previous value to recover it.',
      'warn',
    );
    inMemoryState = emptyState();
    return inMemoryState;
  }
}

// --------------------------------------------------------------- cloud (Supabase)

type RemoteStatus = StorageStatus['remote'];

let remoteStatus: RemoteStatus = isSupabaseConfigured ? 'unknown' : 'off';
/** Revision of the cloud row as last seen/written. null = no row exists yet. */
let remoteRev: number | null = null;
let remoteError: string | null = null;
let lastSyncAt: number | null = null;
let retryTimer: NodeJS.Timeout | null = null;
let tableHintShown = false;

const onRailwayVolume = (() => {
  const mount = process.env.RAILWAY_VOLUME_MOUNT_PATH;
  if (!mount) return false;
  const root = path.resolve(mount);
  return config.dataDir === root || config.dataDir.startsWith(root + path.sep);
})();

export function getStorageStatus(): StorageStatus {
  if (!isSupabaseConfigured) {
    return {
      backend: 'disk',
      durable: onRailwayVolume,
      remote: 'off',
      lastSyncAt: null,
      message: onRailwayVolume
        ? 'Saved encrypted on the Railway volume.'
        : 'Saved on local disk only - accounts are lost on redeploy. Connect Supabase (or attach a Railway volume).',
    };
  }
  const durable = remoteStatus === 'ready' && !remoteError;
  const message =
    remoteStatus === 'ready' && !remoteError
      ? 'Accounts are encrypted and saved to Supabase - they survive restarts and redeploys.'
      : remoteStatus === 'blocked'
        ? 'Cloud state cannot be decrypted with the current ENCRYPTION_KEY. Restore the previous key - nothing was overwritten.'
        : `Cloud save is not working${remoteError ? `: ${remoteError}` : ''}. Accounts are only saved locally until it recovers.`;
  return { backend: 'supabase', durable, remote: remoteStatus, lastSyncAt, message };
}

/** Read through a function so TypeScript does not narrow it across awaits. */
function cloudStatus(): RemoteStatus {
  return remoteStatus;
}

function showTableHint(): void {
  if (tableHintShown) return;
  tableHintShown = true;
  logs.push(
    'Supabase table "gvc_state" is missing. Open Owner panel > Supabase and run the SQL schema (or run it in the Supabase SQL editor).',
    'warn',
  );
}

function decryptRemote(payload: string): PersistedState {
  return normalizeState(JSON.parse(decrypt(Buffer.from(payload, 'base64'))) as Partial<PersistedState>);
}

function writeLocal(state: PersistedState): Promise<void> {
  return (async () => {
    try {
      await fsp.mkdir(config.dataDir, { recursive: true });
      await fsp.writeFile(TMP, encrypt(JSON.stringify(state)));
      await fsp.rename(TMP, FILE);
    } catch (err) {
      logs.push(`Failed to save state to disk: ${errorMessage(err)}`, 'error');
    }
  })();
}

/**
 * Compare the cloud copy with the local one and keep the newer. Safe to call
 * repeatedly. Never overwrites a cloud row it cannot decrypt.
 */
async function reconcile(): Promise<void> {
  const res = await fetchRemoteState();
  if (!res.ok) {
    remoteStatus = 'unavailable';
    remoteError = res.error;
    if (res.tableMissing) showTableHint();
    return;
  }

  remoteError = null;
  const local = loadState();

  if (!res.row) {
    // First run with Supabase: whatever we already have locally becomes the cloud copy.
    remoteRev = null;
    remoteStatus = 'ready';
    if (hasData(local)) {
      logs.push('Supabase is empty - uploading the saved accounts (encrypted).', 'info');
      dirty = true;
    }
    return;
  }

  remoteRev = res.row.rev;

  let remote: PersistedState;
  try {
    remote = decryptRemote(res.row.payload);
  } catch {
    remoteStatus = 'blocked';
    remoteError = 'cloud state is unreadable with the current ENCRYPTION_KEY';
    logs.push(
      'Supabase has saved state but it cannot be decrypted with the current ENCRYPTION_KEY. ' +
        'It was NOT overwritten. Set ENCRYPTION_KEY back to its previous value and redeploy.',
      'error',
    );
    return;
  }

  remoteStatus = 'ready';
  lastSyncAt = Date.now();

  const localRev = local.rev ?? 0;
  if (res.row.rev > localRev) {
    // Cloud is newer: adopt it. A legacy local file with accounts the cloud
    // does not know about is merged in rather than dropped.
    // Same for changes made while the cloud was unreachable (dirty).
    const keepLocal = dirty || (local.rev === undefined && hasData(local));
    const adopted = keepLocal ? mergeStates(remote, local) : remote;
    adopted.rev = res.row.rev;
    inMemoryState = adopted;
    await writeLocal(adopted);
    if (keepLocal) dirty = true;
    logs.push(`Loaded ${inMemoryState.sessions.length} saved account(s) from Supabase.`, 'info');
  } else if (localRev > res.row.rev) {
    dirty = true; // local is ahead (an earlier cloud save failed) - push it
  }
}

/** Call once at boot, before serving requests and before manager.restore(). */
export async function hydrateState(): Promise<void> {
  loadState();
  if (!isSupabaseConfigured) {
    logs.push(`State storage: ${getStorageStatus().message}`, onRailwayVolume ? 'info' : 'warn');
    return;
  }
  await reconcile();
  // Push anything that is newer locally (e.g. saved while the cloud was down)
  // before serving, so the cloud copy is complete as soon as we are up.
  if (dirty) await flush();
  const status = getStorageStatus();
  logs.push(`State storage: ${status.message}`, status.durable ? 'info' : 'warn');
}

// ------------------------------------------------------------------ persistence

let pending: NodeJS.Timeout | null = null;
/** True when inMemoryState has changes that are not saved everywhere yet. */
let dirty = false;
let flushPromise: Promise<void> | null = null;

function scheduleRemoteRetry(): void {
  if (retryTimer) return;
  retryTimer = setTimeout(() => {
    retryTimer = null;
    dirty = true;
    void flush();
  }, 20_000);
  retryTimer.unref();
}

async function pushToCloud(initial: PersistedState): Promise<PersistedState> {
  let snapshot = initial;

  if (cloudStatus() === 'blocked') return snapshot; // never overwrite what we cannot read

  if (cloudStatus() !== 'ready') {
    await reconcile();
    if (cloudStatus() !== 'ready') {
      scheduleRemoteRetry();
      return snapshot;
    }
    snapshot = inMemoryState ?? snapshot;
  }

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const newRev = (remoteRev ?? 0) + 1;
    snapshot.rev = newRev;
    const payload = encrypt(JSON.stringify(snapshot)).toString('base64');
    const result = await pushRemoteState(payload, newRev, remoteRev);

    if (result.ok) {
      remoteRev = newRev;
      remoteError = null;
      lastSyncAt = Date.now();
      return snapshot;
    }

    if (result.conflict) {
      // Someone else saved first. Merge their accounts with ours and retry.
      const theirs = await fetchRemoteState();
      if (theirs.ok && theirs.row) {
        try {
          const remote = decryptRemote(theirs.row.payload);
          remoteRev = theirs.row.rev;
          // Read inMemoryState after the await: it may have changed meanwhile.
          snapshot = mergeStates(remote, inMemoryState ?? snapshot);
          inMemoryState = snapshot;
          continue;
        } catch {
          remoteStatus = 'blocked';
          remoteError = 'cloud state is unreadable with the current ENCRYPTION_KEY';
          return snapshot;
        }
      }
      if (theirs.ok && !theirs.row) {
        remoteRev = null;
        continue;
      }
    }

    remoteError = result.ok ? null : (result.error ?? 'conflict');
    if (!result.ok && result.tableMissing) {
      remoteStatus = 'unavailable';
      showTableHint();
    }
    logs.push(`Cloud save failed (${remoteError}). Will retry.`, 'warn');
    scheduleRemoteRetry();
    return snapshot;
  }

  scheduleRemoteRetry();
  return snapshot;
}

async function doFlush(): Promise<void> {
  if (!dirty || !inMemoryState) return;
  dirty = false;

  try {
    const snapshot = inMemoryState;
    // Every save moves the revision forward, even when the cloud is unreachable,
    // so a local-only change is recognised as "newer than the cloud" next boot.
    snapshot.rev = Math.max(snapshot.rev ?? 0, remoteRev ?? 0) + 1;
    const revBefore = snapshot.rev;

    // Disk first: it is instant and protects us if the container dies mid-upload.
    await writeLocal(snapshot);

    if (!isSupabaseConfigured) return;
    const after = await pushToCloud(snapshot);
    if (after !== snapshot || after.rev !== revBefore) await writeLocal(after);
  } catch (err) {
    logs.push(`Failed to save state: ${errorMessage(err)}`, 'error');
    scheduleRemoteRetry();
  }
}

function flush(): Promise<void> {
  if (flushPromise) return flushPromise.then(() => (dirty ? flush() : undefined));
  if (!dirty) return Promise.resolve();
  flushPromise = doFlush().finally(() => {
    flushPromise = null;
  });
  return flushPromise.then(() => (dirty ? flush() : undefined));
}

function mergePartial(state: Partial<PersistedState>): PersistedState {
  const current = loadState();
  const merged: PersistedState = {
    version: 1,
    rev: current.rev,
    sessions: state.sessions ?? current.sessions,
    config: state.config ?? current.config,
    keys: state.keys ?? current.keys,
    autoReactRules: state.autoReactRules ?? current.autoReactRules,
    ownerPassword: state.ownerPassword !== undefined ? state.ownerPassword : current.ownerPassword,
  };
  inMemoryState = merged;
  dirty = true;
  return merged;
}

/** Debounced so a bulk import of 50 tokens produces one write, not 50. */
export function saveState(state: Partial<PersistedState>): void {
  mergePartial(state);

  if (pending) clearTimeout(pending);
  pending = setTimeout(() => {
    pending = null;
    void flush();
  }, 300);
}

export async function saveStateNow(state: Partial<PersistedState>): Promise<void> {
  if (pending) {
    clearTimeout(pending);
    pending = null;
  }
  mergePartial(state);
  await flush();
}

// ---------------------------------------------------------------- Access Keys API

export function getKeys(): AccessKey[] {
  return loadState().keys;
}

export function getKeyById(id: string): AccessKey | undefined {
  return loadState().keys.find((k) => k.id === id);
}

export function getKeyByCode(code: string): AccessKey | undefined {
  const normalized = code.trim().toUpperCase();
  return loadState().keys.find((k) => k.key.trim().toUpperCase() === normalized);
}

export function upsertKey(accessKey: AccessKey): void {
  const state = loadState();
  const index = state.keys.findIndex((k) => k.id === accessKey.id);
  let nextKeys: AccessKey[];
  if (index >= 0) {
    nextKeys = [...state.keys];
    nextKeys[index] = accessKey;
  } else {
    nextKeys = [accessKey, ...state.keys];
  }
  saveState({ keys: nextKeys });
}

export function deleteKey(id: string): boolean {
  const state = loadState();
  const filtered = state.keys.filter((k) => k.id !== id);
  if (filtered.length === state.keys.length) return false;
  saveState({ keys: filtered });
  return true;
}

export function recordKeyUsage(keyId: string, record: KeyUsageRecord): AccessKey | undefined {
  const state = loadState();
  const target = state.keys.find((k) => k.id === keyId);
  if (!target) return undefined;

  const now = Date.now();
  const existingUserIndex = target.redeemedUsers.findIndex((u) => u.sessionId === record.sessionId);

  let updatedUsers: KeyUsageRecord[];
  if (existingUserIndex >= 0) {
    updatedUsers = [...target.redeemedUsers];
    updatedUsers[existingUserIndex] = {
      ...updatedUsers[existingUserIndex],
      lastActiveAt: now,
      ip: record.ip,
      userAgent: record.userAgent ?? updatedUsers[existingUserIndex].userAgent,
    };
  } else {
    updatedUsers = [
      ...target.redeemedUsers,
      {
        ...record,
        redeemedAt: now,
        lastActiveAt: now,
      },
    ];
  }

  // Handle first activation duration
  let expiresAt = target.expiresAt;
  let firstUsedAt = target.firstUsedAt;
  if (!firstUsedAt && target.durationMs) {
    firstUsedAt = now;
    expiresAt = now + target.durationMs;
  }

  const updated: AccessKey = {
    ...target,
    firstUsedAt,
    expiresAt,
    usedCount: updatedUsers.length,
    redeemedUsers: updatedUsers,
  };

  upsertKey(updated);
  return updated;
}

export function kickKeySession(keyId: string, sessionId: string): boolean {
  const state = loadState();
  const target = state.keys.find((k) => k.id === keyId);
  if (!target) return false;

  const filtered = target.redeemedUsers.filter((u) => u.sessionId !== sessionId);
  if (filtered.length === target.redeemedUsers.length) return false;

  const updated: AccessKey = {
    ...target,
    usedCount: filtered.length,
    redeemedUsers: filtered,
  };
  upsertKey(updated);
  return true;
}

export function updateKeyConfig(keyId: string, patch: Partial<AppConfig>): AccessKey | undefined {
  const state = loadState();
  const target = state.keys.find((k) => k.id === keyId);
  if (!target) return undefined;

  const updated: AccessKey = {
    ...target,
    config: {
      ...(target.config ?? {}),
      ...patch,
    },
  };
  upsertKey(updated);
  return updated;
}

export function getOwnerPassword(): string {
  const state = loadState();
  return state.ownerPassword || config.accessPassword;
}

export function setOwnerPassword(newPassword: string): void {
  saveState({ ownerPassword: newPassword.trim() });
}

export function getAutoReactRules(): AutoReactRule[] {
  const state = loadState();
  return state.autoReactRules || [];
}

export function upsertAutoReactRule(rule: AutoReactRule): void {
  const state = loadState();
  const current = state.autoReactRules || [];
  const idx = current.findIndex((r) => r.id === rule.id);
  const updated = idx >= 0 ? current.map((r, i) => (i === idx ? rule : r)) : [...current, rule];
  saveState({ autoReactRules: updated });
}

export function deleteAutoReactRule(id: string): boolean {
  const state = loadState();
  const current = state.autoReactRules || [];
  const filtered = current.filter((r) => r.id !== id);
  if (filtered.length === current.length) return false;
  saveState({ autoReactRules: filtered });
  return true;
}

export function toggleAutoReactRule(id: string, forceState?: boolean): AutoReactRule | undefined {
  const state = loadState();
  const current = state.autoReactRules || [];
  const target = current.find((r) => r.id === id);
  if (!target) return undefined;
  const updated: AutoReactRule = {
    ...target,
    enabled: typeof forceState === 'boolean' ? forceState : !target.enabled,
  };
  upsertAutoReactRule(updated);
  return updated;
}

export function recordRuleTrigger(id: string): void {
  const state = loadState();
  const current = state.autoReactRules || [];
  const target = current.find((r) => r.id === id);
  if (!target) return;
  const updated: AutoReactRule = {
    ...target,
    triggerCount: (target.triggerCount || 0) + 1,
    lastTriggeredAt: Date.now(),
  };
  upsertAutoReactRule(updated);
}


