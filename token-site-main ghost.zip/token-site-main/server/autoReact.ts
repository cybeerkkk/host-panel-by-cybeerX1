// Auto-react hooks are registered directly in botManager.ts via the messageCreate listener.
// This file is intentionally a no-op stub kept for import compatibility.
export {};
