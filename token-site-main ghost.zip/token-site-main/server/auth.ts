import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from './config.ts';
import { logs } from './logger.ts';
import {
  getKeyByCode,
  getKeyById,
  getOwnerPassword,
  recordKeyUsage,
} from './store.ts';
import type { AccessKey, StreamEvent, UserRole } from '../shared/types.ts';

const COOKIE = 'gvc_session';

/**
 * Session cookie attributes, in one place so every login path gets the same
 * hardening.
 *
 * sameSite was 'none' in production, which tells the browser to attach the
 * cookie to requests started by *any* other site — with no CSRF token in the
 * app that meant a page on another domain could fire authenticated POSTs at
 * this API. 'lax' still covers normal top-level navigation to the dashboard
 * (the front-end and API share one origin) while blocking cross-site writes.
 */
function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: config.isProduction,
    maxAge: config.sessionTtlMs,
    path: '/',
  };
}

export interface RequestAuth {
  role: UserRole;
  sessionId: string;
  keyId?: string;
  key?: AccessKey;
}

declare global {
  namespace Express {
    interface Request {
      auth?: RequestAuth;
    }
  }
}

// ------------------------------------------------------------- Signed Token Engine

function sign(payload: string): string {
  return crypto.createHmac('sha256', config.sessionSecret).update(payload).digest('hex');
}

/**
 * Token format:
 * v2.<role>.<sessionId>.<expiry>.<keyIdOrDash>.<hmac>
 */
export function issueToken(role: UserRole, sessionId: string, keyId = '-'): string {
  const expiry = String(Date.now() + config.sessionTtlMs);
  const payload = `v2.${role}.${sessionId}.${expiry}.${keyId}`;
  const mac = sign(payload);
  return `${payload}.${mac}`;
}

export function verifyToken(raw: unknown): RequestAuth | null {
  if (typeof raw !== 'string' || !raw) return null;

  // Check v2 format first
  if (raw.startsWith('v2.')) {
    const parts = raw.split('.');
    if (parts.length !== 6) return null;
    const [_v, roleStr, sessionId, expiryStr, keyIdStr, mac] = parts;
    const payload = `v2.${roleStr}.${sessionId}.${expiryStr}.${keyIdStr}`;
    const expectedMac = sign(payload);

    if (mac.length !== expectedMac.length) return null;
    if (!crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expectedMac))) return null;

    const expiry = Number.parseInt(expiryStr, 10);
    if (!Number.isFinite(expiry) || expiry <= Date.now()) return null;

    const role: UserRole = roleStr === 'owner' ? 'owner' : 'user';

    if (role === 'owner') {
      // Check revocation list — lets owner sessions be killed without waiting for TTL
      if (revokedOwnerSessions.has(sessionId)) return null;
      return { role: 'owner', sessionId };
    }

    // Role is user: validate against database/store in real time
    if (!keyIdStr || keyIdStr === '-') return null;
    const key = getKeyById(keyIdStr);
    if (!key) return null; // Key was deleted! Instant revocation
    if (key.status !== 'active') return null; // Key was paused/disabled!
    if (key.expiresAt && key.expiresAt <= Date.now()) return null; // Key expired!

    // Check if session was kicked from redeemedUsers
    const userRecord = key.redeemedUsers.find((u) => u.sessionId === sessionId);
    if (!userRecord) return null; // Session kicked by owner!

    return { role: 'user', sessionId, keyId: key.id, key };
  }

  // Anything that is not a v2 token is rejected. The old "<expiry>.<hmac>"
  // format minted an owner session with the fixed id 'legacy-owner', which
  // revokeOwnerSession() could never invalidate — a cookie issued under it
  // stayed valid for the full TTL no matter what the owner did.
  return null;
}

/**
 * Constant-time compare against the current owner password.
 *
 * A password changed through the owner panel is stored as a scrypt hash
 * ("scrypt$<salt>$<hash>"); ACCESS_PASSWORD from the environment is compared
 * literally because the operator supplies it in plain text. Both branches run
 * a fixed amount of work and finish with timingSafeEqual so a wrong password
 * cannot be narrowed down by how long the check took.
 */
function passwordMatches(candidate: string): boolean {
  const current = getOwnerPassword();

  if (current.startsWith('scrypt$')) {
    const [, saltHex, hashHex] = current.split('$');
    if (!saltHex || !hashHex) return false;
    let expected: Buffer;
    let actual: Buffer;
    try {
      expected = Buffer.from(hashHex, 'hex');
      actual = crypto.scryptSync(candidate, Buffer.from(saltHex, 'hex'), expected.length);
    } catch {
      return false;
    }
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  }

  const a = crypto.createHash('sha256').update(candidate).digest();
  const b = crypto.createHash('sha256').update(current).digest();
  return crypto.timingSafeEqual(a, b);
}

/** Produces the stored form for a new owner password. */
export function hashPassword(plain: string): string {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(plain, salt, 32);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

// ------------------------------------------------------------- Real-Time SSE Streams Registry

interface SseClient {
  sessionId: string;
  role: UserRole;
  keyId?: string;
  send: (e: StreamEvent) => void;
  close: () => void;
}

const sseClients = new Map<string, SseClient>();

// Revoked owner session IDs — lets us invalidate an owner cookie before TTL expires
const revokedOwnerSessions = new Set<string>();

export function registerSseClient(
  sessionId: string,
  role: UserRole,
  keyId: string | undefined,
  send: (e: StreamEvent) => void,
  close: () => void,
): () => void {
  sseClients.set(sessionId, { sessionId, role, keyId, send, close });
  return () => {
    sseClients.delete(sessionId);
  };
}

export function revokeKeySessions(keyId: string, reason = 'Access key has been revoked.'): void {
  for (const [sessionId, client] of sseClients.entries()) {
    if (client.keyId === keyId) {
      try {
        client.send({ kind: 'revoked', message: reason });
        client.close();
      } catch {
        // Ignored
      }
      sseClients.delete(sessionId);
    }
  }
}

export function revokeOwnerSession(sessionId: string): void {
  revokedOwnerSessions.add(sessionId);
  // Also close any live SSE connection
  const client = sseClients.get(sessionId);
  if (client) {
    try { client.send({ kind: 'revoked', message: 'Owner session terminated.' }); client.close(); } catch { /* ignored */ }
    sseClients.delete(sessionId);
  }
}

export function revokeUserSession(sessionId: string, reason = 'Your session was terminated by the administrator.'): void {
  const client = sseClients.get(sessionId);
  if (client) {
    try {
      client.send({ kind: 'revoked', message: reason });
      client.close();
    } catch {
      // Ignored
    }
    sseClients.delete(sessionId);
  }
}

// ------------------------------------------------------------- Brute Force Protection

interface Attempt {
  count: number;
  until: number;
}
const attempts = new Map<string, Attempt>();

function clientKey(req: Request): string {
  return req.ip ?? req.socket.remoteAddress ?? 'unknown';
}

setInterval(() => {
  const now = Date.now();
  for (const [key, value] of attempts) {
    if (value.until < now) attempts.delete(key);
  }
}, 60_000).unref();

export function extractToken(req: Request): string | undefined {
  // Accept ONLY the httpOnly cookie — no headers, no query params.
  // This prevents token leakage via Referer headers, server logs, and
  // localStorage persistence across sessions (the original auth bypass).
  const cookie = req.cookies?.[COOKIE];
  if (typeof cookie === 'string' && cookie) return cookie;
  return undefined;
}

// Global login attempt counter — prevents distributed (multi-IP) brute-force
let globalLoginAttempts = 0;
let globalLoginResetAt = Date.now() + 60_000;

export function loginHandler(req: Request, res: Response): void {
  const ip = clientKey(req);
  const now = Date.now();

  // Reset global counter every minute
  if (now > globalLoginResetAt) {
    globalLoginAttempts = 0;
    globalLoginResetAt = now + 60_000;
  }
  globalLoginAttempts++;

  // Hard cap: max 60 login attempts per minute across all IPs
  if (globalLoginAttempts > 60) {
    res.status(429).json({ error: 'Server is busy. Try again shortly.' });
    return;
  }

  const record = attempts.get(ip);

  if (record && record.count >= 12 && record.until > now) {
    const seconds = Math.ceil((record.until - now) / 1000);
    res.status(429).json({ error: `Too many attempts. Try again in ${seconds}s.` });
    return;
  }

  const password = typeof req.body?.password === 'string' ? req.body.password.trim() : '';
  const keyInput = typeof req.body?.key === 'string'
    ? req.body.key.trim()
    : typeof req.body?.code === 'string'
      ? req.body.code.trim()
      : '';

  // 1. Try Owner Login if password provided
  if (password) {
    if (passwordMatches(password)) {
      attempts.delete(ip);
      const sessionId = crypto.randomUUID();
      const token = issueToken('owner', sessionId);
      res.cookie(COOKIE, token, cookieOptions());
      logs.push(`Owner unlocked panel from ${ip}`, 'info');
      // Token is in the httpOnly cookie — don't expose it in the response body
      res.json({ ok: true, role: 'owner' });
      return;
    }

    // Password was wrong
    const next: Attempt = {
      count: (record?.until ?? 0) > now ? (record?.count ?? 0) + 1 : 1,
      until: now + Math.min(15 * 60_000, 20_000 * ((record?.count ?? 0) + 1)),
    };
    attempts.set(ip, next);
    logs.push(`Failed login attempt from ${ip}`, 'warn');
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }

  // 2. Try Owner Permanent Key (env OWNER_PERMANENT_KEY)
  if (keyInput) {
    const ownerPermanentKey = (process.env.OWNER_PERMANENT_KEY ?? '').trim();
    if (ownerPermanentKey) {
      // Use sign() for timing-safe comparison — both values HMAC'd with same secret
      const normExpected = sign(ownerPermanentKey.toLowerCase());
      const normActual   = sign(keyInput.toLowerCase());
      const bufExpected  = Buffer.from(normExpected, 'hex');
      const bufActual    = Buffer.from(normActual, 'hex');
      const isOwnerKey   = bufExpected.length === bufActual.length &&
        crypto.timingSafeEqual(bufExpected, bufActual);

      // No debug logging here. An earlier build logged the expected and
      // supplied key lengths, which any user holding a canViewLogs key could
      // read straight off the live console — a free hint for brute-forcing.
      if (isOwnerKey) {
        attempts.delete(ip);
        const sessionId = crypto.randomUUID();
        const token = issueToken('owner', sessionId);
        res.cookie(COOKIE, token, cookieOptions());
        logs.push(`Owner logged in via permanent key from ${ip}`, 'info');
        res.json({ ok: true, role: 'owner' });
        return;
      }
    } else {
      logs.push('OWNER_PERMANENT_KEY env var is not set or empty', 'warn');
    }
  }

  // 3. Try User Access Key Login
  if (keyInput) {
    const accessKey = getKeyByCode(keyInput);

    if (!accessKey) {
      const next: Attempt = {
        count: (record?.until ?? 0) > now ? (record?.count ?? 0) + 1 : 1,
        until: now + Math.min(15 * 60_000, 10_000 * ((record?.count ?? 0) + 1)),
      };
      attempts.set(ip, next);
      logs.push(`Failed login attempt (key) from ${ip}`, 'warn');
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    // Check status
    if (accessKey.status !== 'active') {
      res.status(403).json({ error: 'This access key has been disabled by the administrator' });
      return;
    }

    // Check expiry
    if (accessKey.expiresAt && accessKey.expiresAt <= now) {
      res.status(403).json({ error: 'This access key has expired' });
      return;
    }

    // Check max uses limit
    // Check if caller already has a valid session cookie for this key — if so,
    // reuse the same sessionId so their existing SSE connection stays alive and
    // they don't burn an extra seat toward maxUses.
    const cookieToken = extractToken(req);
    let existingSessionId: string | null = null;
    if (cookieToken) {
      const cookieAuth = verifyToken(cookieToken);
      if (cookieAuth?.role === 'user' && cookieAuth.keyId === accessKey.id) {
        const record = accessKey.redeemedUsers.find((u) => u.sessionId === cookieAuth.sessionId);
        if (record) existingSessionId = cookieAuth.sessionId;
      }
    }

    // Count distinct IP addresses that have ever redeemed this key so that the
    // maxUses cap is per-device (IP), not per login attempt.
    const existingUser = existingSessionId
      ? accessKey.redeemedUsers.find((u) => u.sessionId === existingSessionId)
      : accessKey.redeemedUsers.find((u) => u.ip === ip);

    if (!existingUser && accessKey.maxUses !== null && accessKey.redeemedUsers.length >= accessKey.maxUses) {
      res.status(403).json({
        error: `Key limit reached. This key is limited to ${accessKey.maxUses} user(s).`,
      });
      return;
    }

    attempts.delete(ip);
    const sessionId = existingUser?.sessionId ?? crypto.randomUUID();
    const userAgent = typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : undefined;

    // Record usage and compute firstUsedAt / expiresAt if duration-based
    const updatedKey = recordKeyUsage(accessKey.id, {
      sessionId,
      ip,
      userAgent,
      redeemedAt: now,
      lastActiveAt: now,
    });

    const token = issueToken('user', sessionId, accessKey.id);
    res.cookie(COOKIE, token, cookieOptions());

    logs.push(`User redeemed key ${accessKey.key} (${accessKey.note || 'no note'}) from ${ip}`, 'info');

    // Token is in the httpOnly cookie — don't expose it in the response body
    res.json({
      ok: true,
      role: 'user',
      keyInfo: {
        id: updatedKey?.id ?? accessKey.id,
        key: accessKey.key,
        note: accessKey.note,
        expiresAt: updatedKey?.expiresAt ?? accessKey.expiresAt,
        remainingMs: updatedKey?.expiresAt ? Math.max(0, updatedKey.expiresAt - now) : null,
        permissions: accessKey.permissions,
      },
    });
    return;
  }

  res.status(400).json({ error: 'Please enter an access key or owner password' });
}

export function logoutHandler(req: Request, res: Response): void {
  const token = extractToken(req);
  if (token) {
    const auth = verifyToken(token);
    if (auth?.sessionId) {
      if (auth.role === 'owner') {
        // Add to revoked set so the token is dead even if someone cached it
        revokeOwnerSession(auth.sessionId);
      } else {
        revokeUserSession(auth.sessionId, 'Logged out');
      }
    }
  }
  res.clearCookie(COOKIE, { path: '/' });
  res.json({ ok: true });
}

export function sessionHandler(req: Request, res: Response): void {
  const auth = verifyToken(extractToken(req));
  if (!auth) {
    // Return identical shape whether unauthenticated or expired — no info leak
    res.status(401).json({ authenticated: false });
    return;
  }

  res.json({
    authenticated: true,
    role: auth.role,
    keyInfo: auth.key
      ? {
          id: auth.key.id,
          key: auth.key.key,
          note: auth.key.note,
          expiresAt: auth.key.expiresAt,
          remainingMs: auth.key.expiresAt ? Math.max(0, auth.key.expiresAt - Date.now()) : null,
          permissions: auth.key.permissions,
        }
      : undefined,
  });
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const auth = verifyToken(extractToken(req));
  if (auth) {
    req.auth = auth;
    next();
    return;
  }
  res.status(401).json({ error: 'Not authenticated or access key revoked' });
}

export function requireOwner(req: Request, res: Response, next: NextFunction): void {
  if (req.auth?.role !== 'owner') {
    res.status(403).json({ error: 'Access denied: Owner privileges required' });
    return;
  }
  next();
}
