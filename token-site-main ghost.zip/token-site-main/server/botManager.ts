import crypto from 'node:crypto';
import { Client, Options } from 'discord.js-selfbot-v13';
import { config } from './config.ts';
import { errorMessage, logs, redact } from './logger.ts';
import { defaultConfig, getKeys, getStorageStatus, loadState, saveState, saveStateNow, getAutoReactRules, recordRuleTrigger } from './store.ts';
import type { PersistedSession, PersistedState, PersistedDesiredVoice } from './store.ts';
import type {
  AppConfig,
  BotSession,
  MutualGuild,
  SessionStatus,
  Snapshot,
  UserProfile,
  VoiceSlot,
} from '../shared/types.ts';

/** The gateway opcode for "update my voice state". */
const OP_VOICE_STATE_UPDATE = 4;

/** Where we intend a session to be in ONE guild. Anti-leave restores *this*. */
interface DesiredVoice {
  guildId: string;
  channelId: string;
  selfMute: boolean;
  selfDeaf: boolean;
}

const startedAt = Date.now();

function avatarUrl(userId: string | null, hash: string | null | undefined, size = 128): string | null {
  if (!userId || !hash) return null;
  // Animated avatars are prefixed a_ and only render as .gif.
  const ext = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/avatars/${userId}/${hash}.${ext}?size=${size}`;
}

function iconUrl(guildId: string, hash: string | null | undefined): string | null {
  if (!hash) return null;
  const ext = hash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/icons/${guildId}/${hash}.${ext}?size=64`;
}

/** Discord snowflakes are 17-20 digits. Reject anything else before it hits the API. */
export function isSnowflake(value: unknown): value is string {
  return typeof value === 'string' && /^\d{17,20}$/.test(value);
}

/**
 * One Discord WebSocket connection scoped to a single guild's voice channel.
 * Discord requires a separate gateway session per guild for voice — you cannot
 * be in voice in two guilds over the same WebSocket connection.
 */
class GuildVoiceClient {
  readonly guildId: string;
  client: Client;
  desired: DesiredVoice;

  private leftIntentionallyAt = 0;
  private rejoinTimer: NodeJS.Timeout | null = null;
  private rejoinAttempts = 0;
  destroyed = false;

  constructor(guildId: string, client: Client, desired: DesiredVoice) {
    this.guildId = guildId;
    this.client = client;
    this.desired = desired;
  }

  sendVoiceState(target: { guildId: string; channelId: string | null; selfMute: boolean; selfDeaf: boolean } | null): boolean {
    if (this.client.ws.status !== 0 /* READY */) return false;
    const ws = this.client.ws as unknown as { broadcast?: (p: unknown) => void };
    if (typeof ws?.broadcast !== 'function') return false;
    try {
      ws.broadcast({
        op: OP_VOICE_STATE_UPDATE,
        d: {
          guild_id: target?.guildId ?? null,
          channel_id: target?.channelId || null,
          self_mute: target?.selfMute ?? false,
          self_deaf: target?.selfDeaf ?? false,
          self_video: false,
          flags: 2,
        },
      });
      return true;
    } catch (err) {
      logs.push(`GuildVoiceClient ${this.guildId}: voice payload failed - ${errorMessage(err)}`, 'error');
      return false;
    }
  }

  join(desired: DesiredVoice): boolean {
    this.leftIntentionallyAt = Date.now();
    if (this.rejoinTimer) { clearTimeout(this.rejoinTimer); this.rejoinTimer = null; }
    this.desired = desired;
    this.rejoinAttempts = 0;
    return this.sendVoiceState(desired);
  }

  updateVoiceState(patch: { selfMute?: boolean; selfDeaf?: boolean }): boolean {
    this.desired = { ...this.desired, selfMute: patch.selfMute ?? this.desired.selfMute, selfDeaf: patch.selfDeaf ?? this.desired.selfDeaf };
    return this.sendVoiceState(this.desired);
  }

  leave(): boolean {
    this.leftIntentionallyAt = Date.now();
    if (this.rejoinTimer) { clearTimeout(this.rejoinTimer); this.rejoinTimer = null; }
    return this.sendVoiceState({ guildId: this.guildId, channelId: null, selfMute: false, selfDeaf: false });
  }

  markIntentionalLeave() {
    this.leftIntentionallyAt = Date.now();
  }

  wasIntentionalLeave(): boolean {
    return Date.now() - this.leftIntentionallyAt < 5000;
  }

  resetRejoin(): void {
    this.rejoinAttempts = 0;
    if (this.rejoinTimer) { clearTimeout(this.rejoinTimer); this.rejoinTimer = null; }
  }

  scheduleRejoin(reason: string, username: string): void {
    if (this.rejoinTimer || this.destroyed) return;
    if (this.rejoinAttempts >= 6) {
      logs.push(`${username}: anti-leave gave up (guild ${this.guildId}) after 6 tries — rejoin manually`, 'error');
      return;
    }
    const backoff = Math.min(1000 * 2 ** this.rejoinAttempts, 30_000) + Math.random() * 400;
    this.rejoinAttempts++;
    this.rejoinTimer = setTimeout(() => {
      this.rejoinTimer = null;
      if (this.destroyed) return;
      const ok = this.sendVoiceState(this.desired);
      logs.push(ok
        ? `Anti-leave returned ${username} to voice in guild ${this.guildId} (${reason}, try ${this.rejoinAttempts})`
        : `Anti-leave: gateway unreachable for ${username} in guild ${this.guildId}`,
        ok ? 'anti-leave' : 'error');
    }, backoff);
  }

  voiceSlot(): VoiceSlot | null {
    const selfId = this.client.user?.id;
    if (!selfId) return null;
    for (const guild of this.client.guilds.cache.values()) {
      if (guild.id !== this.guildId) continue;
      const state = (guild as any).voiceStates?.cache?.get(selfId);
      if (!state?.channelId) return null;
      return {
        guildId: guild.id,
        guildName: guild.name,
        channelId: state.channelId,
        channelName: state.channel?.name ?? null,
        selfMute: Boolean(state.selfMute ?? state.mute),
        selfDeaf: Boolean(state.selfDeaf ?? state.deaf),
      };
    }
    return null;
  }

  async teardown(): Promise<void> {
    this.destroyed = true;
    if (this.rejoinTimer) { clearTimeout(this.rejoinTimer); this.rejoinTimer = null; }
    try {
      this.client.removeAllListeners();
      await this.client.destroy();
    } catch { /* already gone */ }
  }
}

/** Turns a raw login error into something the person importing the token can act on. */
function friendlyLoginError(err: unknown, token: string): string {
  const message = errorMessage(err);
  if (/invalid token/i.test(message)) {
    if (token.split('.').length !== 3) {
      return 'Discord rejected it: this is not a user token (a user token has 3 parts separated by dots). Bot tokens do not work here.';
    }
    return 'Discord rejected this token: it is revoked or expired (logged out, password changed, account locked) - copy a fresh one.';
  }
  if (/timed out/i.test(message)) return 'Login timed out - try again in a minute.';
  return message;
}

class Session {
  readonly id: string;
  readonly token: string;

  /** Primary client — used for presence, guilds list, radar, auto-react, etc. */
  client: Client | null = null;
  status: SessionStatus = 'offline';
  error: string | null = null;

  antiLeave = true;
  autoFollow = false;

  /**
   * One GuildVoiceClient per guild the bot is in voice in.
   * Each uses its own WebSocket connection because Discord does not allow
   * multi-guild voice over a single gateway session.
   */
  private voiceClients: Map<string, GuildVoiceClient> = new Map();
  private destroyed = false;

  constructor(token: string, id?: string, antiLeave = true, autoFollow = false) {
    this.token = token;
    this.id = id ?? crypto.randomUUID();
    this.antiLeave = antiLeave;
    this.autoFollow = autoFollow;
  }

  get userId(): string | null {
    return this.client?.user?.id ?? null;
  }

  get username(): string {
    return this.client?.user?.username ?? 'Unknown';
  }

  /**
   * Connects the primary client (presence + guild cache + radar + auto-react).
   * Voice connections are created separately per guild via joinVoiceGuild().
   */
  async connect(): Promise<void> {
    if (this.status === 'online' || this.status === 'connecting') return;

    this.status = 'connecting';
    this.error = null;

    const client = new Client({
      makeCache: Options.cacheWithLimits({
        MessageManager: 0,
        PresenceManager: 0,
        GuildStickerManager: 0,
        GuildScheduledEventManager: 0,
        GuildEmojiManager: 0,
        ReactionManager: 0,
      }),
      restRequestTimeout: 20000,
      waitGuildTimeout: 10000,
    });
    this.client = client;

    await new Promise<void>((resolve, reject) => {
      let settled = false;

      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        void this.teardown();
        this.status = 'error';
        this.error = 'Timed out waiting for the gateway';
        reject(new Error('Login timed out'));
      }, config.loginTimeoutMs);

      const onReady = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cleanup();
        this.status = 'online';
        this.error = null;
        logs.push(`${this.username} is online (${this.userId})`, 'info');
        manager.notifyChange();
        resolve();
      };

      const onFail = (err: unknown) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cleanup();
        void this.teardown();
        this.status = 'error';
        this.error = errorMessage(err);
        manager.notifyChange();
        reject(err instanceof Error ? err : new Error(errorMessage(err)));
      };

      const cleanup = () => {
        client.off('ready', onReady);
        client.off('error', onFail);
      };

      client.once('ready', onReady);
      client.once('error', onFail);
      client.login(this.token).catch(onFail);
    });

    this.attachListeners();
  }

  /**
   * Creates a SEPARATE Discord WebSocket client for voice in one guild.
   * Discord requires this — voice in guild A and guild B need two separate
   * gateway sessions from the same token.
   */
  async joinVoiceGuild(desired: DesiredVoice): Promise<boolean> {
    if (this.voiceClients.has(desired.guildId)) {
      // Already have a voice client for this guild — just move to new channel
      const vc = this.voiceClients.get(desired.guildId)!;
      vc.join(desired);
      manager.notifyChange();
      manager.persistVoice();
      return true;
    }

    // Spawn a fresh Client for this guild's voice
    const voiceClient = new Client({
      makeCache: Options.cacheWithLimits({
        MessageManager: 0,
        PresenceManager: 0,
        GuildStickerManager: 0,
        GuildScheduledEventManager: 0,
        GuildEmojiManager: 0,
        ReactionManager: 0,
      }),
      restRequestTimeout: 20000,
      waitGuildTimeout: 10000,
    });

    // Connect the voice client
    await new Promise<void>((resolve, reject) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return; settled = true;
        void voiceClient.destroy();
        reject(new Error('Voice client login timed out'));
      }, config.loginTimeoutMs);

      voiceClient.once('ready', () => {
        if (settled) return; settled = true;
        clearTimeout(timer);
        resolve();
      });
      voiceClient.once('error', (err) => {
        if (settled) return; settled = true;
        clearTimeout(timer);
        reject(err);
      });
      void voiceClient.login(this.token).catch((err: unknown) => {
        if (settled) return; settled = true;
        clearTimeout(timer);
        reject(err);
      });
    });

    const gvc = new GuildVoiceClient(desired.guildId, voiceClient, desired);
    this.voiceClients.set(desired.guildId, gvc);

    // Attach voice state listener for anti-leave + anti-move
    voiceClient.on('voiceStateUpdate', (oldState: any, newState: any) => {
      const selfId = voiceClient.user?.id;
      if (!selfId) return;
      const subjectId: string | undefined = newState?.id ?? oldState?.id;
      if (subjectId !== selfId) return;
      // Every voice client sees the account's voice events from ALL guilds. Without
      // this filter a move in guild B rewrote guild A's target channel with B's
      // channel id, so anti-leave kept retrying a channel that does not exist there.
      const eventGuildId: string | undefined = newState?.guild?.id ?? oldState?.guild?.id;
      if (eventGuildId !== gvc.guildId) return;
      manager.notifyChange();
      const wasIn = Boolean(oldState?.channelId);
      const isIn = Boolean(newState?.channelId);
      if (wasIn && !isIn) {
        // Fully removed from voice
        if (gvc.wasIntentionalLeave()) return;
        if (!this.antiLeave || !manager.appConfig.globalAntiLeave) return;
        logs.push(`${this.username} was removed from voice in guild ${desired.guildId}`, 'anti-leave');
        gvc.scheduleRejoin('kicked from voice', this.username);
      } else if (wasIn && isIn && oldState.channelId !== newState.channelId) {
        // Moved to a different channel — update desired so anti-leave tracks the new channel
        if (!gvc.wasIntentionalLeave()) {
          gvc.desired = { ...gvc.desired, channelId: newState.channelId };
          logs.push(`${this.username} was moved to channel ${newState.channelId} in guild ${desired.guildId} — tracking new channel`, 'anti-leave');
          manager.persistVoice();
        }
        gvc.resetRejoin();
      } else if (isIn && newState.channelId === gvc.desired.channelId) {
        gvc.resetRejoin();
      }
    });

    voiceClient.on('shardResume', () => {
      if (gvc.destroyed || !this.antiLeave || !manager.appConfig.globalAntiLeave) return;
      // A resume keeps the voice session. Re-sending the join when we are already in
      // the right channel changes nothing, never produces a voice event to reset the
      // counter, and after 6 resumes made anti-leave give up for no reason.
      const slot = gvc.voiceSlot();
      if (slot && slot.channelId === gvc.desired.channelId) {
        gvc.resetRejoin();
        return;
      }
      gvc.scheduleRejoin('gateway resume', this.username);
    });

    // Send initial join
    const sent = gvc.join(desired);
    manager.notifyChange();
    manager.persistVoice();
    return sent;
  }

  /**
   * Leaves voice in one guild and tears down its dedicated WebSocket client.
   * If guildId is omitted, leaves ALL guilds.
   */
  async leaveVoiceGuild(guildId?: string): Promise<number> {
    const targets = guildId
      ? (this.voiceClients.has(guildId) ? [guildId] : [])
      : [...this.voiceClients.keys()];

    let count = 0;
    for (const id of targets) {
      const gvc = this.voiceClients.get(id);
      if (!gvc) continue;
      gvc.markIntentionalLeave();
      gvc.leave();
      this.voiceClients.delete(id);
      await gvc.teardown();
      count++;
    }
    if (count > 0) {
      manager.notifyChange();
      manager.persistVoice();
    }
    return count;
  }

  private attachListeners(): void {
    const client = this.client;
    if (!client) return;

    client.on('error', (err: unknown) => {
      this.error = errorMessage(err);
      logs.push(`${this.username}: gateway error - ${this.error}`, 'error');
    });

    client.on('shardDisconnect', () => {
      if (this.destroyed) return;
      this.status = 'offline';
      logs.push(`${this.username} disconnected from the gateway`, 'warn');
      manager.notifyChange();
    });

    client.on('shardResume', () => {
      if (this.destroyed) return;
      this.status = 'online';
      logs.push(`${this.username} resumed`, 'info');
      manager.notifyChange();
    });

    // voiceStateUpdate on primary client: used ONLY for auto-follow target tracking
    client.on('voiceStateUpdate', (oldState: any, newState: any) => {
      try {
        const selfId = this.userId;
        const subjectId: string | undefined = newState?.id ?? oldState?.id;
        if (subjectId && subjectId !== selfId) {
          manager.handleTargetMovement(subjectId, oldState, newState);
        }
      } catch (err) {
        logs.push(`voiceStateUpdate handler failed: ${errorMessage(err)}`, 'error');
      }
    });

    client.on('messageCreate', (message: any) => {
      try {
        manager.handleAutoReact(this.id, message);
      } catch (err) {
        logs.push(`messageCreate handler failed: ${errorMessage(err)}`, 'error');
      }
    });
  }

  /** Per-guild mute/deafen update without changing channel. */
  updateVoiceState(guildId: string, patch: { selfMute?: boolean; selfDeaf?: boolean }): boolean {
    const gvc = this.voiceClients.get(guildId);
    if (!gvc) return false;
    const ok = gvc.updateVoiceState(patch);
    manager.persistVoice();
    return ok;
  }

    /** Returns all active voice slots — one per guild voice client. */
  voiceSlots(): VoiceSlot[] {
    const slots: VoiceSlot[] = [];
    for (const gvc of this.voiceClients.values()) {
      if (gvc.destroyed) continue;
      const slot = gvc.voiceSlot();
      if (slot) slots.push(slot);
    }
    return slots;
  }

  /**
   * The channel each guild's voice client is meant to be in. Follows moves by
   * other people (voiceStateUpdate updates `desired`), so a restart brings the
   * account back to where it was last, not to where it was first sent.
   */
  desiredVoiceSnapshot(): Record<string, { guildId: string; channelId: string; selfMute: boolean; selfDeaf: boolean }> {
    const out: Record<string, { guildId: string; channelId: string; selfMute: boolean; selfDeaf: boolean }> = {};
    for (const [guildId, gvc] of this.voiceClients) {
      if (gvc.destroyed || !gvc.desired.channelId) continue;
      out[guildId] = {
        guildId,
        channelId: gvc.desired.channelId,
        selfMute: gvc.desired.selfMute,
        selfDeaf: gvc.desired.selfDeaf,
      };
    }
    return out;
  }

  /** Returns the set of guildIds this session has an active voice client for. */
  activeVoiceGuildIds(): Set<string> {
    return new Set([...this.voiceClients.keys()].filter(g => !this.voiceClients.get(g)!.destroyed));
  }

  toPublic(): BotSession {
    const slots = this.voiceSlots();
    const first = slots[0] ?? null;
    const user = this.client?.user ?? null;

    return {
      id: this.id,
      userId: user?.id ?? null,
      username: user?.username ?? 'Unknown',
      discriminator: user?.discriminator ?? null,
      avatarUrl: avatarUrl(user?.id ?? null, user?.avatar),
      status: this.status,
      error: this.error,
      antiLeave: this.antiLeave,
      antiMove: false,
      antiHost: false,
      autoFollow: this.autoFollow,
      guildCount: this.client?.guilds.cache.size ?? 0,
      tokenHint: this.token.slice(-4),
      // Multi-server voice
      voiceSlots: slots,
      inVoice: slots.length > 0,
      // Legacy single-slot fields — reflect the first slot for backwards compat
      guildId: first?.guildId ?? null,
      guildName: first?.guildName ?? null,
      channelId: first?.channelId ?? null,
      channelName: first?.channelName ?? null,
      selfMute: first?.selfMute ?? false,
      selfDeaf: first?.selfDeaf ?? false,
    };
  }

  async teardown(): Promise<void> {
    this.destroyed = true;

    // Tear down all per-guild voice WebSocket clients first
    const vcTeardowns = [...this.voiceClients.values()].map((gvc) => gvc.teardown());
    this.voiceClients.clear();
    await Promise.allSettled(vcTeardowns);

    // Then tear down the primary client
    const client = this.client;
    this.client = null;
    this.status = 'offline';

    if (!client) return;
    try {
      client.removeAllListeners();
      await client.destroy();
    } catch {
      // Already gone.
    }
  }
}

class BotManager {
  private sessions = new Map<string, Session>();
  /** token -> session id, so the same token is never connected twice. */
  private byToken = new Map<string, string>();
  /** Guards concurrent adds of the same token. */
  private connecting = new Map<string, Promise<Session>>();

  appConfig: AppConfig = { ...defaultConfig };

  private followTimer: NodeJS.Timeout | null = null;
  private queue: Promise<void> = Promise.resolve();

  /** Anything that should push a fresh snapshot to open tabs right away. */
  private changeListeners = new Set<() => void>();

  onChange(listener: () => void): () => void {
    this.changeListeners.add(listener);
    return () => this.changeListeners.delete(listener);
  }

  notifyChange(): void {
    for (const listener of this.changeListeners) listener();
  }

  // ---------------------------------------------------------------- lifecycle

  async restore(): Promise<void> {
    const state = loadState();
    this.appConfig = state.config;

    // Accounts only come from the saved (encrypted) state: they are added and
    // removed from the website, never from environment variables.
    const queue: PersistedSession[] = [...state.sessions];

    if (queue.length === 0) return;

    // Keep not-yet-connected accounts visible to persist(): a restore of many
    // accounts is staggered and takes minutes, and any save during that time
    // must not drop the ones still waiting.
    this.restoreQueue = new Map(queue.map((q) => [q.token, q]));

    logs.push(
      `Restoring ${queue.length} saved account(s)...`,
      'info',
    );

    // A few accounts log in and rejoin voice at once instead of strictly one at
    // a time, so a large fleet is back in voice in roughly queue.length /
    // RESTORE_CONCURRENCY rounds — the gap people in voice see after a redeploy
    // is shorter. Each worker still staggers its own logins/joins so Discord
    // never sees more than RESTORE_CONCURRENCY logins land at once.
    let cursor = 0;
    const worker = async () => {
      while (cursor < queue.length) {
        const saved = queue[cursor++];
        // removeAll() during a restore clears the queue: stop reconnecting.
        if (!this.restoreQueue.has(saved.token)) continue;
        const session = new Session(saved.token, saved.id, saved.antiLeave, saved.autoFollow);
        this.sessions.set(session.id, session);
        this.byToken.set(saved.token, session.id);
        this.restoreQueue.delete(saved.token);

        try {
          await session.connect();
          // Re-join voice channels that were active before the restart
          if (session.status === 'online' && saved.desiredVoice) {
            const pending = { ...saved.desiredVoice };
            this.restoringVoice.set(session.id, pending);
            for (const d of Object.values(saved.desiredVoice)) {
              for (let attempt = 1; attempt <= 3; attempt += 1) {
                try {
                  await session.joinVoiceGuild(d);
                  delete pending[d.guildId];
                  break;
                } catch (err) {
                  logs.push(
                    `Restore voice failed for ${session.username} in guild ${d.guildId} (try ${attempt}/3): ${errorMessage(err)}`,
                    'error',
                  );
                  if (attempt < 3) await delay(5_000);
                }
              }
              await delay(config.joinStaggerMs);
            }
            if (Object.keys(pending).length === 0) this.restoringVoice.delete(session.id);
          } else if (saved.desiredVoice && Object.keys(saved.desiredVoice).length > 0) {
            // Login failed this boot: keep its saved voice slots instead of erasing them on the next save.
            this.restoringVoice.set(session.id, { ...saved.desiredVoice });
          }
        } catch (err) {
          logs.push(`Token ${redact(saved.token)} failed: ${errorMessage(err)}`, 'error');
        }
        await delay(config.joinStaggerMs);
      }
    };

    await Promise.all(Array.from({ length: Math.min(RESTORE_CONCURRENCY, queue.length) }, worker));

    this.restoreQueue.clear();
    this.persist();
  }

  private restoreQueue = new Map<string, PersistedSession>();
  /** Saved voice slots of accounts whose voice is not rejoined yet; kept so a save mid-restore cannot drop them. */
  private restoringVoice = new Map<string, Record<string, PersistedDesiredVoice>>();

  /** Debounced save after any voice join / move / leave / mute change. */
  persistVoice(): void {
    this.persist();
  }

  private persist(): void {
    saveState(this.snapshotForDisk());
  }

  /** Awaited save: returns once the encrypted state is on disk and pushed to Supabase. */
  private persistNow(): Promise<void> {
    return saveStateNow(this.snapshotForDisk());
  }

  private snapshotForDisk(): PersistedState {
    const liveSessions: PersistedSession[] = [...this.sessions.values()].map((s) => ({
      id: s.id,
      token: s.token,
      antiLeave: s.antiLeave,
      autoFollow: s.autoFollow,
      desiredVoice: { ...(this.restoringVoice.get(s.id) ?? {}), ...s.desiredVoiceSnapshot() },
    }));

    // Accounts still waiting to reconnect after a restart stay in the saved list.
    const liveTokens = new Set(liveSessions.map((s) => s.token));
    for (const queued of this.restoreQueue.values()) {
      if (!liveTokens.has(queued.token)) liveSessions.push(queued);
    }

    return {
      version: 1,
      sessions: liveSessions,
      config: this.appConfig,
      keys: getKeys(),
    };
  }

  async shutdown(): Promise<void> {
    if (this.followTimer) clearTimeout(this.followTimer);
    await saveStateNow(this.snapshotForDisk());
    await Promise.allSettled([...this.sessions.values()].map((s) => s.teardown()));
    this.sessions.clear();
    this.byToken.clear();
  }

  // ----------------------------------------------------------------- sessions

  list(): Session[] {
    return [...this.sessions.values()];
  }

  get(id: string): Session | undefined {
    return this.sessions.get(id);
  }

  resolve(ids: unknown): Session[] {
    if (!Array.isArray(ids) || ids.length === 0) return this.list();
    const wanted = new Set(ids.filter((id): id is string => typeof id === 'string'));
    return this.list().filter((s) => wanted.has(s.id));
  }

  async addTokens(
    raw: string,
  ): Promise<{ added: number; failed: number; skipped: number; addedIds: string[]; reasons: string[] }> {
    const tokens = [
      ...new Set(
        raw
          .split(/[\r\n,;]+/)
          .map((t) => t.trim())
          // Strip a quoted paste, which is the most common import mistake.
          .map((t) => t.replace(/^["']|["']$/g, ''))
          .filter((t) => t.length >= 30),
      ),
    ];

    let added = 0;
    let failed = 0;
    let skipped = 0;
    const addedIds: string[] = [];
    const reasons = new Set<string>();

    for (const token of tokens) {
      if (this.byToken.has(token)) {
        skipped += 1;
        continue;
      }
      if (this.sessions.size >= config.maxSessions) {
        logs.push(`Session limit reached (${config.maxSessions}). Skipping the rest.`, 'warn');
        skipped += tokens.length - added - failed - skipped;
        break;
      }

      try {
        const session = await this.connectToken(token);
        added += 1;
        addedIds.push(session.id);
      } catch (err) {
        failed += 1;
        reasons.add(friendlyLoginError(err, token));
        logs.push(`Token ${redact(token)} rejected: ${errorMessage(err)}`, 'error');
      }

      await delay(config.joinStaggerMs);
    }

    if (added > 0) await this.persistNow();
    return { added, failed, skipped, addedIds, reasons: [...reasons] };
  }

  private connectToken(token: string): Promise<Session> {
    const inFlight = this.connecting.get(token);
    if (inFlight) return inFlight;

    const attempt = (async () => {
      const session = new Session(token);
      try {
        await session.connect();
        this.sessions.set(session.id, session);
        this.byToken.set(token, session.id);
        return session;
      } catch (err) {
        // Failed logins must not leak a live socket.
        await session.teardown();
        throw err;
      } finally {
        this.connecting.delete(token);
      }
    })();

    this.connecting.set(token, attempt);
    return attempt;
  }

  async remove(id: string): Promise<boolean> {
    const session = this.sessions.get(id);
    if (!session) {
      // Still waiting in the boot restore queue: drop it from there.
      for (const [token, queued] of this.restoreQueue) {
        if (queued.id !== id) continue;
        this.restoreQueue.delete(token);
        logs.push('Removed a saved account that had not reconnected yet', 'info');
        await this.persistNow();
        this.notifyChange();
        return true;
      }
      return false;
    }

    const name = session.username;
    this.restoringVoice.delete(id);
    this.sessions.delete(id);
    this.byToken.delete(session.token);
    await session.teardown();
    logs.push(`Removed ${name}`, 'info');
    await this.persistNow();
    this.notifyChange();
    return true;
  }

  /**
   * Swap the token of an existing account (e.g. after a token reset). The new
   * token is verified by actually logging in BEFORE the old one is dropped, so a
   * typo can never wipe a working account. Keeps the same id, so assignments to
   * access keys and settings stay intact.
   */
  async replaceToken(id: string, raw: string): Promise<BotSession> {
    const token = raw.trim().replace(/^["']|["']$/g, '');
    if (token.length < 30) throw new Error('That does not look like a valid token');

    const old = this.sessions.get(id);
    if (!old) throw new Error('Session not found');
    if (token === old.token) throw new Error('That is already this account\'s token');

    const owner = this.byToken.get(token);
    if (owner && owner !== id) throw new Error('That token is already used by another account');
    if (this.connecting.has(token)) throw new Error('That token is already being connected');

    const fresh = new Session(token, id, old.antiLeave, old.autoFollow);
    try {
      await fresh.connect();
    } catch (err) {
      await fresh.teardown();
      throw new Error(`The new token was rejected: ${errorMessage(err)}`);
    }

    this.byToken.delete(old.token);
    this.sessions.set(id, fresh);
    this.byToken.set(token, id);
    await old.teardown();
    logs.push(`Token updated for ${fresh.username}`, 'info');
    await this.persistNow();
    this.notifyChange();
    return fresh.toPublic();
  }

  async removeAll(): Promise<number> {
    const count = this.sessions.size;
    await Promise.allSettled(this.list().map((s) => s.teardown()));
    this.sessions.clear();
    this.byToken.clear();
    this.restoreQueue.clear();
    logs.push(`Removed all ${count} account(s)`, 'info');
    await this.persistNow();
    this.notifyChange();
    return count;
  }

  async reconnect(id: string): Promise<void> {
    const session = this.sessions.get(id);
    if (!session) throw new Error('Session not found');

    await session.teardown();
    const fresh = new Session(session.token, session.id, session.antiLeave, session.autoFollow);
    this.sessions.set(fresh.id, fresh);
    this.byToken.set(fresh.token, fresh.id);
    await fresh.connect();
  }

  // -------------------------------------------------------------------- voice

  /**
   * Runs voice actions one at a time with a stagger.
   *
   * Firing 40 op-4 payloads in the same tick is what gets accounts rate limited
   * or disconnected, so every bulk action funnels through this queue.
   */
  private enqueue(task: () => Promise<void>): Promise<void> {
    this.queue = this.queue.then(task).catch((err) => {
      logs.push(`Queued action failed: ${errorMessage(err)}`, 'error');
    });
    return this.queue;
  }

  async joinVoice(opts: {
    ids?: unknown;
    guildId: string;
    channelId: string;
    selfMute: boolean;
    selfDeaf: boolean;
  }): Promise<{ sent: number; skipped: number }> {
    const targets = this.resolve(opts.ids).filter((s) => s.status === 'online');

    // Fire all joins in parallel — every bot enters at the exact same moment
    const results = await Promise.allSettled(
      targets.map((session) =>
        session.joinVoiceGuild({
          guildId: opts.guildId,
          channelId: opts.channelId,
          selfMute: opts.selfMute,
          selfDeaf: opts.selfDeaf,
        }).catch((err) => {
          logs.push(`${session.username}: failed to join voice in guild ${opts.guildId} — ${errorMessage(err)}`, 'error');
          return false;
        }),
      ),
    );

    const sent = results.filter((r) => r.status === 'fulfilled' && r.value === true).length;
    logs.push(`Sent ${sent} account(s) to voice channel ${opts.channelId} in guild ${opts.guildId}`, 'join');
    return { sent, skipped: targets.length - sent };
  }

  /**
   * Flips mute/deafen for one or more accounts without touching voice
   * channel or the other accounts already in it — same queue and stagger
   * as join/leave so this never fires alongside a bulk action in the same tick.
   */
  async setVoiceFlags(
    ids: unknown,
    guildId: string,
    patch: { selfMute?: boolean; selfDeaf?: boolean },
  ): Promise<{ sent: number; skipped: number }> {
    const targets = this.resolve(ids).filter((s) => s.status === 'online' && s.activeVoiceGuildIds().has(guildId));
    let sent = 0;

    await this.enqueue(async () => {
      for (const session of targets) {
        if (session.updateVoiceState(guildId, patch)) sent += 1;
        await delay(Math.min(config.joinStaggerMs, 250));
      }
    });

    return { sent, skipped: targets.length - sent };
  }

  /**
   * Leave voice. If guildId is provided, only leave that guild.
   * Otherwise leave ALL guilds for each targeted session.
   * Tears down the dedicated WebSocket client for each guild left.
   */
  async leaveVoice(ids?: unknown, guildId?: string): Promise<number> {
    const targets = this.resolve(ids).filter((s) => s.status === 'online');
    let sent = 0;

    await this.enqueue(async () => {
      for (const session of targets) {
        sent += await session.leaveVoiceGuild(guildId);
        await delay(Math.min(config.joinStaggerMs, 250));
      }
    });

    logs.push(
      guildId
        ? `Pulled ${sent} account(s) out of voice in guild ${guildId}`
        : `Pulled ${sent} account(s) out of all voice channels`,
      'leave',
    );
    return sent;
  }

  // -------------------------------------------------------------- auto-follow

  /** Called from every session's voiceStateUpdate; debounced into one move. */
  handleTargetMovement(subjectId: string, _oldState: any, newState: any): void {
    const cfg = this.appConfig;
    if (!cfg.autoFollowEnabled || !cfg.autoFollowTargetId) return;
    if (subjectId !== cfg.autoFollowTargetId) return;

    const guildId: string | null = newState?.guild?.id ?? null;
    const channelId: string | null = newState?.channelId ?? null;

    // Several accounts see the same event. Debounce so one move is issued.
    if (this.followTimer) clearTimeout(this.followTimer);
    this.followTimer = setTimeout(() => {
      this.followTimer = null;
      const followers = this.list().filter((s) => s.autoFollow && s.status === 'online');
      if (followers.length === 0) return;

      if (channelId && guildId) {
        logs.push(`Target moved. Following with ${followers.length} account(s).`, 'follow');
        void this.joinVoice({
          ids: followers.map((s) => s.id),
          guildId,
          channelId,
          selfMute: cfg.selfMute,
          selfDeaf: cfg.selfDeaf,
        });
      } else {
        logs.push('Target left voice. Pulling followers out.', 'follow');
        void this.leaveVoice(followers.map((s) => s.id));
      }
    }, 700);
  }

  // -------------------------------------------------------------- auto-react

  handleAutoReact(sessionId: string, message: any): void {
    const rules = getAutoReactRules();
    if (rules.length === 0) return;

    const session = this.sessions.get(sessionId);
    if (!session || session.status !== 'online') return;

    const authorId: string | undefined = message.author?.id;
    if (!authorId) return;

    // Collect matching rules for this message
    const matching = rules.filter((r) =>
      r.enabled &&
      r.targetUserId === authorId &&
      (r.botScope !== 'specific' || r.botIds.includes(sessionId)),
    );
    if (matching.length === 0) return;

    // Fire ALL matching reactions in parallel — no artificial delay
    const promises = matching.map(async (rule) => {
      // Extract raw ID for custom emoji <:name:123456> or <a:name:123456>
      const m = rule.emoji.match(/<a?:.+?:(\d+)>/);
      const reactionEmoji = m ? m[1] : rule.emoji;
      try {
        await message.react(reactionEmoji);
        recordRuleTrigger(rule.id);
      } catch {
        // Silently ignore: unknown emoji, missing perms, deleted message, etc.
      }
    });

    // Notify UI once all settled
    Promise.allSettled(promises).then(() => this.notifyChange());
  }

  // ------------------------------------------------------------------- config

  updateConfig(patch: Partial<AppConfig>): AppConfig {
    const next: AppConfig = { ...this.appConfig };

    if (typeof patch.defaultGuildId === 'string') next.defaultGuildId = patch.defaultGuildId.trim();
    if (typeof patch.defaultChannelId === 'string') {
      next.defaultChannelId = patch.defaultChannelId.trim();
    }
    if (typeof patch.autoFollowTargetId === 'string') {
      next.autoFollowTargetId = patch.autoFollowTargetId.trim();
    }
    if (typeof patch.autoFollowEnabled === 'boolean') next.autoFollowEnabled = patch.autoFollowEnabled;
    if (typeof patch.globalAntiLeave === 'boolean') next.globalAntiLeave = patch.globalAntiLeave;
    if (typeof patch.selfMute === 'boolean') next.selfMute = patch.selfMute;
    if (typeof patch.selfDeaf === 'boolean') next.selfDeaf = patch.selfDeaf;

    this.appConfig = next;
    this.persist();
    this.notifyChange();
    return next;
  }

  setSessionFlag(id: string, flag: 'antiLeave' | 'autoFollow', value: boolean): BotSession | null {
    const session = this.sessions.get(id);
    if (!session) return null;
    session[flag] = value;
    this.persist();
    this.notifyChange();
    return session.toPublic();
  }

  // ----------------------------------------------------------------- snapshot

  snapshot(): Snapshot {
    const sessions = this.list().map((s) => s.toPublic());
    return {
      sessions,
      storage: getStorageStatus(),
      config: this.appConfig,
      autoReactRules: getAutoReactRules(),
      stats: {
        total: sessions.length,
        online: sessions.filter((s) => s.status === 'online').length,
        inVoice: sessions.filter((s) => s.inVoice).length,
        uptimeSeconds: Math.floor((Date.now() - startedAt) / 1000),
      },
    };
  }

  // ------------------------------------------------------------------- radar

  /** Cached + de-duplicated lookup: repeat searches are instant, parallel ones share one fetch. */
  lookupProfile(userId: string): Promise<UserProfile> {
    const hit = profileCache.get(userId);
    if (hit && Date.now() - hit.at < PROFILE_TTL_MS) return Promise.resolve(hit.value);
    const pending = profileInflight.get(userId);
    if (pending) return pending;
    const p = this.buildProfile(userId)
      .then((value) => {
        if (!partialProfiles.has(value)) profileCache.set(userId, { at: Date.now(), value });
        if (profileCache.size > 500) profileCache.delete(profileCache.keys().next().value as string);
        return value;
      })
      .finally(() => profileInflight.delete(userId));
    profileInflight.set(userId, p);
    return p;
  }

  /** Highest rank (owner / administrator / admin) of a user in each of their mutual servers. */
  lookupRanks(userId: string): Promise<Record<string, GuildRankKey>> {
    const hit = rankCache.get(userId);
    if (hit && Date.now() - hit.at < RANK_TTL_MS) return Promise.resolve(hit.value);
    const pending = rankInflight.get(userId);
    if (pending) return pending;
    const p = this.buildRanks(userId)
      .then((value) => {
        rankCache.set(userId, { at: Date.now(), value });
        if (rankCache.size > 300) rankCache.delete(rankCache.keys().next().value as string);
        return value;
      })
      .finally(() => rankInflight.delete(userId));
    rankInflight.set(userId, p);
    return p;
  }

  private async buildRanks(userId: string): Promise<Record<string, GuildRankKey>> {
    const profile = await this.lookupProfile(userId);
    const online = this.list().filter((s) => s.status === 'online' && s.client);
    const ADMIN_BIT = 1n << 3n;
    const ELEVATED_BITS = [1, 2, 4, 5, 13, 28, 40].reduce((acc, n) => acc | (1n << BigInt(n)), 0n);
    const result: Record<string, GuildRankKey> = {};
    const ids = profile.mutualGuilds.map((g) => g.id).slice(0, 300);
    let cursor = 0;

    const rankOf = async (guildId: string): Promise<GuildRankKey | null> => {
      const guilds: any[] = [];
      for (const session of online) {
        const g = session.client!.guilds.cache.get(guildId);
        if (g) guilds.push(g);
      }
      if (guilds.length === 0) return null;
      if (String((guilds[0] as any).ownerId ?? '') === userId) return 'owner';

      let member: any = null;
      for (const g of guilds) {
        const cached = g.members?.cache?.get(userId);
        if (cached?.roles?.cache) { member = cached; break; }
      }
      for (const g of guilds) {
        if (member) break;
        try {
          member = await withTimeout<any>(g.members.fetch(userId), BOT_MUTUAL_CALL_TIMEOUT_MS);
        } catch {
          /* try the next token that is in this server */
        }
      }
      if (!member?.roles?.cache) return null;

      let best: GuildRankKey | null = null;
      for (const roleId of member.roles.cache.keys()) {
        const role: any = guilds[0].roles?.cache?.get(roleId);
        if (!role || role.name === '@everyone') continue;
        const bits = role.permissions?.bitfield !== undefined ? BigInt(role.permissions.bitfield.toString()) : 0n;
        if ((bits & ADMIN_BIT) === ADMIN_BIT) return 'administrator';
        if ((bits & ELEVATED_BITS) !== 0n) best = 'admin';
      }
      return best;
    };

    const run = async () => {
      while (cursor < ids.length) {
        const id = ids[cursor++];
        try {
          const rank = await rankOf(id);
          if (rank) result[id] = rank;
        } catch {
          /* leave this server without a badge */
        }
      }
    };
    await Promise.all(Array.from({ length: 12 }, run));
    return result;
  }

  private async buildProfile(userId: string): Promise<UserProfile> {
    const online = this.list().filter((s) => s.status === 'online' && s.client);
    if (online.length === 0) {
      throw new Error('Add at least one working account before searching');
    }

    let rawProfile: any = null;
    let lastError: unknown = null;

    // Ask every online token at once. First answer wins; the rest get a short
    // grace window so their mutual servers can be merged in.
    const { values, error } = await collectFast(
      online.map(async (session) => {
        const p: any = await withTimeout<any>(
          (session.client as any).api.users(userId).profile.get({ query: { with_mutual_guilds: true } }),
          PROFILE_TIMEOUT_MS,
        );
        if (!p?.user) throw new Error('Empty profile');
        return p as any;
      }),
      PROFILE_GRACE_MS,
    );
    lastError = error;
    const extraMutuals: Array<{ id: string }> = [];
    if (values.length > 0) {
      rawProfile = values[0];
      for (const v of values) if (Array.isArray(v.mutual_guilds)) extraMutuals.push(...v.mutual_guilds);
    }

    if (!rawProfile) {
      // Fallback: plain fetch on every token in parallel.
      try {
        const u: any = await Promise.any(
          online.map((session) =>
            withTimeout((session.client!.users as any).fetch(userId, { force: true }), PROFILE_TIMEOUT_MS),
          ),
        );
        if (u) {
          rawProfile = {
            user: {
              id: u.id,
              username: u.username,
              global_name: u.globalName ?? u.username,
              avatar: u.avatar,
              banner: u.banner,
              accent_color: u.accentColor,
              bot: Boolean(u.bot),
              public_flags: typeof u.flags?.bitfield === 'number' ? u.flags.bitfield : 0,
            },
            user_profile: { bio: u.bio ?? '' },
            mutual_guilds: [],
          };
        }
      } catch (err) {
        lastError = err instanceof AggregateError ? err.errors[0] ?? lastError : err;
      }
    }

    if (!rawProfile) {
      throw new Error(
        lastError instanceof Error
          ? lastError.message
          : 'User not found or not visible to any of your accounts',
      );
    }

    const user = rawProfile.user;
    let bio = rawProfile.user_profile?.bio ?? user.bio ?? '';
    const profileMutuals: Array<{ id: string }> = [
      ...(Array.isArray(rawProfile.mutual_guilds) ? rawProfile.mutual_guilds : []),
      ...extraMutuals,
    ];

    // Scan every guild every account can see, not just the first one.
    let voice: {
      guildId: string;
      guildName: string;
      channelId: string;
      channelName: string | null;
      memberCount: number;
      selfMute: boolean;
      selfDeaf: boolean;
    } | null = null;

    outer: for (const session of online) {
      for (const guild of session.client!.guilds.cache.values()) {
        const state = (guild as any).voiceStates?.cache?.get(userId);
        if (!state?.channelId) continue;
        const channel = (guild as any).channels?.cache?.get(state.channelId);
        voice = {
          guildId: guild.id,
          guildName: guild.name,
          channelId: state.channelId,
          channelName: channel?.name ?? state.channel?.name ?? 'Voice Channel',
          memberCount: (channel as any)?.members?.size ?? state.channel?.members?.size ?? 1,
          selfMute: Boolean(state.selfMute ?? state.self_mute),
          selfDeaf: Boolean(state.selfDeaf ?? state.self_deaf),
        };
        break outer;
      }
    }

    /** Resolve a guild id to a name/icon using whichever account can see it. */
    const describeGuild = (guildId: string): MutualGuild => {
      for (const session of online) {
        const guild = session.client!.guilds.cache.get(guildId);
        if (guild) {
          return { id: guild.id, name: guild.name, iconUrl: iconUrl(guild.id, (guild as any).icon) };
        }
      }
      return { id: guildId, name: `Server ${guildId}`, iconUrl: null };
    };

    const mutuals = new Map<string, MutualGuild>();

    // Start with the API answer...
    for (const entry of profileMutuals) {
      if (typeof entry?.id === 'string') mutuals.set(entry.id, describeGuild(entry.id));
    }

    // ...then ALWAYS also scan every guild every online account can see. Discord's
    // mutual_guilds field is reported per-token and regularly omits servers the
    // queried account is a verified member of, so skipping this scan whenever the
    // API already returned something (the old `mutuals.size === 0` gate) silently
    // dropped the majority of a user's real mutual servers across a large fleet
    // of accounts. The Map dedupes, so merging both sources is always safe.
    for (const session of online) {
      for (const guild of session.client!.guilds.cache.values()) {
        if (mutuals.has(guild.id)) continue;
        const isMember =
          (guild as any).members?.cache?.has(userId) ||
          Boolean((guild as any).voiceStates?.cache?.get(userId));
        if (isMember) mutuals.set(guild.id, describeGuild(guild.id));
      }
    }

    const bannerExt = user.banner?.startsWith('a_') ? 'gif' : 'png';

    // Bots: the REST user object carries `bot: true`; fall back to the client cache
    // in case the profile endpoint omitted it. Verified bot = public flag 1 << 16.
    let cachedUser: any = null;
    for (const session of online) {
      cachedUser = (session.client as any)?.users?.cache?.get(userId) ?? null;
      if (cachedUser) break;
    }
    const isBot = Boolean(user.bot ?? cachedUser?.bot);
    const publicFlags = Number(user.public_flags ?? user.flags?.bitfield ?? cachedUser?.flags?.bitfield ?? 0) || 0;
    const isVerifiedBot = isBot && (publicFlags & (1 << 16)) !== 0;

    // Users: the profile API was asked on EVERY token above and their mutual lists are
    // merged, so no per-server REST scan is needed (it was slow and added nothing).
    // Bots: the API returns nothing useful, so check membership server by server. Each
    // server is checked once, by one of the tokens that is in it, spread evenly so all
    // tokens work in parallel. Deadline: a slow scan finishes in the background and
    // fills the cache; the partial profile itself is not cached.
    const apiCount = mutuals.size;
    let partial = false;
    if (isBot) {
      const cached = botMutualCache.get(userId);
      if (cached && Date.now() - cached.at < BOT_MUTUAL_TTL_MS) {
        for (const g of cached.guilds) mutuals.set(g.id, g);
      } else {
        const assigned = new Map<string, any>();
        const load = new Map<number, number>();
        const queues: any[][] = online.map(() => []);
        const owners = new Map<string, number[]>();
        online.forEach((session, i) => {
          load.set(i, 0);
          for (const guild of session.client!.guilds.cache.values()) {
            if (!owners.has(guild.id)) owners.set(guild.id, []);
            owners.get(guild.id)!.push(i);
            if (!assigned.has(guild.id)) assigned.set(guild.id, guild);
          }
        });
        for (const [guildId, idxs] of owners) {
          if (mutuals.has(guildId)) continue;
          const best = idxs.reduce((x, y) => ((load.get(y) ?? 0) < (load.get(x) ?? 0) ? y : x));
          load.set(best, (load.get(best) ?? 0) + 1);
          queues[best].push(online[best].client!.guilds.cache.get(guildId));
        }
        const worker = async (guilds: any[]) => {
          let cursor = 0;
          const run = async () => {
            while (cursor < guilds.length) {
              const guild = guilds[cursor++];
              if (!guild || mutuals.has(guild.id)) continue;
              try {
                const member = await withTimeout<any>(guild.members.fetch(userId), BOT_MUTUAL_CALL_TIMEOUT_MS);
                if (member) mutuals.set(guild.id, describeGuild(guild.id));
              } catch {
                /* not a member of this server, or no access */
              }
            }
          };
          await Promise.all(Array.from({ length: BOT_MUTUAL_PER_TOKEN }, run));
        };
        let finished = false;
        const scanStart = Date.now();
        const scan = Promise.all(queues.map((q) => worker(q.slice(0, BOT_MUTUAL_MAX_GUILDS)))).then(() => {
          finished = true;
          botMutualCache.set(userId, { at: Date.now(), guilds: [...mutuals.values()] });
          logs.push(
            `[lookup-scan] ${userId}: done in ${Date.now() - scanStart}ms, checked ${assigned.size} unique servers over ${online.length} tokens, total=${mutuals.size}`,
            'info',
          );
        });
        await Promise.race([scan, delay(BOT_MUTUAL_DEADLINE_MS)]);
        partial = !finished;
      }
    }
    logs.push(
      `[lookup] ${user.id}: tokens=${online.length} api=${apiCount} total=${mutuals.size}${partial ? ' (scan still running)' : ''}`,
      'info',
    );

    const result: UserProfile = {
      userId: user.id,
      username: user.username,
      globalName: user.global_name ?? user.globalName ?? null,
      avatarUrl: avatarUrl(user.id, user.avatar, 256),
      bannerUrl: user.banner
        ? `https://cdn.discordapp.com/banners/${user.id}/${user.banner}.${bannerExt}?size=600`
        : null,
      accentColor: typeof user.accent_color === 'number'
        ? `#${user.accent_color.toString(16).padStart(6, '0')}`
        : typeof user.accentColor === 'number'
        ? `#${user.accentColor.toString(16).padStart(6, '0')}`
        : null,
      bio,
      createdAt: Number((BigInt(user.id) >> 22n) + 1420070400000n), // calculate createdAt directly from snowflake!
      badges: typeof user.flags?.toArray === 'function' ? user.flags.toArray() : [],
      isBot,
      isVerifiedBot,
      inVoice: Boolean(voice),
      voiceGuildId: voice?.guildId ?? null,
      voiceGuildName: voice?.guildName ?? null,
      voiceChannelId: voice?.channelId ?? null,
      voiceChannelName: voice?.channelName ?? null,
      voiceMemberCount: voice?.memberCount ?? 0,
      voiceSelfMute: voice?.selfMute ?? false,
      voiceSelfDeaf: voice?.selfDeaf ?? false,
      mutualGuilds: [...mutuals.values()].slice(0, 300),
    };
    if (partial) partialProfiles.add(result);
    return result;
  }
}

export type GuildRankKey = 'owner' | 'administrator' | 'admin';
const RANK_TTL_MS = 2 * 60_000;
const rankCache = new Map<string, { at: number; value: Record<string, GuildRankKey> }>();
const rankInflight = new Map<string, Promise<Record<string, GuildRankKey>>>();
const PROFILE_TTL_MS = 30_000;
const PROFILE_TIMEOUT_MS = 6_000;
const PROFILE_GRACE_MS = 2_500;
const profileCache = new Map<string, { at: number; value: UserProfile }>();
const profileInflight = new Map<string, Promise<UserProfile>>();

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Request timed out')), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}

/** Resolves once the first task succeeds plus `graceMs`, or when all tasks have settled. */
function collectFast<T>(tasks: Promise<T>[], graceMs: number): Promise<{ values: T[]; error: unknown }> {
  return new Promise((resolve) => {
    const values: T[] = [];
    let error: unknown = null;
    let pending = tasks.length;
    let timer: ReturnType<typeof setTimeout> | null = null;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      if (timer) clearTimeout(timer);
      resolve({ values, error });
    };
    if (pending === 0) return finish();
    for (const task of tasks) {
      task.then(
        (v) => {
          if (done) return;
          values.push(v);
          if (!timer) timer = setTimeout(finish, graceMs);
        },
        (e) => { error = e; },
      ).finally(() => {
        pending -= 1;
        if (pending === 0) finish();
      });
    }
  });
}

const RESTORE_CONCURRENCY = 3;
const BOT_MUTUAL_TTL_MS = 10 * 60_000;
const BOT_MUTUAL_MAX_GUILDS = 400;
const BOT_MUTUAL_PER_TOKEN = 6;
const BOT_MUTUAL_CALL_TIMEOUT_MS = 2_000;
const BOT_MUTUAL_DEADLINE_MS = 4_000;
const partialProfiles = new WeakSet<object>();
const botMutualCache = new Map<string, { at: number; guilds: MutualGuild[] }>();

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Member search with EVERY online token at once: each token searches all of its own
 * servers (own request pool per token, so tokens never queue behind each other).
 * Resolves after `deadlineMs` at the latest; slower calls keep running, still call
 * onHit and fill the client's member cache, so the next search finds them instantly.
 */
export async function searchAllTokens(
  sessions: Array<{ client?: any }>,
  query: string,
  deadlineMs: number,
  onHit: (guild: any, member: any) => void,
): Promise<void> {
  const perToken = async (client: any) => {
    const guilds: any[] = [...(client?.guilds?.cache?.values?.() ?? [])].slice(0, 400);
    let cursor = 0;
    const run = async () => {
      while (cursor < guilds.length) {
        const guild = guilds[cursor++];
        try {
          const found: any = await withTimeout<any>(
            guild.members.search({ query, limit: 10, cache: true }),
            deadlineMs,
          );
          for (const m of found.values()) onHit(guild, m);
        } catch {
          /* this token can't search that server */
        }
      }
    };
    await Promise.all(Array.from({ length: 6 }, run));
  };
  await Promise.race([
    Promise.all(sessions.map((s) => perToken(s.client))),
    delay(deadlineMs),
  ]);
}

export const manager = new BotManager();
