-- Run this ONCE in Supabase > SQL Editor.
-- Stores the app state (imported Discord accounts, config, access keys) as an
-- encrypted blob, so it survives restarts, redeploys and updates.

create table if not exists public.gvc_state (
  id text primary key default 'main',
  rev bigint not null default 0,
  payload text not null,
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Lock it down: only the service_role key (used by the server) can access it.
alter table public.gvc_state enable row level security;

-- Recommended for the existing tables too (skipped if they do not exist).
alter table if exists public.gvc_access_keys enable row level security;
alter table if exists public.gvc_audit_logs enable row level security;

-- Only the service_role key (used by the server) may touch these tables.
revoke all on table public.gvc_state, public.gvc_access_keys, public.gvc_audit_logs from anon, authenticated, public;
grant all on table public.gvc_state, public.gvc_access_keys, public.gvc_audit_logs to service_role;

-- Rolling backup: the previous encrypted payload is archived on every update
-- (last 30 kept), so a bad write can never destroy the saved accounts.
create table if not exists public.gvc_state_history (
  hid bigserial primary key,
  state_id text not null,
  rev bigint not null,
  payload text not null,
  archived_at timestamptz not null default timezone('utc'::text, now())
);
alter table public.gvc_state_history enable row level security;
revoke all on table public.gvc_state_history from anon, authenticated, public;
grant all on table public.gvc_state_history to service_role;
grant usage, select on sequence public.gvc_state_history_hid_seq to service_role;

create or replace function public.gvc_state_archive() returns trigger
language plpgsql security invoker set search_path = public as $$
begin
  if old.payload is distinct from new.payload then
    insert into public.gvc_state_history (state_id, rev, payload) values (old.id, old.rev, old.payload);
    delete from public.gvc_state_history
      where state_id = old.id
        and hid not in (select hid from public.gvc_state_history where state_id = old.id order by hid desc limit 30);
  end if;
  return new;
end $$;
revoke execute on function public.gvc_state_archive() from anon, authenticated, public;

drop trigger if exists gvc_state_archive_trg on public.gvc_state;
create trigger gvc_state_archive_trg before update on public.gvc_state
  for each row execute function public.gvc_state_archive();
